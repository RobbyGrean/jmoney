Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem

$BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DefaultTemplateDir = 'C:\Users\MSI\Desktop\Template'
$DefaultOutputDir = Join-Path $BaseDir 'output'
$ManifestPath = Join-Path $BaseDir 'template_tags.json'
$WordNs = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$XmlNs = 'http://www.w3.org/XML/1998/namespace'

function Get-Manifest {
    $json = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $manifest = [ordered]@{}
    foreach ($prop in $json.PSObject.Properties) {
        $manifest[$prop.Name] = @($prop.Value)
    }
    return $manifest
}

function Get-TextNodes {
    param([xml]$Xml)
    $nsm = New-Object System.Xml.XmlNamespaceManager($Xml.NameTable)
    $nsm.AddNamespace('w', $WordNs)
    return @($Xml.SelectNodes('//w:t', $nsm))
}

function ConvertTo-XmlBytes {
    param([xml]$Xml)
    $settings = New-Object System.Xml.XmlWriterSettings
    $settings.Encoding = [System.Text.UTF8Encoding]::new($false)
    $settings.OmitXmlDeclaration = $false
    $settings.Indent = $false
    $memory = New-Object System.IO.MemoryStream
    $writer = [System.Xml.XmlWriter]::Create($memory, $settings)
    $Xml.Save($writer)
    $writer.Close()
    return $memory.ToArray()
}

function Replace-TagsInXmlBytes {
    param(
        [byte[]]$Bytes,
        [hashtable]$Values
    )

    [xml]$xml = [System.Text.Encoding]::UTF8.GetString($Bytes)
    $nodes = Get-TextNodes -Xml $xml
    if ($nodes.Count -eq 0) { return $Bytes }

    $plainBuilder = [System.Text.StringBuilder]::new()
    $spans = New-Object System.Collections.Generic.List[object]
    $cursor = 0
    foreach ($node in $nodes) {
        $text = if ($null -eq $node.InnerText) { '' } else { $node.InnerText }
        [void]$plainBuilder.Append($text)
        $spans.Add([pscustomobject]@{ Start = $cursor; End = $cursor + $text.Length; Node = $node })
        $cursor += $text.Length
    }

    $matches = [regex]::Matches($plainBuilder.ToString(), '\{[^{}\r\n]{1,80}\}')
    for ($i = $matches.Count - 1; $i -ge 0; $i--) {
        $match = $matches[$i]
        $tag = $match.Value
        if (-not $Values.ContainsKey($tag)) { continue }

        $touched = @($spans | Where-Object { $_.Start -lt $match.Index + $match.Length -and $_.End -gt $match.Index })
        if ($touched.Count -eq 0) { continue }

        $first = $touched[0]
        $last = $touched[$touched.Count - 1]
        $firstText = if ($null -eq $first.Node.InnerText) { '' } else { $first.Node.InnerText }
        $lastText = if ($null -eq $last.Node.InnerText) { '' } else { $last.Node.InnerText }
        $prefixLength = [Math]::Max(0, $match.Index - $first.Start)
        $suffixStart = [Math]::Max(0, ($match.Index + $match.Length) - $last.Start)
        $prefix = $firstText.Substring(0, $prefixLength)
        $suffix = if ($suffixStart -lt $lastText.Length) { $lastText.Substring($suffixStart) } else { '' }

        $first.Node.InnerText = $prefix + [string]$Values[$tag] + $suffix
        $spaceAttr = $xml.CreateAttribute('xml', 'space', $XmlNs)
        $spaceAttr.Value = 'preserve'
        [void]$first.Node.Attributes.SetNamedItem($spaceAttr)

        if ($touched.Count -gt 1) {
            foreach ($item in $touched[1..($touched.Count - 1)]) {
                $item.Node.InnerText = ''
            }
        }
    }

    return ConvertTo-XmlBytes -Xml $xml
}

function New-DocxFromTemplate {
    param(
        [string]$TemplatePath,
        [string]$OutputPath,
        [hashtable]$Values
    )

    $outputDir = Split-Path -Parent $OutputPath
    if (-not (Test-Path -LiteralPath $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir | Out-Null
    }
    if (Test-Path -LiteralPath $OutputPath) {
        Remove-Item -LiteralPath $OutputPath -Force
    }

    $source = [System.IO.Compression.ZipFile]::OpenRead($TemplatePath)
    $target = [System.IO.Compression.ZipFile]::Open($OutputPath, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($entry in $source.Entries) {
            $newEntry = $target.CreateEntry($entry.FullName, [System.IO.Compression.CompressionLevel]::Optimal)
            $inputStream = $entry.Open()
            $memory = New-Object System.IO.MemoryStream
            $inputStream.CopyTo($memory)
            $inputStream.Dispose()
            $bytes = $memory.ToArray()

            if ($entry.FullName -match '^word/(document|header\d+|footer\d+)\.xml$') {
                $bytes = Replace-TagsInXmlBytes -Bytes $bytes -Values $Values
            }

            $outputStream = $newEntry.Open()
            $outputStream.Write($bytes, 0, $bytes.Length)
            $outputStream.Dispose()
        }
    }
    finally {
        $source.Dispose()
        $target.Dispose()
    }
}

$manifest = Get-Manifest
$allTags = @($manifest.Values | ForEach-Object { $_ } | Sort-Object -Unique)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'ออกเอกสารการเบิกจ่าย'
$form.Size = [System.Drawing.Size]::new(980, 720)
$form.MinimumSize = [System.Drawing.Size]::new(860, 620)
$form.StartPosition = 'CenterScreen'

$templateLabel = New-Object System.Windows.Forms.Label
$templateLabel.Text = 'Template'
$templateLabel.Location = [System.Drawing.Point]::new(12, 16)
$templateLabel.Size = [System.Drawing.Size]::new(80, 22)
$form.Controls.Add($templateLabel)

$templateBox = New-Object System.Windows.Forms.TextBox
$templateBox.Text = $DefaultTemplateDir
$templateBox.Location = [System.Drawing.Point]::new(100, 12)
$templateBox.Size = [System.Drawing.Size]::new(740, 24)
$form.Controls.Add($templateBox)

$templateButton = New-Object System.Windows.Forms.Button
$templateButton.Text = 'เลือก'
$templateButton.Location = [System.Drawing.Point]::new(850, 10)
$templateButton.Size = [System.Drawing.Size]::new(90, 28)
$form.Controls.Add($templateButton)

$outputLabel = New-Object System.Windows.Forms.Label
$outputLabel.Text = 'Output'
$outputLabel.Location = [System.Drawing.Point]::new(12, 52)
$outputLabel.Size = [System.Drawing.Size]::new(80, 22)
$form.Controls.Add($outputLabel)

$outputBox = New-Object System.Windows.Forms.TextBox
$outputBox.Text = $DefaultOutputDir
$outputBox.Location = [System.Drawing.Point]::new(100, 48)
$outputBox.Size = [System.Drawing.Size]::new(740, 24)
$form.Controls.Add($outputBox)

$outputButton = New-Object System.Windows.Forms.Button
$outputButton.Text = 'เลือก'
$outputButton.Location = [System.Drawing.Point]::new(850, 46)
$outputButton.Size = [System.Drawing.Size]::new(90, 28)
$form.Controls.Add($outputButton)

$docGroup = New-Object System.Windows.Forms.GroupBox
$docGroup.Text = 'เอกสาร'
$docGroup.Location = [System.Drawing.Point]::new(12, 88)
$docGroup.Size = [System.Drawing.Size]::new(300, 520)
$form.Controls.Add($docGroup)

$checks = [ordered]@{}
$y = 28
foreach ($name in $manifest.Keys) {
    $check = New-Object System.Windows.Forms.CheckBox
    $check.Text = $name
    $check.Checked = $true
    $check.Location = [System.Drawing.Point]::new(12, $y)
    $check.Size = [System.Drawing.Size]::new(270, 24)
    $docGroup.Controls.Add($check)
    $checks[$name] = $check
    $y += 30
}

$fieldPanel = New-Object System.Windows.Forms.Panel
$fieldPanel.Location = [System.Drawing.Point]::new(326, 88)
$fieldPanel.Size = [System.Drawing.Size]::new(614, 520)
$fieldPanel.AutoScroll = $true
$form.Controls.Add($fieldPanel)

$fields = [ordered]@{}
$y = 8
foreach ($tag in $allTags) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $tag.Trim('{}')
    $label.Location = [System.Drawing.Point]::new(8, $y + 4)
    $label.Size = [System.Drawing.Size]::new(190, 22)
    $fieldPanel.Controls.Add($label)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Location = [System.Drawing.Point]::new(210, $y)
    $box.Size = [System.Drawing.Size]::new(360, 24)
    $fieldPanel.Controls.Add($box)
    $fields[$tag] = $box
    $y += 32
}

$generateButton = New-Object System.Windows.Forms.Button
$generateButton.Text = 'สร้างเอกสาร Word'
$generateButton.Location = [System.Drawing.Point]::new(760, 624)
$generateButton.Size = [System.Drawing.Size]::new(180, 34)
$form.Controls.Add($generateButton)

$templateButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.SelectedPath = $templateBox.Text
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $templateBox.Text = $dialog.SelectedPath
    }
})

$outputButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.SelectedPath = $outputBox.Text
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $outputBox.Text = $dialog.SelectedPath
    }
})

$generateButton.Add_Click({
    $missing = @()
    $values = @{}
    foreach ($tag in $fields.Keys) {
        $value = $fields[$tag].Text.Trim()
        if ([string]::IsNullOrWhiteSpace($value)) {
            $missing += $tag.Trim('{}')
        }
        $values[$tag] = $value
    }

    if ($missing.Count -gt 0) {
        [System.Windows.Forms.MessageBox]::Show('กรุณากรอก: ' + (($missing | Select-Object -First 8) -join ', '), 'ข้อมูลยังไม่ครบ') | Out-Null
        return
    }

    $created = 0
    foreach ($name in $checks.Keys) {
        if (-not $checks[$name].Checked) { continue }
        $templatePath = Join-Path $templateBox.Text $name
        if (-not (Test-Path -LiteralPath $templatePath)) {
            [System.Windows.Forms.MessageBox]::Show("ไม่พบ Template`n$templatePath", 'Error') | Out-Null
            return
        }
        $outputPath = Join-Path $outputBox.Text $name
        New-DocxFromTemplate -TemplatePath $templatePath -OutputPath $outputPath -Values $values
        $created += 1
    }

    [System.Windows.Forms.MessageBox]::Show("สร้างเอกสาร $created ไฟล์แล้ว`n$($outputBox.Text)", 'สำเร็จ') | Out-Null
})

[void]$form.ShowDialog()

$ErrorActionPreference = 'Stop'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $csc)) {
    $csc = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
}

$testExe = Join-Path $PSScriptRoot 'GoalAcceptanceTest.exe'
& $csc `
    /codepage:65001 `
    /target:exe `
    /platform:anycpu `
    /out:$testExe `
    /reference:System.IO.Compression.dll `
    /reference:System.IO.Compression.FileSystem.dll `
    /reference:System.Web.Extensions.dll `
    "$PSScriptRoot\TemplateCatalog.cs" `
    "$PSScriptRoot\GoalAcceptanceTest.cs"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $testExe
exit $LASTEXITCODE

from __future__ import annotations

import copy
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


WORD_XML_RE = re.compile(r"^word/(document|header\d+|footer\d+)\.xml$")
TAG_RE = re.compile(r"\{[^{}\r\n]{1,80}\}")
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_NS = "http://www.w3.org/XML/1998/namespace"
ET.register_namespace("w", W_NS)


def _text_nodes(root: ET.Element) -> list[ET.Element]:
    return list(root.iter(f"{{{W_NS}}}t"))


def extract_tags(docx_path: str | Path) -> list[str]:
    tags: set[str] = set()
    with zipfile.ZipFile(docx_path) as docx:
        for name in docx.namelist():
            if not WORD_XML_RE.match(name):
                continue
            root = ET.fromstring(docx.read(name))
            plain = "".join(node.text or "" for node in _text_nodes(root))
            tags.update(match.group(0) for match in TAG_RE.finditer(plain))
    return sorted(tags)


def _replace_in_xml(xml_bytes: bytes, values: dict[str, str]) -> bytes:
    root = ET.fromstring(xml_bytes)
    nodes = _text_nodes(root)
    if not nodes:
        return xml_bytes

    text = "".join(node.text or "" for node in nodes)
    matches = list(TAG_RE.finditer(text))
    if not matches:
        return xml_bytes

    spans: list[tuple[int, int, ET.Element]] = []
    cursor = 0
    for node in nodes:
        value = node.text or ""
        spans.append((cursor, cursor + len(value), node))
        cursor += len(value)

    for match in reversed(matches):
        tag = match.group(0)
        if tag not in values:
            continue
        replacement = values[tag]
        touched = [
            (start, end, node)
            for start, end, node in spans
            if start < match.end() and end > match.start()
        ]
        if not touched:
            continue

        first_start, first_end, first_node = touched[0]
        last_start, last_end, last_node = touched[-1]
        prefix = (first_node.text or "")[: max(0, match.start() - first_start)]
        suffix = (last_node.text or "")[max(0, match.end() - last_start) :]
        first_node.text = prefix + replacement + suffix
        first_node.set(f"{{{XML_NS}}}space", "preserve")
        for _, _, node in touched[1:]:
            node.text = ""

    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def render_docx(template_path: str | Path, output_path: str | Path, values: dict[str, str]) -> None:
    template = Path(template_path)
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    normalized = {key if key.startswith("{") else "{" + key + "}": str(value) for key, value in values.items()}

    with zipfile.ZipFile(template, "r") as source, zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as target:
        for item in source.infolist():
            data = source.read(item.filename)
            if WORD_XML_RE.match(item.filename):
                data = _replace_in_xml(data, normalized)
            target.writestr(copy.copy(item), data)

# ข้อกำหนด Template และ Tag

เอกสารนี้กำหนด contract ระหว่าง Word template, catalog, UI และ DOCX renderer

## Template Contract

แม่แบบที่รองรับต้อง:

- เป็นไฟล์ `.docx`
- เปิดเป็น Open XML ZIP package ได้
- เก็บ placeholder ในรูป `{ชื่อแท็ก}`
- ใช้ Tag ที่มีใน System Tag หรือ Custom Tag catalog
- ไม่มีวงเล็บปีกกาที่ผิดรูป
- รักษาแท็กสำคัญของแม่แบบเดิมเมื่อแก้ revision
- ปิดไฟล์ใน Word ก่อน import, validate หรือ render

## ส่วนของ DOCX ที่ระบบอ่าน

```text
word/document.xml
word/header*.xml
word/footer*.xml
```

ระบบรวมข้อความของ paragraph ก่อนค้นหา Tag จึงรองรับกรณี:

```text
Run 1: {ชื่อ
Run 2: โรงเรียน}
```

แต่ควรพยายามพิมพ์ Tag ให้เป็นข้อความต่อเนื่องและใช้ style เดียวกันใน Word เพื่อให้ง่ายต่อการดูแล

## รูปแบบ Tag

รูปแบบที่ถูกต้อง:

```text
{เลขที่สัญญา}
```

รูปแบบที่ไม่ถูกต้อง:

```text
{เลขที่สัญญา
เลขที่สัญญา}
{{เลขที่สัญญา}}
[เลขที่สัญญา]
{}
{__ชื่อสงวน}
```

## กฎชื่อ Custom Tag

- ต้องมี `{` และ `}` ครบหนึ่งคู่
- ข้อความภายใน 1–80 ตัวอักษร
- ห้ามมีวงเล็บซ้อน
- ห้ามมี `[` หรือ `]`
- ห้ามขึ้นบรรทัดใหม่
- ห้ามขึ้นต้นด้วย `__`
- ห้ามซ้ำ System Tag
- ห้ามซ้ำ Custom Tag อื่นแบบตรงตัว

## Tag Classification

ก่อนเพิ่ม Tag ให้จัดประเภท:

```mermaid
flowchart TD
    A["ข้อมูลใน DOCX"] --> B{"มี System Tag ความหมายเดียวกัน?"}
    B -- "มี" --> C["ใช้ System Tag เดิม"]
    B -- "ไม่มี" --> D{"ผู้ใช้กรอกตรง ๆ ได้?"}
    D -- "ได้" --> E["สร้าง Custom Tag"]
    D -- "ไม่ได้" --> F{"คำนวณ/แปลงจากข้อมูลอื่น?"}
    F -- "ใช่" --> G["เพิ่ม Business Rule + System Tag + Tests"]
    F -- "ไม่ใช่" --> H["ทบทวน requirement กับเจ้าของงาน"]
```

อย่าใช้ Tag เดิมเพียงเพราะชื่อคล้ายกัน ตัวอย่างเช่นคำนำหน้าของผู้รับจ้างและคำนำหน้าของผู้ลงนามเป็นข้อมูลคนละบทบาท

## Custom Tag Data Types

### Text

ข้อมูลหนึ่งบรรทัด เช่น เลขที่สัญญา ชื่อโครงการ หรือรหัสอ้างอิง

### Multiline

รายละเอียดหรือหมายเหตุหลายบรรทัด ควรทดสอบความสูงและ pagination

### Number

ตัวเลขที่ผู้ใช้กรอก ไม่ได้สร้างคำอ่านหรือ formatting ทางการเงินอัตโนมัติ เว้นแต่เพิ่ม business rule

### Date

วันที่เฉพาะของเอกสารใหม่ ต้องยืนยันรูปแบบ output ที่ต้องการ หากต้องแปลงเป็นวันที่ไทยเฉพาะทางควรเพิ่ม test

### Choice

รายการค่าที่กำหนดล่วงหน้า ต้องมีอย่างน้อยหนึ่งตัวเลือก

## Required, Default และ Remember

- `Required`: block การสร้างเมื่อว่างและเอกสารที่เลือกใช้ Tag นี้
- `DefaultValue`: ค่าเริ่มต้นเมื่อฟอร์มสร้างช่อง
- `RememberLastValue`: จำค่าล่าสุดตามกลไกฟอร์ม
- ช่องที่ไม่ Required สามารถแทนด้วยค่าว่างได้

## Template Lifecycle

| Status | ปรากฏหน้าหลัก | ความหมาย |
|---|---|---|
| Draft | ไม่ | สแกนเบื้องต้นผ่าน แต่ยังไม่ทดลองสร้าง |
| Invalid | ไม่ | มี Unknown/Malformed/Missing Tag หรือ render ล้มเหลว |
| Active | ใช่ | ผ่าน preflight และ trial render |

User Template ต้องผ่าน:

```text
Import -> Draft/Invalid -> Validate -> Trial Render -> Active
```

System Template เป็น built-in และถูกล็อก แต่ยังถูกสแกนเพื่อตรวจความเสียหายได้

## Validation Contract

แม่แบบเปิดใช้ได้เมื่อ:

```text
Error is empty
UnknownTags.Count == 0
MalformedPlaceholders.Count == 0
MissingTags.Count == 0
Trial render succeeds
```

### Unknown Tag

Tag รูปถูกต้องแต่ไม่มี definition ต้องสร้าง Custom/System Tag หรือแก้ชื่อใน DOCX

### Malformed Placeholder

วงเล็บหรือรูปแบบไม่สมบูรณ์ ต้องแก้ DOCX

### Missing Tag

Tag ที่เป็น baseline ของแม่แบบเดิมหายไป ใช้ป้องกันการลบข้อมูลสำคัญโดยไม่ตั้งใจ

## Font และ Spacing

Renderer รักษา XML และ style ของต้นฉบับเท่าที่เป็นไปได้ แต่ผู้สร้างแม่แบบต้อง:

- วาง Tag ใน paragraph/cell ที่มี style ถูกต้อง
- ใช้ฟอนต์และขนาดที่รองรับข้อความจริง
- เผื่อความยาวชื่อบุคคล หน่วยงาน และหมายเหตุ
- ตรวจ table row ที่อาจขยาย
- ตรวจ page break
- ตรวจบรรทัดใต้ลายเซ็น
- ทดสอบ Header/Footer

ใช้ตัวอย่างค่าที่สั้นและยาว ไม่ควรทดสอบเฉพาะคำว่า `ทดสอบ`

## Safe Rename

การเปลี่ยนชื่อ Custom Tag ต้อง:

1. ตรวจชื่อใหม่
2. หาแม่แบบที่ใช้ชื่อเดิม
3. แสดง impact
4. สำรอง DOCX
5. rewrite document/header/footer
6. เปลี่ยนแม่แบบที่ได้รับผลกระทบเป็น Draft
7. validate และ activate ใหม่

ห้ามใช้ Search/Replace บน binary `.docx` โดยตรง

## Safe Remove

- System Tag ลบไม่ได้
- Custom Tag ที่ยังถูกใช้งานลบไม่ได้
- User Template นำออกได้โดยเก็บ DOCX หรือย้ายไป recovery
- System Template นำออกไม่ได้
- กลุ่มที่ยังมีเอกสารลบไม่ได้

## Release Packaging Rules

ต้องรวม:

- catalog และ tag baseline
- System Template
- version
- app database
- executable ใน Installer
- source/scripts/tests/docs ใน Source

ห้ามรวม:

- saved user data
- output documents
- recovery/backup
- user-imported confidential templates
- test executable
- temporary screenshot
- compiler output ที่ไม่ใช่ release

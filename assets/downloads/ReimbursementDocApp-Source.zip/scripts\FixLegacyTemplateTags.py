"""Apply the minimal, verified tag corrections to the legacy Word templates.

This script preserves the document structure and formatting by changing only the
text spans that contain the specified placeholders. It creates one backup of the
two source templates before the first in-place update.
"""

from __future__ import annotations

import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from lxml import etree


WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": WORD_NS}


def paragraph_text(paragraph: etree._Element) -> str:
    return "".join(node.text or "" for node in paragraph.xpath(".//w:t", namespaces=NS))


def replace_logical_text(paragraph: etree._Element, old: str, new: str) -> None:
    """Replace one string even when Word split it across multiple w:t nodes."""
    nodes = paragraph.xpath(".//w:t", namespaces=NS)
    full_text = "".join(node.text or "" for node in nodes)
    start = full_text.find(old)
    if start < 0:
        raise ValueError(f"Expected text not found: {old}")
    if full_text.find(old, start + 1) >= 0:
        raise ValueError(f"Expected one occurrence but found multiple: {old}")

    end = start + len(old)
    spans: list[tuple[int, int, etree._Element]] = []
    cursor = 0
    for node in nodes:
        value = node.text or ""
        spans.append((cursor, cursor + len(value), node))
        cursor += len(value)

    touched = [span for span in spans if span[0] < end and span[1] > start]
    if not touched:
        raise ValueError(f"No Word text node matched: {old}")

    first_start, _, first_node = touched[0]
    _, last_end, last_node = touched[-1]
    first_text = first_node.text or ""
    last_text = last_node.text or ""
    prefix = first_text[: max(0, start - first_start)]
    suffix_offset = max(0, end - (last_end - len(last_text)))
    suffix = last_text[suffix_offset:]
    first_node.text = prefix + new + suffix
    first_node.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    for _, _, node in touched[1:]:
        node.text = ""


def replace_by_context(root: etree._Element, context: str, old: str, new: str) -> None:
    matches = [
        paragraph
        for paragraph in root.xpath("//w:p", namespaces=NS)
        if context in paragraph_text(paragraph) and old in paragraph_text(paragraph)
    ]
    if len(matches) != 1:
        raise ValueError(
            f"Expected one paragraph for context {context!r} and tag {old!r}; found {len(matches)}"
        )
    replace_logical_text(matches[0], old, new)


def update_docx(path: Path, mutator) -> None:
    with zipfile.ZipFile(path, "r") as source:
        payload = {entry.filename: source.read(entry.filename) for entry in source.infolist()}

    xml = etree.fromstring(payload["word/document.xml"])
    mutator(xml)
    payload["word/document.xml"] = etree.tostring(
        xml, encoding="UTF-8", xml_declaration=True, standalone=True
    )

    with tempfile.NamedTemporaryFile(delete=False, suffix=".docx", dir=str(path.parent)) as handle:
        temporary_path = Path(handle.name)
    try:
        with zipfile.ZipFile(temporary_path, "w", compression=zipfile.ZIP_DEFLATED) as target:
            for name, content in payload.items():
                target.writestr(name, content)
        temporary_path.replace(path)
    finally:
        temporary_path.unlink(missing_ok=True)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    template_dir = root / "dist" / "Template"
    inspection_template = template_dir / "4. ใบตรวจรับ.docx"
    approval_template = template_dir / "5. บันทึกอนุมัติเบิกจ่าย.docx"
    backup_dir = root / "backup-before-tag-hotfix"

    for path in (inspection_template, approval_template):
        if not path.is_file():
            raise FileNotFoundError(path)

    backup_dir.mkdir(exist_ok=True)
    for path in (inspection_template, approval_template):
        backup = backup_dir / path.name
        if not backup.exists():
            shutil.copy2(path, backup)

    def fix_inspection(root_xml: etree._Element) -> None:
        replace_by_context(root_xml, "ชื่อลูกจ้าง", "{คำนำหน้าชื่อ}", "{คำนำหน้าลูกจ้าง}")
        replace_by_context(root_xml, "ผู้รับจ้างควรได้รับเงินเป้น", "เป้น", "เป็น")

    def fix_approval(root_xml: etree._Element) -> None:
        replace_by_context(root_xml, "ชื่อลูกจ้าง", "{คำนำหน้าชื่อ}", "{คำนำหน้าลูกจ้าง}")
        replace_by_context(root_xml, "ชื่อพัสดุ", "{คำนำหน้าชื่อ}", "{คำนำหน้าพัสดุ}")
        replace_by_context(root_xml, "ชื่อหพัสดุ", "{คำนำหน้าชื่อ}", "{คำนำหน้าหพัสดุ}")
        replace_by_context(root_xml, "ชื่อการเงิน", "{คำนำหน้าชื่อ}", "{คำนำหน้าการเงิน}")
        for paragraph in root_xml.xpath("//w:p", namespaces=NS):
            while "โรงเรียน{ชื่อโรงเรียน}" in paragraph_text(paragraph):
                replace_logical_text(paragraph, "โรงเรียน{ชื่อโรงเรียน}", "{ชื่อโรงเรียน}")

    update_docx(inspection_template, fix_inspection)
    update_docx(approval_template, fix_approval)
    print("Corrected:", inspection_template)
    print("Corrected:", approval_template)
    print("Originals backed up in:", backup_dir)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise

param(
    [string]$OutputFileName = 'ReimbursementDocApp.exe'
)

$ErrorActionPreference = 'Stop'
if ([IO.Path]::GetFileName($OutputFileName) -ne $OutputFileName -or
    -not $OutputFileName.EndsWith('.exe', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'OutputFileName must be a plain .exe file name.'
}
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $csc)) {
    $csc = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
}

$outDir = Join-Path $PSScriptRoot 'dist'
$outputPath = Join-Path $outDir $OutputFileName
if (-not (Test-Path -LiteralPath $outDir)) {
    New-Item -ItemType Directory -Path $outDir | Out-Null
}

& $csc `
    /codepage:65001 `
    /target:winexe `
    /platform:anycpu `
    /win32icon:"$PSScriptRoot\app-icon.ico" `
    /out:$outputPath `
    /reference:System.Windows.Forms.dll `
    /reference:System.Drawing.dll `
    /reference:System.IO.Compression.dll `
    /reference:System.IO.Compression.FileSystem.dll `
    /reference:System.Web.Extensions.dll `
    "$PSScriptRoot\TemplateCatalog.cs" `
    "$PSScriptRoot\TemplateAdminCenter.cs" `
    "$PSScriptRoot\DocumentTemplateDialogs.cs" `
    "$PSScriptRoot\ReimbursementDocApp.cs"

if ($LASTEXITCODE -ne 0) {
    throw "Build failed. Close ReimbursementDocApp.exe if it is currently open, then run the build again."
}

Copy-Item -LiteralPath "$PSScriptRoot\template_tags.json" -Destination "$outDir\template_tags.json" -Force
Copy-Item -LiteralPath "$PSScriptRoot\template_catalog.json" -Destination "$outDir\template_catalog.json" -Force
Copy-Item -LiteralPath "$PSScriptRoot\app_database.json" -Destination "$outDir\app_database.json" -Force
Copy-Item -LiteralPath "$PSScriptRoot\VERSION.txt" -Destination "$outDir\VERSION.txt" -Force
Write-Host "Built: $outputPath"

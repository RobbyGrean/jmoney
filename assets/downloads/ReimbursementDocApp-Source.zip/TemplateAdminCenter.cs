using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ReimbursementDocApp
{
    internal sealed class AdminEntryDialog : Form
    {
        public AdminEntryDialog()
        {
            Text = "เครื่องมือผู้ดูแลแม่แบบ";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(620, 330);
            BackColor = Color.White;
            Font = new Font("Segoe UI", 10f);
            AutoScaleMode = AutoScaleMode.Dpi;

            var banner = new Panel
            {
                Dock = DockStyle.Top,
                Height = 92,
                BackColor = Color.FromArgb(24, 56, 82)
            };
            Controls.Add(banner);
            banner.Controls.Add(new Label
            {
                Text = "เครื่องมือผู้ดูแลแม่แบบ",
                Location = new Point(28, 18),
                Size = new Size(520, 34),
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                ForeColor = Color.White
            });
            banner.Controls.Add(new Label
            {
                Text = "พื้นที่ขั้นสูงสำหรับจัดการโครงสร้างเอกสารและ {tag}",
                Location = new Point(30, 55),
                Size = new Size(520, 24),
                ForeColor = Color.FromArgb(213, 229, 240)
            });

            Controls.Add(new Label
            {
                Text = "คำเตือน",
                Location = new Point(30, 116),
                Size = new Size(120, 26),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(180, 83, 9)
            });
            Controls.Add(new Label
            {
                Text = "การเพิ่ม ลบ หรือกำหนดแท็กผิดอาจทำให้เอกสารสร้างไม่สมบูรณ์\n"
                    + "รายการใหม่จะเริ่มเป็นฉบับร่าง และต้องตรวจสอบก่อนเปิดใช้งาน",
                Location = new Point(30, 148),
                Size = new Size(555, 58),
                ForeColor = Color.FromArgb(51, 65, 85)
            });

            var enter = new Button
            {
                Text = "เข้าสู่โหมดผู้ดูแล",
                Location = new Point(374, 258),
                Size = new Size(210, 42),
                BackColor = Color.FromArgb(31, 94, 140),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                DialogResult = DialogResult.OK
            };
            enter.FlatAppearance.BorderSize = 0;
            Controls.Add(enter);
            Controls.Add(new Button
            {
                Text = "ยกเลิก",
                Location = new Point(268, 258),
                Size = new Size(94, 42),
                FlatStyle = FlatStyle.Flat,
                DialogResult = DialogResult.Cancel
            });
            AcceptButton = enter;
            CancelButton = Controls.OfType<Button>().First(x => x.DialogResult == DialogResult.Cancel);
        }
    }

    internal sealed class TemplateAdminCenterDialog : Form
    {
        private readonly Color Navy = Color.FromArgb(24, 56, 82);
        private readonly Color Primary = Color.FromArgb(31, 94, 140);
        private readonly Color Muted = Color.FromArgb(100, 116, 139);
        private readonly Color Surface = Color.FromArgb(248, 250, 252);
        private readonly string baseDirectory;
        private readonly string templateDirectory;
        private readonly DocumentTemplateCatalog originalCatalog;
        private readonly DocumentTemplateCatalog workingCatalog;
        private readonly List<string> importedFiles = new List<string>();
        private readonly List<string> filesToRemove = new List<string>();
        private readonly List<Tuple<string, string>> renamedFileRollbacks = new List<Tuple<string, string>>();
        private readonly ListBox navigation = new ListBox();
        private readonly Panel content = new Panel();
        private readonly Label pageTitle = new Label();
        private readonly Label pageSubtitle = new Label();
        private readonly Label dirtyLabel = new Label();
        private bool saved;
        private bool dirty;

        public bool IsDirty { get { return saved && dirty; } }

        public TemplateAdminCenterDialog(DocumentTemplateCatalog catalog, string baseDirectory)
        {
            originalCatalog = catalog;
            workingCatalog = TemplateCatalogStore.Clone(catalog);
            this.baseDirectory = baseDirectory;
            templateDirectory = Path.Combine(baseDirectory, "Template");

            Text = "ศูนย์ผู้ดูแลแม่แบบและแท็ก";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(1040, 700);
            Size = new Size(1180, 780);
            BackColor = Surface;
            Font = new Font("Segoe UI", 9.5f);
            KeyPreview = true;
            AutoScaleMode = AutoScaleMode.Dpi;

            BuildShell();
            navigation.SelectedIndex = 0;
            FormClosing += OnAdminClosing;
        }

        private void BuildShell()
        {
            var rail = new Panel { Dock = DockStyle.Left, Width = 225, BackColor = Navy };
            Controls.Add(rail);
            rail.Controls.Add(new Label
            {
                Text = "JMoney Admin",
                Location = new Point(22, 22),
                Size = new Size(180, 32),
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = Color.White
            });
            rail.Controls.Add(new Label
            {
                Text = "เครื่องมือขั้นสูง",
                Location = new Point(24, 57),
                Size = new Size(170, 22),
                ForeColor = Color.FromArgb(186, 210, 226)
            });

            navigation.Location = new Point(14, 105);
            navigation.Size = new Size(197, 250);
            navigation.BorderStyle = BorderStyle.None;
            navigation.BackColor = Navy;
            navigation.ForeColor = Color.White;
            navigation.Font = new Font("Segoe UI", 11f);
            navigation.ItemHeight = 44;
            navigation.Items.AddRange(new object[]
            {
                "ภาพรวม",
                "กลุ่มเอกสาร",
                "แม่แบบเอกสาร",
                "พจนานุกรม Tag",
                "ตรวจสอบและกู้คืน"
            });
            navigation.SelectedIndexChanged += delegate { ShowSelectedPage(); };
            rail.Controls.Add(navigation);
            rail.Controls.Add(new Label
            {
                Text = "System Template และ System Tag\nถูกล็อกเพื่อป้องกันการแก้โดยไม่ตั้งใจ",
                Location = new Point(20, 590),
                Size = new Size(185, 62),
                ForeColor = Color.FromArgb(186, 210, 226)
            });

            var header = new Panel { Dock = DockStyle.Top, Height = 100, BackColor = Color.White };
            Controls.Add(header);
            header.Controls.Add(pageTitle);
            pageTitle.Location = new Point(28, 18);
            pageTitle.Size = new Size(700, 34);
            pageTitle.Font = new Font("Segoe UI", 18f, FontStyle.Bold);
            pageTitle.ForeColor = Navy;
            header.Controls.Add(pageSubtitle);
            pageSubtitle.Location = new Point(30, 57);
            pageSubtitle.Size = new Size(760, 24);
            pageSubtitle.ForeColor = Muted;
            header.Controls.Add(dirtyLabel);
            dirtyLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            dirtyLabel.Location = new Point(header.Width - 210, 34);
            dirtyLabel.Size = new Size(180, 28);
            dirtyLabel.TextAlign = ContentAlignment.MiddleRight;
            dirtyLabel.ForeColor = Color.FromArgb(180, 83, 9);

            var footer = new Panel { Dock = DockStyle.Bottom, Height = 68, BackColor = Color.White };
            Controls.Add(footer);
            var save = PrimaryButton("บันทึกการเปลี่ยนแปลง", 210);
            save.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            save.Location = new Point(footer.Width - 235, 13);
            save.Click += delegate { SaveChanges(); };
            footer.Controls.Add(save);
            var cancel = SecondaryButton("ปิด", 92);
            cancel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            cancel.Location = new Point(footer.Width - 339, 13);
            cancel.Click += delegate { Close(); };
            footer.Controls.Add(cancel);

            content.Dock = DockStyle.Fill;
            content.BackColor = Surface;
            content.Padding = new Padding(26, 22, 26, 22);
            Controls.Add(content);
            content.BringToFront();
        }

        private void ShowSelectedPage()
        {
            content.Controls.Clear();
            switch (navigation.SelectedIndex)
            {
                case 1: ShowGroupsPage(); break;
                case 2: ShowTemplatesPage(); break;
                case 3: ShowTagsPage(); break;
                case 4: ShowDiagnosticsPage(); break;
                default: ShowOverviewPage(); break;
            }
        }

        private void SetHeading(string title, string subtitle)
        {
            pageTitle.Text = title;
            pageSubtitle.Text = subtitle;
        }

        private void ShowOverviewPage()
        {
            SetHeading("ภาพรวมระบบแม่แบบ", "ตรวจสถานะก่อนแก้ไขโครงสร้างเอกสาร");
            var active = workingCatalog.Templates.Count(x => x.Status == TemplateLifecycle.Active);
            var draft = workingCatalog.Templates.Count(x => x.Status == TemplateLifecycle.Draft);
            var invalid = workingCatalog.Templates.Count(x => x.Status == TemplateLifecycle.Invalid);
            AddMetricCard("กลุ่มเอกสาร", workingCatalog.Groups.Count.ToString(), "กลุ่มที่ใช้จัดกระบวนงาน", 0);
            AddMetricCard("พร้อมใช้งาน", active.ToString(), "แสดงในหน้าผู้ใช้ทั่วไป", 1);
            AddMetricCard("ฉบับร่าง", draft.ToString(), "รอตรวจและเปิดใช้งาน", 2);
            AddMetricCard("ต้องแก้ไข", invalid.ToString(), "มีแท็กหรือไฟล์ผิดปกติ", 3);

            var note = new Panel
            {
                Location = new Point(26, 200),
                Size = new Size(content.ClientSize.Width - 52, 150),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            note.Controls.Add(new Label
            {
                Text = "ขั้นตอนที่ปลอดภัย",
                Location = new Point(22, 18),
                Size = new Size(250, 28),
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Navy
            });
            note.Controls.Add(new Label
            {
                Text = "1  นำเข้า DOCX  →  2  กำหนด New Tag  →  3  ตรวจสอบและทดลองสร้าง  →  4  เปิดใช้งาน\n\n"
                    + "รายการใหม่จะไม่ปรากฏในหน้าหลักจนกว่าจะผ่านขั้นตอนเปิดใช้งาน",
                Location = new Point(22, 56),
                Size = new Size(note.Width - 44, 72),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                ForeColor = Color.FromArgb(51, 65, 85)
            });
            content.Controls.Add(note);
        }

        private void AddMetricCard(string title, string value, string note, int index)
        {
            var width = Math.Max(180, (content.ClientSize.Width - 82) / 4);
            var card = new Panel
            {
                Location = new Point(26 + index * (width + 10), 24),
                Size = new Size(width, 136),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            card.Controls.Add(new Label { Text = title, Location = new Point(16, 14), Size = new Size(width - 32, 22), ForeColor = Muted });
            card.Controls.Add(new Label { Text = value, Location = new Point(16, 41), Size = new Size(width - 32, 44), Font = new Font("Segoe UI", 24f, FontStyle.Bold), ForeColor = Navy });
            card.Controls.Add(new Label { Text = note, Location = new Point(16, 94), Size = new Size(width - 32, 30), ForeColor = Muted });
            content.Controls.Add(card);
        }

        private void ShowGroupsPage()
        {
            SetHeading("กลุ่มเอกสาร", "จัดโครงสร้างกระบวนงานและลำดับที่แสดงในหน้าหลัก");
            var list = CreateListView(new[] { "ลำดับ", "ชื่อกลุ่ม", "คำอธิบาย", "เอกสาร" }, new[] { 70, 260, 390, 90 });
            list.Name = "groupList";
            foreach (var group in workingCatalog.Groups.OrderBy(x => x.SortOrder))
            {
                var row = new ListViewItem((group.SortOrder + 1).ToString()) { Tag = group };
                row.SubItems.Add(group.Name);
                row.SubItems.Add(group.Description);
                row.SubItems.Add(workingCatalog.Templates.Count(x => x.GroupId == group.Id).ToString());
                list.Items.Add(row);
            }
            content.Controls.Add(list);
            AddActionBar(new[]
            {
                Action("เพิ่มกลุ่ม", delegate { AddGroup(); }),
                Action("แก้ชื่อ", delegate { EditGroup(list); }),
                Action("เลื่อนขึ้น", delegate { MoveGroup(list, -1); }),
                Action("เลื่อนลง", delegate { MoveGroup(list, 1); }),
                Action("ลบกลุ่ม", delegate { RemoveGroup(list); })
            });
        }

        private void AddGroup()
        {
            using (var prompt = new TextPromptDialog("เพิ่มกลุ่มเอกสาร", "ชื่อกลุ่มเอกสาร", "เช่น กระบวนการทำสัญญา", ""))
            {
                if (prompt.ShowDialog(this) != DialogResult.OK) return;
                if (workingCatalog.Groups.Any(x => string.Equals(x.Name, prompt.Value, StringComparison.CurrentCultureIgnoreCase)))
                {
                    Warn("มีชื่อกลุ่มนี้แล้ว"); return;
                }
                workingCatalog.Groups.Add(new DocumentGroupRecord
                {
                    Id = TemplateCatalogStore.CreateId(),
                    Name = prompt.Value,
                    Description = "",
                    SortOrder = workingCatalog.Groups.Count
                });
                MarkDirty(); ShowGroupsPage();
            }
        }

        private void EditGroup(ListView list)
        {
            var group = Selected<DocumentGroupRecord>(list);
            if (group == null) return;
            using (var prompt = new TextPromptDialog("แก้ไขชื่อกลุ่ม", "ชื่อกลุ่มเอกสาร", "", group.Name))
            {
                if (prompt.ShowDialog(this) != DialogResult.OK) return;
                if (workingCatalog.Groups.Any(x => x != group && string.Equals(x.Name, prompt.Value, StringComparison.CurrentCultureIgnoreCase)))
                {
                    Warn("มีชื่อกลุ่มนี้แล้ว"); return;
                }
                group.Name = prompt.Value; MarkDirty(); ShowGroupsPage();
            }
        }

        private void MoveGroup(ListView list, int delta)
        {
            var group = Selected<DocumentGroupRecord>(list);
            if (group == null) return;
            var ordered = workingCatalog.Groups.OrderBy(x => x.SortOrder).ToList();
            var index = ordered.IndexOf(group);
            var next = index + delta;
            if (next < 0 || next >= ordered.Count) return;
            var other = ordered[next];
            var order = group.SortOrder; group.SortOrder = other.SortOrder; other.SortOrder = order;
            MarkDirty(); ShowGroupsPage();
        }

        private void RemoveGroup(ListView list)
        {
            var group = Selected<DocumentGroupRecord>(list);
            if (group == null) return;
            if (workingCatalog.Groups.Count == 1) { Warn("ต้องมีอย่างน้อยหนึ่งกลุ่มเอกสาร"); return; }
            if (workingCatalog.Templates.Any(x => x.GroupId == group.Id)) { Warn("กลุ่มนี้ยังมีเอกสาร กรุณาย้ายเอกสารก่อนลบ"); return; }
            if (Confirm("ลบกลุ่ม \"" + group.Name + "\" หรือไม่?") != DialogResult.Yes) return;
            workingCatalog.Groups.Remove(group); NormalizeGroupOrder(); MarkDirty(); ShowGroupsPage();
        }

        private void ShowTemplatesPage()
        {
            SetHeading("แม่แบบเอกสาร", "นำเข้า ตรวจสอบ เปิดใช้งาน และนำแม่แบบออกอย่างควบคุม");
            var filter = new ComboBox
            {
                Location = new Point(26, 20), Size = new Size(310, 30), DropDownStyle = ComboBoxStyle.DropDownList
            };
            filter.Items.Add("ทุกกลุ่ม");
            foreach (var group in workingCatalog.Groups.OrderBy(x => x.SortOrder)) filter.Items.Add(group);
            filter.SelectedIndex = 0;
            content.Controls.Add(filter);
            var list = CreateListView(new[] { "สถานะ", "ชื่อที่แสดง", "กลุ่ม", "ไฟล์", "Tag" }, new[] { 100, 250, 190, 260, 60 });
            list.Top = 62;
            list.Height -= 38;
            list.Name = "templateList";
            Action refresh = delegate
            {
                list.Items.Clear();
                var selectedGroup = filter.SelectedItem as DocumentGroupRecord;
                foreach (var template in workingCatalog.Templates.Where(x => selectedGroup == null || x.GroupId == selectedGroup.Id))
                {
                    var group = workingCatalog.Groups.FirstOrDefault(x => x.Id == template.GroupId);
                    var row = new ListViewItem(StatusText(template.Status)) { Tag = template };
                    row.SubItems.Add(template.DisplayName);
                    row.SubItems.Add(group == null ? "-" : group.Name);
                    row.SubItems.Add(template.FileName);
                    row.SubItems.Add(template.Tags.Count.ToString());
                    if (template.Status == TemplateLifecycle.Invalid) row.ForeColor = Color.FromArgb(185, 28, 28);
                    else if (template.Status == TemplateLifecycle.Draft) row.ForeColor = Color.FromArgb(180, 83, 9);
                    list.Items.Add(row);
                }
            };
            filter.SelectedIndexChanged += delegate { refresh(); };
            refresh();
            content.Controls.Add(list);
            AddActionBar(new[]
            {
                Action("นำเข้า DOCX", delegate { ImportTemplate(); }),
                Action("แก้ไข / ย้ายกลุ่ม", delegate { EditTemplate(list); }),
                Action("ตรวจสอบ", delegate { ValidateTemplate(list); }),
                Action("เปิดใช้งาน", delegate { ActivateTemplate(list); }),
                Action("นำออก", delegate { RemoveTemplate(list); }),
                Action("เปิดโฟลเดอร์", delegate { OpenTemplateFolder(); })
            });
        }

        private void ImportTemplate()
        {
            var selectedGroup = workingCatalog.Groups.FirstOrDefault();
            if (selectedGroup == null) { Warn("กรุณาสร้างกลุ่มเอกสารก่อน"); return; }
            using (var picker = new OpenFileDialog
            {
                Title = "เลือกแม่แบบเอกสาร Word",
                Filter = "Word document (*.docx)|*.docx",
                CheckFileExists = true,
                Multiselect = false
            })
            {
                if (picker.ShowDialog(this) != DialogResult.OK) return;
                var customTagsAddedForImport = new List<CustomTagDefinition>();
                var inspection = DocxTemplateInspector.Inspect(
                    picker.FileName,
                    SupportedTagCatalog.Create(workingCatalog).Select(x => x.Tag));
                if (!string.IsNullOrWhiteSpace(inspection.Error)) { Warn(inspection.Error); return; }

                foreach (var tag in inspection.UnknownTags.ToList())
                {
                    var answer = MessageBox.Show(
                        "พบ New Tag " + tag + "\n\nต้องการกำหนดช่องกรอกสำหรับแท็กนี้ตอนนี้หรือไม่?",
                        "กำหนด New Tag",
                        MessageBoxButtons.YesNoCancel,
                        MessageBoxIcon.Question);
                    if (answer == DialogResult.Cancel)
                    {
                        RollbackImportedTagDefinitions(customTagsAddedForImport); return;
                    }
                    if (answer == DialogResult.No) continue;
                    var custom = new CustomTagDefinition
                    {
                        Id = TemplateCatalogStore.CreateId(),
                        Tag = tag,
                        DisplayName = tag.Trim('{', '}'),
                        Category = "ข้อมูลเพิ่มเติม",
                        CreatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss")
                    };
                    using (var editor = new CustomTagEditorDialog(custom, true, workingCatalog))
                    {
                        if (editor.ShowDialog(this) != DialogResult.OK)
                        {
                            RollbackImportedTagDefinitions(customTagsAddedForImport); return;
                        }
                    }
                    workingCatalog.CustomTags.Add(custom);
                    customTagsAddedForImport.Add(custom);
                }

                inspection = DocxTemplateInspector.Inspect(
                    picker.FileName,
                    SupportedTagCatalog.Create(workingCatalog).Select(x => x.Tag));
                using (var import = new TemplateImportDialog(
                    picker.FileName,
                    workingCatalog.Groups,
                    selectedGroup,
                    inspection))
                {
                    if (import.ShowDialog(this) != DialogResult.OK)
                    {
                        RollbackImportedTagDefinitions(customTagsAddedForImport); return;
                    }
                    Directory.CreateDirectory(templateDirectory);
                    var storedName = TemplateCatalogStore.GetUniqueFileName(templateDirectory, Path.GetFileName(picker.FileName));
                    var destination = Path.Combine(templateDirectory, storedName);
                    try
                    {
                        File.Copy(picker.FileName, destination, false);
                        importedFiles.Add(destination);
                        workingCatalog.Templates.Add(new DocumentTemplateRecord
                        {
                            Id = TemplateCatalogStore.CreateId(),
                            GroupId = import.SelectedGroup.Id,
                            FileName = storedName,
                            DisplayName = import.DisplayName,
                            Description = import.Description,
                            Source = "user",
                            CreatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                            Status = inspection.CanGenerate ? TemplateLifecycle.Draft : TemplateLifecycle.Invalid,
                            LastValidatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                            ValidationMessage = inspection.CanGenerate ? "ตรวจ tag ผ่าน • รอทดลองและเปิดใช้งาน" : "ต้องแก้ไข tag ก่อน",
                            Tags = inspection.Tags.ToList()
                        });
                        MarkDirty(); ShowTemplatesPage();
                    }
                    catch
                    {
                        if (File.Exists(destination)) File.Delete(destination);
                        RollbackImportedTagDefinitions(customTagsAddedForImport);
                        throw;
                    }
                }
            }
        }

        private void RollbackImportedTagDefinitions(IEnumerable<CustomTagDefinition> definitions)
        {
            foreach (var definition in definitions.ToList())
            {
                workingCatalog.CustomTags.Remove(definition);
            }
        }

        private void EditTemplate(ListView list)
        {
            var template = Selected<DocumentTemplateRecord>(list);
            if (template == null) return;
            var currentGroup = workingCatalog.Groups.FirstOrDefault(x => x.Id == template.GroupId);
            using (var editor = new TemplatePropertiesDialog(template, workingCatalog.Groups, currentGroup))
            {
                if (editor.ShowDialog(this) != DialogResult.OK) return;
                template.DisplayName = editor.DisplayName;
                template.Description = editor.Description;
                template.GroupId = editor.SelectedGroup.Id;
                MarkDirty(); ShowTemplatesPage();
            }
        }

        private void ValidateTemplate(ListView list)
        {
            var template = Selected<DocumentTemplateRecord>(list);
            if (template == null) return;
            var inspection = TemplateCatalogStore.ValidateTemplate(baseDirectory, workingCatalog, template);
            MarkDirty();
            MessageBox.Show(template.ValidationMessage, inspection.CanGenerate ? "ตรวจสอบผ่าน" : "ต้องแก้ไข", MessageBoxButtons.OK,
                inspection.CanGenerate ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            ShowTemplatesPage();
        }

        private void ActivateTemplate(ListView list)
        {
            var template = Selected<DocumentTemplateRecord>(list);
            if (template == null) return;
            if (string.Equals(template.Source, "built-in", StringComparison.OrdinalIgnoreCase))
            {
                Warn("System Template เปิดใช้งานและถูกล็อกอยู่แล้ว"); return;
            }
            var inspection = TemplateCatalogStore.ActivateTemplate(baseDirectory, workingCatalog, template);
            if (!inspection.CanGenerate)
            {
                Warn(template.ValidationMessage); MarkDirty(); ShowTemplatesPage(); return;
            }
            try
            {
                RunTemplateTrial(template);
                template.Status = TemplateLifecycle.Active;
                template.ValidationMessage = "พร้อมใช้งาน • ผ่านการทดลองสร้าง";
                MarkDirty();
                MessageBox.Show("ตรวจ tag และทดลองสร้างเอกสารผ่านแล้ว", "เปิดใช้งานสำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                template.Status = TemplateLifecycle.Invalid;
                template.ValidationMessage = "ทดลองสร้างไม่ผ่าน: " + ex.Message;
                MarkDirty(); Warn(template.ValidationMessage);
            }
            ShowTemplatesPage();
        }

        private void RunTemplateTrial(DocumentTemplateRecord template)
        {
            var definitions = SupportedTagCatalog.Create(workingCatalog).ToDictionary(x => x.Tag, StringComparer.Ordinal);
            var values = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var tag in template.Tags)
            {
                TagDefinition definition;
                if (!definitions.TryGetValue(tag, out definition)) throw new InvalidDataException("ไม่พบคำจำกัดความของ " + tag);
                values[tag] = string.IsNullOrWhiteSpace(definition.Example) ? "ทดสอบ" : definition.Example;
            }
            var trialFolder = Path.Combine(baseDirectory, "admin-backups", "validation");
            Directory.CreateDirectory(trialFolder);
            var output = Path.Combine(trialFolder, Guid.NewGuid().ToString("N") + ".docx");
            try
            {
                Program.RenderDocx(Path.Combine(templateDirectory, template.FileName), output, values);
            }
            finally
            {
                if (File.Exists(output)) File.Delete(output);
            }
        }

        private void RemoveTemplate(ListView list)
        {
            var template = Selected<DocumentTemplateRecord>(list);
            if (template == null) return;
            if (string.Equals(template.Source, "built-in", StringComparison.OrdinalIgnoreCase))
            {
                Warn("System Template ถูกล็อกและไม่สามารถนำออกได้"); return;
            }
            var answer = MessageBox.Show(
                "นำ \"" + template.DisplayName + "\" ออกจากระบบหรือไม่?\n\n"
                    + "Yes = นำออกและย้ายไฟล์สำเนาไปโฟลเดอร์กู้คืน\n"
                    + "No = นำออกแต่เก็บไฟล์ไว้ใน Template\n"
                    + "Cancel = ยกเลิก",
                "ยืนยันและเลือกวิธีจัดการไฟล์",
                MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Warning);
            if (answer == DialogResult.Cancel) return;
            if (answer == DialogResult.Yes) filesToRemove.Add(Path.Combine(templateDirectory, template.FileName));
            workingCatalog.Templates.Remove(template);
            MarkDirty(); ShowTemplatesPage();
        }

        private void ShowTagsPage()
        {
            SetHeading("พจนานุกรม Tag", "System Tag อ่านอย่างเดียว • Custom Tag จัดการได้พร้อมตรวจผลกระทบ");
            var search = new TextBox { Location = new Point(26, 20), Size = new Size(330, 30) };
            search.Text = "";
            content.Controls.Add(search);
            var typeFilter = new ComboBox { Location = new Point(370, 20), Size = new Size(180, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            typeFilter.Items.AddRange(new object[] { "ทั้งหมด", "System Tag", "Custom Tag" });
            typeFilter.SelectedIndex = 0;
            content.Controls.Add(typeFilter);
            var list = CreateListView(new[] { "ประเภท", "Tag", "ชื่อที่แสดง", "หมวด", "ชนิดข้อมูล", "เอกสาร" }, new[] { 95, 210, 200, 160, 100, 70 });
            list.Top = 62; list.Height -= 38; list.Name = "tagList";
            Action refresh = delegate
            {
                list.Items.Clear();
                var keyword = search.Text.Trim();
                var showSystem = typeFilter.SelectedIndex != 2;
                var showCustom = typeFilter.SelectedIndex != 1;
                if (showSystem)
                {
                    foreach (var definition in SupportedTagCatalog.Create().Where(x => MatchTag(x.Tag, x.DisplayName, keyword)))
                    {
                        AddTagRow(list, "System", definition.Tag, definition.DisplayName, definition.Category, definition.DataType, definition);
                    }
                }
                if (showCustom)
                {
                    foreach (var definition in workingCatalog.CustomTags.Where(x => MatchTag(x.Tag, x.DisplayName, keyword)))
                    {
                        AddTagRow(list, "Custom", definition.Tag, definition.DisplayName, definition.Category, definition.DataType, definition);
                    }
                }
            };
            search.TextChanged += delegate { refresh(); };
            typeFilter.SelectedIndexChanged += delegate { refresh(); };
            refresh(); content.Controls.Add(list);
            AddActionBar(new[]
            {
                Action("เพิ่ม Custom Tag", delegate { AddCustomTag(); }),
                Action("แก้ไข", delegate { EditCustomTag(list); }),
                Action("ลบ", delegate { RemoveCustomTag(list); }),
                Action("ดูเอกสารที่ใช้", delegate { ShowTagUsage(list); })
            });
        }

        private void AddTagRow(ListView list, string kind, string tag, string display, string category, string dataType, object model)
        {
            var row = new ListViewItem(kind) { Tag = model };
            row.SubItems.Add(tag); row.SubItems.Add(display); row.SubItems.Add(category); row.SubItems.Add(dataType);
            row.SubItems.Add(workingCatalog.Templates.Count(x => x.Tags.Contains(tag)).ToString());
            if (kind == "System") row.ForeColor = Muted;
            list.Items.Add(row);
        }

        private void AddCustomTag()
        {
            var custom = new CustomTagDefinition { Id = TemplateCatalogStore.CreateId(), CreatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss") };
            using (var editor = new CustomTagEditorDialog(custom, false, workingCatalog))
            {
                if (editor.ShowDialog(this) != DialogResult.OK) return;
            }
            workingCatalog.CustomTags.Add(custom); MarkDirty(); ShowTagsPage();
        }

        private void EditCustomTag(ListView list)
        {
            var custom = Selected<CustomTagDefinition>(list);
            if (custom == null) { Warn("System Tag เป็นแบบอ่านอย่างเดียว"); return; }
            var oldTag = custom.Tag;
            using (var editor = new CustomTagEditorDialog(custom, false, workingCatalog))
            {
                if (editor.ShowDialog(this) != DialogResult.OK) return;
            }
            if (!string.Equals(oldTag, custom.Tag, StringComparison.Ordinal))
            {
                try
                {
                    RenameCustomTagInDocuments(custom, oldTag, custom.Tag);
                }
                catch (Exception ex)
                {
                    custom.Tag = oldTag;
                    Warn("เปลี่ยนชื่อ Custom Tag ไม่สำเร็จ ระบบคืนไฟล์แม่แบบแล้ว\n\n" + ex.Message);
                    return;
                }
            }
            custom.UpdatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
            MarkDirty(); ShowTagsPage();
        }

        private void RenameCustomTagInDocuments(CustomTagDefinition definition, string oldTag, string newTag)
        {
            var affected = workingCatalog.Templates
                .Where(x => (x.Tags ?? new List<string>()).Contains(oldTag, StringComparer.Ordinal))
                .ToList();
            if (affected.Count == 0) return;
            var impact = string.Join("\n", affected.Take(8).Select(x => "• " + x.DisplayName).ToArray());
            if (Confirm("แท็ก " + oldTag + " ถูกใช้ใน " + affected.Count + " เอกสาร\n\n"
                + impact + "\n\nระบบจะสำรอง DOCX แล้วเปลี่ยนเป็น " + newTag + " ทุกตำแหน่ง ดำเนินการต่อหรือไม่?")
                != DialogResult.Yes)
            {
                throw new OperationCanceledException("ผู้ใช้ยกเลิกการเปลี่ยนชื่อแท็ก");
            }

            var operationFolder = Path.Combine(
                baseDirectory,
                "admin-backups",
                "tag-rename-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6));
            Directory.CreateDirectory(operationFolder);
            var prepared = new List<Tuple<string, string, string>>();
            try
            {
                foreach (var template in affected)
                {
                    var source = Path.Combine(templateDirectory, template.FileName);
                    if (!File.Exists(source)) throw new FileNotFoundException("ไม่พบไฟล์แม่แบบ", source);
                    var backup = UniquePath(Path.Combine(operationFolder, template.FileName));
                    var temporary = source + ".rename-" + Guid.NewGuid().ToString("N") + ".tmp";
                    File.Copy(source, backup, false);
                    Program.RewriteTagInDocx(source, temporary, oldTag, newTag);
                    prepared.Add(Tuple.Create(source, backup, temporary));
                }
                foreach (var item in prepared)
                {
                    File.Copy(item.Item3, item.Item1, true);
                    File.Delete(item.Item3);
                    renamedFileRollbacks.Add(Tuple.Create(item.Item1, item.Item2));
                }
                foreach (var template in affected)
                {
                    template.Tags = template.Tags
                        .Select(x => string.Equals(x, oldTag, StringComparison.Ordinal) ? newTag : x)
                        .Distinct(StringComparer.Ordinal)
                        .ToList();
                    template.Status = TemplateLifecycle.Draft;
                    template.ValidationMessage = "เปลี่ยนชื่อแท็กแล้ว • กรุณาตรวจสอบและเปิดใช้งานใหม่";
                }
            }
            catch
            {
                foreach (var item in prepared)
                {
                    if (File.Exists(item.Item2)) File.Copy(item.Item2, item.Item1, true);
                    if (File.Exists(item.Item3)) File.Delete(item.Item3);
                }
                throw;
            }
        }

        private void RemoveCustomTag(ListView list)
        {
            var custom = Selected<CustomTagDefinition>(list);
            if (custom == null) { Warn("System Tag ถูกล็อกและลบไม่ได้"); return; }
            var used = workingCatalog.Templates.Where(x => x.Tags.Contains(custom.Tag)).ToList();
            if (used.Count > 0)
            {
                Warn("ยังลบไม่ได้ เพราะมี " + used.Count + " เอกสารใช้แท็กนี้:\n" + string.Join("\n", used.Take(6).Select(x => "• " + x.DisplayName).ToArray()));
                return;
            }
            if (Confirm("ลบ " + custom.Tag + " หรือไม่?") != DialogResult.Yes) return;
            workingCatalog.CustomTags.Remove(custom); MarkDirty(); ShowTagsPage();
        }

        private void ShowTagUsage(ListView list)
        {
            if (list.SelectedItems.Count == 0) return;
            var tag = list.SelectedItems[0].SubItems[1].Text;
            var used = workingCatalog.Templates.Where(x => x.Tags.Contains(tag)).Select(x => "• " + x.DisplayName).ToArray();
            MessageBox.Show(used.Length == 0 ? "ยังไม่มีเอกสารใช้แท็กนี้" : string.Join("\n", used), "เอกสารที่ใช้ " + tag, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowDiagnosticsPage()
        {
            SetHeading("ตรวจสอบและกู้คืน", "สแกนแม่แบบทั้งหมด สำรองการตั้งค่า และเปิดพื้นที่กู้คืน");
            var list = CreateListView(new[] { "สถานะ", "เอกสาร", "ผลการตรวจล่าสุด" }, new[] { 110, 300, 520 });
            foreach (var template in workingCatalog.Templates)
            {
                var row = new ListViewItem(StatusText(template.Status)) { Tag = template };
                row.SubItems.Add(template.DisplayName);
                row.SubItems.Add(template.ValidationMessage);
                list.Items.Add(row);
            }
            content.Controls.Add(list);
            AddActionBar(new[]
            {
                Action("สแกนทั้งหมด", delegate { ScanAllTemplates(); }),
                Action("สำรองการตั้งค่า", delegate { BackupConfiguration(); }),
                Action("คืนค่าจากสำรอง", delegate { RestoreConfiguration(); }),
                Action("เปิดโฟลเดอร์กู้คืน", delegate { OpenRecoveryFolder(); })
            });
        }

        private void ScanAllTemplates()
        {
            foreach (var template in workingCatalog.Templates)
            {
                TemplateCatalogStore.ValidateTemplate(baseDirectory, workingCatalog, template);
            }
            MarkDirty(); ShowDiagnosticsPage();
        }

        private void BackupConfiguration()
        {
            try
            {
                var folder = TemplateCatalogStore.CreateConfigurationBackup(baseDirectory);
                MessageBox.Show("สำรองไว้ที่\n" + folder, "สำรองสำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { Warn("สำรองไม่สำเร็จ\n" + ex.Message); }
        }

        private void OpenRecoveryFolder()
        {
            var folder = Path.Combine(baseDirectory, "admin-backups");
            Directory.CreateDirectory(folder);
            Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
        }

        private void RestoreConfiguration()
        {
            var backupRoot = Path.Combine(baseDirectory, "admin-backups");
            Directory.CreateDirectory(backupRoot);
            using (var picker = new OpenFileDialog
            {
                Title = "เลือก template_catalog.json ที่สำรองไว้",
                InitialDirectory = backupRoot,
                Filter = "Template catalog (template_catalog.json)|template_catalog.json",
                CheckFileExists = true,
                Multiselect = false
            })
            {
                if (picker.ShowDialog(this) != DialogResult.OK) return;
                var fullBackupRoot = Path.GetFullPath(backupRoot).TrimEnd(Path.DirectorySeparatorChar)
                    + Path.DirectorySeparatorChar;
                var selected = Path.GetFullPath(picker.FileName);
                if (!selected.StartsWith(fullBackupRoot, StringComparison.OrdinalIgnoreCase))
                {
                    Warn("เพื่อความปลอดภัย เลือกได้เฉพาะไฟล์ในโฟลเดอร์ admin-backups"); return;
                }
                if (Confirm("คืนค่ารายการกลุ่ม แม่แบบ และ Custom Tag จากไฟล์นี้หรือไม่?\n\n"
                    + selected + "\n\nไฟล์ DOCX จะไม่ถูกลบหรือเขียนทับ") != DialogResult.Yes) return;
                try
                {
                    var restored = TemplateCatalogStore.LoadCatalogFile(selected);
                    TemplateCatalogStore.CopyInto(workingCatalog, restored);
                    MarkDirty();
                    ShowDiagnosticsPage();
                    MessageBox.Show("โหลดข้อมูลสำรองเข้าสู่ฉบับแก้ไขแล้ว\nกด “บันทึกการเปลี่ยนแปลง” เพื่อยืนยัน",
                        "พร้อมคืนค่า", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { Warn("เปิดข้อมูลสำรองไม่สำเร็จ\n" + ex.Message); }
            }
        }

        private void SaveChanges()
        {
            if (!dirty) { saved = true; DialogResult = DialogResult.OK; Close(); return; }
            var moved = new List<Tuple<string, string>>();
            try
            {
                TemplateCatalogStore.CreateConfigurationBackup(baseDirectory);
                var recovery = Path.Combine(baseDirectory, "admin-backups", "removed-" + DateTime.Now.ToString("yyyyMMdd-HHmmss"));
                foreach (var source in filesToRemove.Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    if (!File.Exists(source)) continue;
                    Directory.CreateDirectory(recovery);
                    var destination = Path.Combine(recovery, Path.GetFileName(source));
                    destination = UniquePath(destination);
                    File.Move(source, destination);
                    moved.Add(Tuple.Create(source, destination));
                }
                TemplateCatalogStore.Save(baseDirectory, workingCatalog);
                TemplateCatalogStore.CopyInto(originalCatalog, workingCatalog);
                saved = true;
                importedFiles.Clear();
                filesToRemove.Clear();
                renamedFileRollbacks.Clear();
                dirtyLabel.Text = "บันทึกแล้ว";
                dirtyLabel.ForeColor = Color.FromArgb(21, 128, 61);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                foreach (var item in moved)
                {
                    if (File.Exists(item.Item2) && !File.Exists(item.Item1)) File.Move(item.Item2, item.Item1);
                }
                Warn("บันทึกไม่สำเร็จ ระบบย้อนการเปลี่ยนแปลงไฟล์แล้ว\n\n" + ex.Message);
            }
        }

        private void OnAdminClosing(object sender, FormClosingEventArgs args)
        {
            if (saved) return;
            if (dirty && MessageBox.Show("ยังไม่ได้บันทึก ต้องการปิดและยกเลิกการเปลี่ยนแปลงหรือไม่?", "ยกเลิกการเปลี่ยนแปลง", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                args.Cancel = true; return;
            }
            foreach (var file in importedFiles)
            {
                if (File.Exists(file)) File.Delete(file);
            }
            for (var index = renamedFileRollbacks.Count - 1; index >= 0; index--)
            {
                var item = renamedFileRollbacks[index];
                if (File.Exists(item.Item2)) File.Copy(item.Item2, item.Item1, true);
            }
        }

        private void MarkDirty()
        {
            dirty = true;
            dirtyLabel.Text = "มีการเปลี่ยนแปลงที่ยังไม่บันทึก";
            dirtyLabel.ForeColor = Color.FromArgb(180, 83, 9);
        }

        private ListView CreateListView(string[] columns, int[] widths)
        {
            var list = new ListView
            {
                Location = new Point(26, 22),
                Size = new Size(content.ClientSize.Width - 52, content.ClientSize.Height - 104),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                HideSelection = false,
                MultiSelect = false,
                BackColor = Color.White
            };
            for (var i = 0; i < columns.Length; i++) list.Columns.Add(columns[i], widths[i]);
            return list;
        }

        private void AddActionBar(IEnumerable<Button> buttons)
        {
            var bar = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 64,
                Padding = new Padding(26, 10, 10, 10),
                FlowDirection = FlowDirection.LeftToRight,
                BackColor = Surface
            };
            foreach (var button in buttons) bar.Controls.Add(button);
            content.Controls.Add(bar);
            bar.BringToFront();
        }

        private Button Action(string text, EventHandler handler)
        {
            var button = SecondaryButton(text, Math.Max(112, TextRenderer.MeasureText(text, Font).Width + 34));
            button.Click += handler;
            return button;
        }

        private Button PrimaryButton(string text, int width)
        {
            var button = new Button { Text = text, Size = new Size(width, 42), BackColor = Primary, ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            button.FlatAppearance.BorderSize = 0; return button;
        }

        private Button SecondaryButton(string text, int width)
        {
            var button = new Button { Text = text, Size = new Size(width, 42), BackColor = Color.White, ForeColor = Navy, FlatStyle = FlatStyle.Flat };
            button.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225); return button;
        }

        private T Selected<T>(ListView list) where T : class
        {
            return list.SelectedItems.Count == 0 ? null : list.SelectedItems[0].Tag as T;
        }

        private void NormalizeGroupOrder()
        {
            var order = 0;
            foreach (var group in workingCatalog.Groups.OrderBy(x => x.SortOrder)) group.SortOrder = order++;
        }

        private string StatusText(string status)
        {
            if (status == TemplateLifecycle.Active) return "พร้อมใช้งาน";
            if (status == TemplateLifecycle.Invalid) return "ต้องแก้ไข";
            return "ฉบับร่าง";
        }

        private bool MatchTag(string tag, string display, string keyword)
        {
            return keyword.Length == 0
                || (tag ?? "").IndexOf(keyword, StringComparison.CurrentCultureIgnoreCase) >= 0
                || (display ?? "").IndexOf(keyword, StringComparison.CurrentCultureIgnoreCase) >= 0;
        }

        private DialogResult Confirm(string text)
        {
            return MessageBox.Show(text, "ยืนยัน", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        }

        private void Warn(string text)
        {
            MessageBox.Show(text, "ตรวจสอบข้อมูล", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void OpenTemplateFolder()
        {
            Directory.CreateDirectory(templateDirectory);
            Process.Start(new ProcessStartInfo { FileName = templateDirectory, UseShellExecute = true });
        }

        private string UniquePath(string path)
        {
            if (!File.Exists(path)) return path;
            var directory = Path.GetDirectoryName(path);
            var stem = Path.GetFileNameWithoutExtension(path);
            var extension = Path.GetExtension(path);
            var index = 2;
            string candidate;
            do { candidate = Path.Combine(directory, stem + "_" + index++ + extension); } while (File.Exists(candidate));
            return candidate;
        }
    }

    internal sealed class CustomTagEditorDialog : Form
    {
        private readonly CustomTagDefinition definition;
        private readonly DocumentTemplateCatalog catalog;
        private readonly TextBox tagBox = new TextBox();
        private readonly TextBox nameBox = new TextBox();
        private readonly TextBox descriptionBox = new TextBox();
        private readonly TextBox categoryBox = new TextBox();
        private readonly ComboBox typeBox = new ComboBox();
        private readonly TextBox defaultBox = new TextBox();
        private readonly TextBox choicesBox = new TextBox();
        private readonly CheckBox requiredBox = new CheckBox();
        private readonly CheckBox rememberBox = new CheckBox();

        public CustomTagEditorDialog(CustomTagDefinition definition, bool lockTagName, DocumentTemplateCatalog catalog)
        {
            this.definition = definition;
            this.catalog = catalog;
            var existing = catalog != null && catalog.CustomTags != null
                && catalog.CustomTags.Any(x => string.Equals(x.Id, definition.Id, StringComparison.OrdinalIgnoreCase));
            Text = existing ? "แก้ไข Custom Tag" : (lockTagName ? "กำหนดรายละเอียด Custom Tag" : "เพิ่ม Custom Tag");
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            ClientSize = new Size(690, 620);
            BackColor = Color.White;
            Font = new Font("Segoe UI", 9.5f);
            AutoScaleMode = AutoScaleMode.Dpi;

            AddLabel("Tag *", 28, 26); Setup(tagBox, 28, 50, 300); tagBox.Text = definition.Tag; tagBox.ReadOnly = lockTagName;
            AddLabel("ชื่อที่แสดง *", 356, 26); Setup(nameBox, 356, 50, 306); nameBox.Text = definition.DisplayName;
            AddLabel("หมวดข้อมูล *", 28, 92); Setup(categoryBox, 28, 116, 300); categoryBox.Text = definition.Category;
            AddLabel("ประเภทข้อมูล *", 356, 92); Setup(typeBox, 356, 116, 306);
            typeBox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeBox.Items.AddRange(new object[] { "Text", "Multiline", "Number", "Date", "Choice" });
            typeBox.SelectedItem = string.IsNullOrWhiteSpace(definition.DataType) ? "Text" : definition.DataType;
            AddLabel("คำอธิบาย", 28, 158); Setup(descriptionBox, 28, 182, 634); descriptionBox.Height = 70; descriptionBox.Multiline = true; descriptionBox.Text = definition.Description;
            AddLabel("ค่าเริ่มต้น", 28, 270); Setup(defaultBox, 28, 294, 300); defaultBox.Text = definition.DefaultValue;
            AddLabel("ตัวเลือก (หนึ่งรายการต่อบรรทัด)", 356, 270); Setup(choicesBox, 356, 294, 306); choicesBox.Height = 120; choicesBox.Multiline = true; choicesBox.ScrollBars = ScrollBars.Vertical; choicesBox.Text = string.Join(Environment.NewLine, definition.Choices ?? new List<string>());
            requiredBox.Text = "จำเป็นต้องกรอก"; requiredBox.Location = new Point(28, 442); requiredBox.Size = new Size(180, 28); requiredBox.Checked = definition.Required; Controls.Add(requiredBox);
            rememberBox.Text = "จำค่าล่าสุด"; rememberBox.Location = new Point(220, 442); rememberBox.Size = new Size(160, 28); rememberBox.Checked = definition.RememberLastValue; Controls.Add(rememberBox);
            Controls.Add(new Label { Text = "Custom Tag ใช้เป็นข้อมูลเท่านั้น ไม่สามารถรันโค้ด สคริปต์ หรือสูตรได้", Location = new Point(28, 486), Size = new Size(620, 30), ForeColor = Color.FromArgb(100, 116, 139) });

            var save = new Button { Text = "บันทึก", Location = new Point(550, 550), Size = new Size(112, 40), BackColor = Color.FromArgb(31, 94, 140), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            save.FlatAppearance.BorderSize = 0;
            save.Click += delegate { SaveDefinition(); };
            Controls.Add(save);
            var cancel = new Button { Text = "ยกเลิก", Location = new Point(430, 550), Size = new Size(108, 40), DialogResult = DialogResult.Cancel, FlatStyle = FlatStyle.Flat };
            Controls.Add(cancel); CancelButton = cancel; AcceptButton = save;
        }

        private void SaveDefinition()
        {
            var candidate = new CustomTagDefinition
            {
                Id = definition.Id,
                Tag = tagBox.Text.Trim(),
                DisplayName = nameBox.Text.Trim(),
                Description = descriptionBox.Text.Trim(),
                Category = categoryBox.Text.Trim(),
                DataType = typeBox.SelectedItem == null ? "Text" : typeBox.SelectedItem.ToString(),
                DefaultValue = defaultBox.Text.Trim(),
                Required = requiredBox.Checked,
                RememberLastValue = rememberBox.Checked,
                Choices = choicesBox.Lines.Select(x => x.Trim()).Where(x => x.Length > 0)
                    .Distinct(StringComparer.CurrentCultureIgnoreCase).ToList(),
                CreatedAt = definition.CreatedAt,
                UpdatedAt = definition.UpdatedAt
            };
            var error = TagDefinitionRules.Validate(
                candidate,
                SupportedTagCatalog.Create().Select(x => x.Tag),
                catalog.CustomTags);
            if (error.Length > 0)
            {
                MessageBox.Show(error, "ตรวจสอบ Custom Tag", MessageBoxButtons.OK, MessageBoxIcon.Warning); return;
            }
            definition.Tag = candidate.Tag;
            definition.DisplayName = candidate.DisplayName;
            definition.Description = candidate.Description;
            definition.Category = candidate.Category;
            definition.DataType = candidate.DataType;
            definition.DefaultValue = candidate.DefaultValue;
            definition.Required = candidate.Required;
            definition.RememberLastValue = candidate.RememberLastValue;
            definition.Choices = candidate.Choices;
            DialogResult = DialogResult.OK;
        }

        private void AddLabel(string text, int x, int y)
        {
            Controls.Add(new Label { Text = text, Location = new Point(x, y), Size = new Size(260, 22), Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) });
        }

        private void Setup(Control control, int x, int y, int width)
        {
            control.Location = new Point(x, y); control.Size = new Size(width, 28); Controls.Add(control);
        }
    }
}

param(
    [switch]$PublishToSite
)

$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
$dist = Join-Path $root 'dist'
$templateSources = @((Join-Path $dist 'Template'))
$templateSources += (Join-Path $root 'Template')
$templateJson = [IO.File]::ReadAllText((Join-Path $root 'template_tags.json'), [Text.Encoding]::UTF8)
$templateFiles = [regex]::Matches($templateJson, '"([^"]+\.docx)"\s*:') |
    ForEach-Object { $_.Groups[1].Value }
$release = Join-Path $root 'release'
$payload = Join-Path $release 'Payload'
$payloadTemplate = Join-Path $payload 'Template'
$packageRoot = Join-Path $release 'mhs2jm'
$sourceStage = Join-Path $release 'Source'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $csc)) {
    $csc = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
}

powershell -ExecutionPolicy Bypass -File (Join-Path $root 'build-exe.ps1')
if ($LASTEXITCODE -ne 0) {
    throw 'Application build failed.'
}

if (Test-Path -LiteralPath $release) {
    Remove-Item -LiteralPath $release -Recurse -Force
}
New-Item -ItemType Directory -Path $payload -Force | Out-Null
New-Item -ItemType Directory -Path $payloadTemplate -Force | Out-Null

Copy-Item -LiteralPath (Join-Path $dist 'ReimbursementDocApp.exe') -Destination $payload -Force
Copy-Item -LiteralPath (Join-Path $dist 'template_tags.json') -Destination $payload -Force
Copy-Item -LiteralPath (Join-Path $dist 'template_catalog.json') -Destination $payload -Force
Copy-Item -LiteralPath (Join-Path $dist 'app_database.json') -Destination $payload -Force
Copy-Item -LiteralPath (Join-Path $dist 'VERSION.txt') -Destination $payload -Force
Copy-Item -LiteralPath (Join-Path $root 'USER_README_TH.txt') -Destination (Join-Path $release 'README-TH.txt') -Force
foreach ($templateFile in $templateFiles) {
    $source = $null
    foreach ($templateSource in $templateSources) {
        $candidatePath = Join-Path $templateSource $templateFile
        $candidate = Get-Item -LiteralPath $candidatePath -ErrorAction SilentlyContinue
        if ($candidate) {
            $source = $candidate.FullName
            break
        }
    }
    if (-not $source) {
        throw "Template not found: $templateFile"
    }
    Copy-Item -LiteralPath $source -Destination (Join-Path $payloadTemplate (Split-Path $source -Leaf)) -Force
}

& $csc `
    /codepage:65001 `
    /target:winexe `
    /platform:anycpu `
    /win32icon:"$root\app-icon.ico" `
    /out:"$payload\Uninstall ReimbursementDocApp.exe" `
    /reference:System.Windows.Forms.dll `
    "$root\Uninstaller.cs"
if ($LASTEXITCODE -ne 0) {
    throw 'Uninstaller build failed.'
}

& $csc `
    /codepage:65001 `
    /target:winexe `
    /platform:anycpu `
    /win32icon:"$root\app-icon.ico" `
    /out:"$release\ReimbursementDocApp-Setup.exe" `
    /reference:System.Windows.Forms.dll `
    /reference:Microsoft.CSharp.dll `
    "$root\Installer.cs"
if ($LASTEXITCODE -ne 0) {
    throw 'Installer build failed.'
}

New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
Copy-Item -LiteralPath "$release\ReimbursementDocApp-Setup.exe" -Destination $packageRoot -Force
Copy-Item -LiteralPath "$release\README-TH.txt" -Destination $packageRoot -Force
Copy-Item -LiteralPath $payload -Destination $packageRoot -Recurse -Force

Compress-Archive -Path $packageRoot -DestinationPath "$release\ReimbursementDocApp-Installer.zip" -Force

$sourceZip = Join-Path $release 'ReimbursementDocApp-Source.zip'
New-Item -ItemType Directory -Path $sourceStage -Force | Out-Null
$sourceFiles = Get-ChildItem -LiteralPath $root -File -Force | Where-Object {
    ($_.Name -notin @(
        'GoalAcceptanceTest.exe',
        'DocxSmokeTest.exe',
        'InstallerUpgradeTest.exe',
        'tmp-verify-screen.png',
        'ui-before.png'
    )) -and
    ($_.Extension -in @('.cs', '.ps1', '.py', '.json', '.md', '.txt', '.ico', '.png'))
}
Copy-Item -LiteralPath $sourceFiles.FullName -Destination $sourceStage -Force

# Keep the canonical handoff and the npx installer source inside every
# published Source ZIP. Prefer files already inside an extracted source
# package, then fall back to the repository-level canonical copies.
$repositoryRoot = Split-Path -Parent $root
$handoffDirectorySource = @(
    (Join-Path $root 'Handof6steps'),
    (Join-Path $repositoryRoot 'Handof6steps')
) | Where-Object { Test-Path -LiteralPath $_ -PathType Container } | Select-Object -First 1
if ($handoffDirectorySource) {
    $sourceHandoffDirectory = Join-Path $sourceStage 'Handof6steps'
    New-Item -ItemType Directory -Path $sourceHandoffDirectory -Force | Out-Null
    Get-ChildItem -LiteralPath $handoffDirectorySource -File -Filter '*.md' |
        Copy-Item -Destination $sourceHandoffDirectory -Force
}

$npmInstallerSource = @(
    (Join-Path $root 'npm-installer'),
    (Join-Path $repositoryRoot 'npm-installer')
) | Where-Object { Test-Path -LiteralPath $_ -PathType Container } | Select-Object -First 1
if ($npmInstallerSource) {
    $sourceNpmInstaller = Join-Path $sourceStage 'npm-installer'
    New-Item -ItemType Directory -Path $sourceNpmInstaller -Force | Out-Null
    foreach ($npmFile in @('package.json', 'releases.json', 'README.md')) {
        $npmFileSource = Join-Path $npmInstallerSource $npmFile
        if (Test-Path -LiteralPath $npmFileSource -PathType Leaf) {
            Copy-Item -LiteralPath $npmFileSource -Destination $sourceNpmInstaller -Force
        }
    }
    foreach ($npmDirectory in @('bin', 'lib', 'test')) {
        $npmDirectorySource = Join-Path $npmInstallerSource $npmDirectory
        if (Test-Path -LiteralPath $npmDirectorySource -PathType Container) {
            $sourceNpmDirectory = Join-Path $sourceNpmInstaller $npmDirectory
            New-Item -ItemType Directory -Path $sourceNpmDirectory -Force | Out-Null
            Get-ChildItem -LiteralPath $npmDirectorySource -File -Filter '*.js' |
                Copy-Item -Destination $sourceNpmDirectory -Force
        }
    }
}

$sourceDist = Join-Path $sourceStage 'dist'
$sourceDistTemplate = Join-Path $sourceDist 'Template'
New-Item -ItemType Directory -Path $sourceDistTemplate -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $dist 'template_tags.json') -Destination $sourceDist -Force
Copy-Item -LiteralPath (Join-Path $dist 'template_catalog.json') -Destination $sourceDist -Force
Copy-Item -LiteralPath (Join-Path $dist 'app_database.json') -Destination $sourceDist -Force
Copy-Item -LiteralPath (Join-Path $dist 'VERSION.txt') -Destination $sourceDist -Force
foreach ($templateFile in $templateFiles) {
    Copy-Item -LiteralPath (Join-Path $payloadTemplate $templateFile) -Destination $sourceDistTemplate -Force
}
Compress-Archive -Path (Join-Path $sourceStage '*') -DestinationPath $sourceZip -Force

$siteDownloads = Join-Path $root 'jmoney-repo\assets\downloads'
if ($PublishToSite -and (Test-Path -LiteralPath $siteDownloads)) {
    Copy-Item -LiteralPath "$release\ReimbursementDocApp-Installer.zip" -Destination $siteDownloads -Force
    Copy-Item -LiteralPath $sourceZip -Destination $siteDownloads -Force
    $siteReadme = Get-ChildItem -LiteralPath $siteDownloads -File |
        Where-Object { $_.Name -like 'README-*.txt' } |
        Select-Object -First 1
    if ($siteReadme) {
        Copy-Item -LiteralPath "$root\USER_README_TH.txt" -Destination $siteReadme.FullName -Force
    }
}

Write-Host "Installer folder built: $release"
Write-Host "Send this zip: $release\ReimbursementDocApp-Installer.zip"
Write-Host "Source zip: $sourceZip"
if (-not $PublishToSite) {
    Write-Host "Local build only. Nothing was copied to site downloads."
}

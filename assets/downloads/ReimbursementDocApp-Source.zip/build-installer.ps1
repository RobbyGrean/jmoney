$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
$dist = Join-Path $root 'dist'
$templateSource = Join-Path $dist 'Template'
$templateJsonPath = Join-Path $root 'template_tags.json'
$release = Join-Path $root 'release'
$payload = Join-Path $release 'Payload'
$payloadTemplate = Join-Path $payload 'Template'
$packageRoot = Join-Path $release 'mhs2jm'
$sourceStage = Join-Path $release 'source-package'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'

if (-not (Test-Path -LiteralPath $csc)) {
    $csc = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path -LiteralPath $csc)) {
    throw 'C# compiler (.NET Framework csc.exe) was not found.'
}
if (-not (Test-Path -LiteralPath $templateSource)) {
    throw "Canonical template folder not found: $templateSource"
}

$templateJson = [IO.File]::ReadAllText($templateJsonPath, [Text.Encoding]::UTF8)
$templateFiles = [regex]::Matches($templateJson, '"([^"]+\.docx)"\s*:') |
    ForEach-Object { $_.Groups[1].Value } |
    Select-Object -Unique
if ($templateFiles.Count -eq 0) {
    throw 'No template files were found in template_tags.json.'
}

& powershell -ExecutionPolicy Bypass -File (Join-Path $root 'build-exe.ps1')
if ($LASTEXITCODE -ne 0) {
    throw 'Application build failed.'
}

# This script may clear only its own release folder, never a discovered external folder.
if (Test-Path -LiteralPath $release) {
    $resolvedRelease = (Resolve-Path -LiteralPath $release).Path
    $expectedRelease = [IO.Path]::GetFullPath($release)
    if (-not [string]::Equals($resolvedRelease, $expectedRelease, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to clear an unexpected release folder: $resolvedRelease"
    }
    Remove-Item -LiteralPath $release -Recurse -Force
}

New-Item -ItemType Directory -Path $payloadTemplate -Force | Out-Null
foreach ($file in @('ReimbursementDocApp.exe', 'template_tags.json', 'app_database.json')) {
    Copy-Item -LiteralPath (Join-Path $dist $file) -Destination $payload -Force
}
Copy-Item -LiteralPath (Join-Path $root 'USER_README_TH.txt') -Destination (Join-Path $release 'README-TH.txt') -Force

foreach ($templateFile in $templateFiles) {
    $source = Join-Path $templateSource $templateFile
    if (-not (Test-Path -LiteralPath $source)) {
        throw "Template declared in template_tags.json was not found: $templateFile"
    }
    Copy-Item -LiteralPath $source -Destination (Join-Path $payloadTemplate $templateFile) -Force
}

& $csc /nologo /codepage:65001 /target:winexe /platform:anycpu /win32icon:"$root\app-icon.ico" /out:"$payload\Uninstall ReimbursementDocApp.exe" /reference:System.Windows.Forms.dll "$root\Uninstaller.cs"
if ($LASTEXITCODE -ne 0) { throw 'Uninstaller build failed.' }

& $csc /nologo /codepage:65001 /target:winexe /platform:anycpu /win32icon:"$root\app-icon.ico" /out:"$release\ReimbursementDocApp-Setup.exe" /reference:System.Windows.Forms.dll /reference:Microsoft.CSharp.dll "$root\Installer.cs"
if ($LASTEXITCODE -ne 0) { throw 'Installer build failed.' }

New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $release 'ReimbursementDocApp-Setup.exe') -Destination $packageRoot -Force
Copy-Item -LiteralPath (Join-Path $release 'README-TH.txt') -Destination $packageRoot -Force
Copy-Item -LiteralPath $payload -Destination $packageRoot -Recurse -Force
Compress-Archive -Path $packageRoot -DestinationPath (Join-Path $release 'ReimbursementDocApp-Installer.zip') -Force

# Build a clean, reproducible source archive. Runtime data, generated documents,
# backups and temporary QA files are deliberately excluded from a public release.
New-Item -ItemType Directory -Path $sourceStage -Force | Out-Null
$sourceFiles = @(
    'app.py', 'app_database.json', 'app-icon.ico', 'app-icon.png',
    'build-exe.ps1', 'build-installer.ps1', 'document_generator.py',
    'DocxSmokeTest.cs', 'HANDOFF.md', 'Installer.cs', 'README.md',
    'ReimbursementDocApp.cs', 'Start-ReimbursementApp.ps1',
    'template_tags.json', 'Uninstaller.cs', 'USER_README_TH.txt'
)
foreach ($file in $sourceFiles) {
    $source = Join-Path $root $file
    if (Test-Path -LiteralPath $source) {
        Copy-Item -LiteralPath $source -Destination (Join-Path $sourceStage $file) -Force
    }
}

New-Item -ItemType Directory -Path (Join-Path $sourceStage 'dist\Template') -Force | Out-Null
foreach ($templateFile in $templateFiles) {
    $sourceTemplateDestination = Join-Path (Join-Path $sourceStage 'dist\Template') $templateFile
    Copy-Item -LiteralPath (Join-Path $templateSource $templateFile) -Destination $sourceTemplateDestination -Force
}

New-Item -ItemType Directory -Path (Join-Path $sourceStage 'scripts') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $root 'scripts\FixLegacyTemplateTags.py') -Destination (Join-Path $sourceStage 'scripts') -Force
if (Test-Path -LiteralPath (Join-Path $root '.tours')) {
    Copy-Item -LiteralPath (Join-Path $root '.tours') -Destination $sourceStage -Recurse -Force
}
Compress-Archive -Path (Join-Path $sourceStage '*') -DestinationPath (Join-Path $release 'ReimbursementDocApp-Source.zip') -Force

Write-Host "Installer folder built: $release"
Write-Host "Installer ZIP: $(Join-Path $release 'ReimbursementDocApp-Installer.zip')"
Write-Host "Source ZIP: $(Join-Path $release 'ReimbursementDocApp-Source.zip')"

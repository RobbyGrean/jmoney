# ReimbursementDocApp 2.0.0

WinForms desktop app สำหรับกรอกข้อมูลครั้งเดียวและสร้างเอกสารสำนักงานหลายฉบับจาก Word template แบบออฟไลน์

## ความสามารถ

- สร้างเอกสาร `.docx` โดยใช้ layout ของต้นฉบับเป็น source of truth
- แทนค่า `{tag}` ใน document, Header และ Footer รวมถึงแท็กที่ถูกแบ่งเป็นหลาย Word run
- จัดกลุ่มเอกสารและเลือกสร้างเฉพาะเอกสารที่ต้องการ
- นำเข้าแม่แบบจาก Windows File Picker โดยคัดลอกต้นฉบับเข้า `Template`
- ใช้วงจร ฉบับร่าง → ตรวจสอบ → เปิดใช้งาน สำหรับแม่แบบใหม่
- สร้าง Custom Tag ชนิด Text, Multiline, Number, Date และ Choice
- สร้างช่องกรอกบนฟอร์มตามแท็กของเอกสารที่เลือก
- ตรวจ unknown/malformed/missing tag ก่อนเปิดใช้งานแม่แบบ
- เปลี่ยนชื่อ Custom Tag พร้อม impact preview, DOCX backup และ rollback
- บันทึก catalog/manifest แบบ atomic และมีพื้นที่ `admin-backups`

เครื่องมือแม่แบบอยู่หลังปุ่ม `ตั้งค่า` และมีคำเตือนก่อนเข้า เพื่อไม่ให้ผู้ใช้ทั่วไปแก้โครงสร้างระบบโดยไม่ตั้งใจ

## Build และทดสอบ

รันจาก Windows PowerShell ในโฟลเดอร์ source:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-exe.ps1
powershell -ExecutionPolicy Bypass -File .\run-acceptance-tests.ps1
powershell -ExecutionPolicy Bypass -File .\run-installer-tests.ps1
powershell -ExecutionPolicy Bypass -File .\build-installer.ps1
```

ผลที่คาดหวัง:

- Acceptance tests ผ่าน 46 รายการ
- Installer tests ผ่าน 19 รายการ
- แพ็กเกจอยู่ที่ `release\ReimbursementDocApp-Installer.zip` และ `release\ReimbursementDocApp-Source.zip`

Build script ใช้ compiler ที่มากับ Windows/.NET Framework และสร้าง release ในเครื่องเท่านั้น เว้นแต่เรียก `build-installer.ps1 -PublishToSite` อย่างชัดเจน

## การติดตั้งและอัปเกรด

1. แตก `ReimbursementDocApp-Installer.zip`
2. เปิด `ReimbursementDocApp-Setup.exe`
3. โปรแกรมติดตั้งที่ `%LOCALAPPDATA%\ReimbursementDocApp`
4. เปิดจาก Desktop หรือ Start Menu

เมื่อติดตั้งทับ ตัวติดตั้งจะรักษา:

- `saved_templates.json`
- เอกสารใน `output`
- แม่แบบที่ผู้ใช้เพิ่มเอง
- catalog, กลุ่ม และ Custom Tag ของการติดตั้งรุ่นใหม่

ไฟล์ระบบและแม่แบบมาตรฐานที่ถูกแทนที่จะมีสำเนาใน `admin-backups/installer-upgrade-*`

## โครงสร้าง runtime

```text
%LOCALAPPDATA%\ReimbursementDocApp\
  ReimbursementDocApp.exe
  VERSION.txt
  app_database.json
  template_catalog.json
  template_manifest.json
  template_tags.json
  saved_templates.json
  Template\
  output\
  admin-backups\
  Uninstall ReimbursementDocApp.exe
```

แอปมองหา `Template` ข้าง executable และสร้างไฟล์สำเร็จใน `output`

## ข้อกำหนดด้านเอกสาร

- ใช้ `.docx` เดิมเพื่อรักษาหน้ากระดาษ ตาราง ฟอนต์ ระยะบรรทัด และตำแหน่ง
- trim ค่าก่อนแทนแท็ก
- จัดข้อความใต้ลายเซ็นที่กำหนดให้กึ่งกลาง
- `{วันที่สั่งจ้าง}` รองรับ `dd/MM/yyyy` และ `yyyy-MM-dd` ก่อนแปลงเป็นวันที่ไทย
- ต.ค.–ธ.ค. ใช้ปีงบประมาณ พ.ศ. + 1; ม.ค.–ก.ย. ใช้ปี พ.ศ. ปัจจุบัน
- `{ปีใบสั่งจ้าง}` อิงปีงบประมาณ
- ต.ค. เป็นงวด 1 และ ก.ย. เป็นงวด 12

System Tag จาก `template_tags.json` เป็นแบบอ่านอย่างเดียว Custom Tag สร้างและบริหารผ่านศูนย์ผู้ดูแล

## ถอนการติดตั้ง

เปิด `Uninstall ReimbursementDocApp` จาก Start Menu ตัวถอนการติดตั้งจำกัดเป้าหมายไว้ที่โฟลเดอร์และ shortcut ของแอปเท่านั้น

ดูรายละเอียดรุ่นนี้ใน [RELEASE_NOTES.md](./RELEASE_NOTES.md) และคู่มือผู้ใช้ใน `USER_README_TH.txt`

## คู่มือต่อยอดระบบ

- [DEVELOPER_GUIDE_TH.md](./DEVELOPER_GUIDE_TH.md) — แนวทางใช้ Source เป็นฐานสร้างระบบเอกสารอื่น
- [CODEX_STARTER_PROMPT_TH.md](./CODEX_STARTER_PROMPT_TH.md) — Prompt ตั้งต้นสำหรับสั่ง Codex ส่วนตัว
- [TEMPLATE_AND_TAG_SPEC_TH.md](./TEMPLATE_AND_TAG_SPEC_TH.md) — Contract ของ DOCX, Tag, lifecycle และ packaging
- [EXTENSION_EXAMPLE_TH.md](./EXTENSION_EXAMPLE_TH.md) — ตัวอย่างเพิ่มกลุ่มกระบวนการทำสัญญาและเอกสาร 11 แบบ

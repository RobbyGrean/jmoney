# Local Reimbursement Document App

แอพ local สำหรับกรอกข้อมูลครั้งเดียว แล้วออกเอกสารเบิกจ่ายจาก Word template ทั้ง 5 ไฟล์

## วิธีใช้

## แจกจ่ายให้ผู้ใช้

ส่งไฟล์นี้ให้ผู้ใช้:

```text
release\ReimbursementDocApp-Installer.zip
```

วิธีใช้สำหรับผู้รับ:

1. แตก zip
2. เปิด `ReimbursementDocApp-Setup.exe`
3. โปรแกรมจะติดตั้งไปที่ `%LOCALAPPDATA%\ReimbursementDocApp`
4. installer จะสร้าง shortcut โปรแกรมหลักที่ Desktop และ Start Menu
5. installer จะสร้าง shortcut ถอนการติดตั้งไว้ใน Start Menu

ถ้าต้อง build installer ใหม่:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-installer.ps1
```

เปิด exe สำหรับทดสอบในเครื่อง dev ได้โดยตรง:

```text
dist\ReimbursementDocApp.exe
```

หรือใช้ PowerShell prototype:

```powershell
powershell -ExecutionPolicy Bypass -File .\Start-ReimbursementApp.ps1
```

ค่าเริ่มต้นของ template คือ `C:\Users\MSI\Desktop\Template` และไฟล์ที่สร้างจะอยู่ใน `output`

> มีไฟล์ Python prototype ให้ด้วย แต่เครื่องนี้ยังไม่มี Python runtime จริง จึงให้ `.exe` และ PowerShell app เป็นทางหลักสำหรับใช้งานทันที

## Path ที่สำคัญ

สำหรับเครื่องผู้ใช้จริง path สำคัญมาก จึงไม่ควรพึ่ง `C:\Users\MSI\...`

หลังติดตั้งแล้ว โครงสร้างจะเป็น:

```text
%LOCALAPPDATA%\ReimbursementDocApp\
  ReimbursementDocApp.exe
  template_tags.json
  Template\
    *.docx
  output\
  Uninstall ReimbursementDocApp.exe
```

แอพจะมองหา `Template` ที่อยู่ข้าง exe ก่อน ทำให้ย้ายไปใช้ในเครื่องคนอื่นได้โดยไม่ต้องแก้ path รายเครื่อง

## ถอนการติดตั้ง

เปิด `Uninstall ReimbursementDocApp` จาก Start Menu หรือรันไฟล์นี้:

```text
%LOCALAPPDATA%\ReimbursementDocApp\Uninstall ReimbursementDocApp.exe
```

ตัวถอนการติดตั้งมี guard กันพลาด:

- ลบเฉพาะ `%LOCALAPPDATA%\ReimbursementDocApp`
- ลบเฉพาะ shortcut `ReimbursementDocApp.lnk` บน Desktop
- ลบเฉพาะ shortcut ของแอพใน Start Menu
- ไม่ลบโฟลเดอร์อื่นใน `C:\`

## แนวทางเทคนิค

- ใช้ `.docx` เดิมเป็น source of truth เพื่อรักษาหน้ากระดาษ ตาราง ฟอนต์ ระยะบรรทัด และตำแหน่งข้อความ
- แทนค่า `{tag}` ใน XML ของ Word เฉพาะ `document.xml`, header, footer
- รองรับ tag ที่ Word แยกเป็นหลาย run เช่น `{คำนำหน้า` + `ลูกจ้าง}`
- หลังแทนค่า แอพจะจัด paragraph ของชื่อในวงเล็บและตำแหน่งใต้ลายเซ็นให้เป็นกึ่งกลาง เพื่อให้ชื่อ/ตำแหน่งอยู่ใต้ลายเซ็นเสมอ
- ไม่พึ่ง Google Sheet, Google Docs, Apps Script, Python package, Node package หรือ .NET CLI

## Output Contract

- Result document สำคัญกว่าหน้าฟอร์ม
- แอพต้องไม่สร้าง layout ใหม่เอง ให้ใช้ layout จาก Word template เป็นหลัก
- ข้อมูลต้องไม่ทำให้ฟอร์มเลื่อนหรือบรรทัดพัง
- ชื่อและตำแหน่งใต้ลายเซ็นต้องอยู่กึ่งกลางเสมอ

## UI และคำเตือนที่ย้ายมาจาก index เดิม

- แยกหน้าจอเป็นกลุ่ม: path, ปีงบประมาณ, เอกสารที่จะสร้าง, และแท็บข้อมูล
- ช่องที่ระบบคำนวณเอง เช่น เดือนส่งมอบ, ย่อเดือน, ปีใบสั่งจ้าง เป็น read-only
- ถ้าข้อมูลไม่ครบ แอพจะแสดงข้อความเตือนและ mark ช่องที่ต้องกรอก
- ก่อนสร้างเอกสารมีหน้าต่าง preview/confirm สรุปเดือนส่งมอบ ปีงบประมาณ จำนวนเอกสาร และ output path
- ระหว่างสร้างเอกสารมีสถานะ "กำลังสร้าง..." บน header
- มีกล่อง checklist เตือนตรวจเดือน/ปีงบประมาณ และให้ปิด Word ก่อน generate หากแก้ template

## Logic ที่ย้ายมาจาก Google Apps Script เดิม

- trim ค่าทุกช่องก่อนแทน `{tag}`
- `{วันที่สั่งจ้าง}` รองรับการกรอกแบบ `dd/MM/yyyy`, `yyyy-MM-dd` แล้วแปลงเป็นวันที่ไทย เช่น `1 ตุลาคม 2569`
- `{โซนหัวหน้าการเงิน}` เป็น optional ถ้าไม่กรอกจะแทนเป็นค่าว่าง
- ตั้งชื่อไฟล์ output เป็น `ชื่อเอกสาร_ชื่อลูกจ้าง_ชื่อโรงเรียน.docx` เพื่อลดการเขียนทับไฟล์เดิม
- ยังไม่ย้าย Google Drive ID, Spreadsheet DROP, Committee sheet เพราะแอพ local ไม่ควรผูกกับ Google account โดยตรง

## ปีงบประมาณ

แอพคำนวณปีงบประมาณจากเดือนส่งมอบ:

- ต.ค. ถึง ธ.ค. ใช้ปีงบประมาณ = ปี พ.ศ. + 1
- ม.ค. ถึง ก.ย. ใช้ปีงบประมาณ = ปี พ.ศ.
- `{ปีใบสั่งจ้าง}` อิงตามปีงบประมาณ ไม่ใช่ปีของวันที่สั่งจ้าง
- ต.ค. คือ งวดที่ 1 และ ก.ย. คือ งวดที่ 12

## Grill / Forcing Questions

ก่อนพัฒนาเป็นเวอร์ชัน production ควรล็อกคำตอบเหล่านี้:

1. ใครเป็นผู้ใช้หลัก: ธุรการโรงเรียนคนเดียว, หลายโรงเรียน, หรือส่วนกลาง?
2. ต้องเก็บประวัติรายการเบิกย้อนหลังหรือแค่ออกเอกสารครั้งต่อครั้ง?
3. ข้อมูลบุคคล เช่น ผอ., พัสดุ, การเงิน, กรรมการ ต้องจำค่าเดิมและเลือกซ้ำได้หรือไม่?
4. ต้องเปิดเอกสารให้ตรวจใน Word ก่อนบันทึก PDF หรือ output เป็น `.docx` พอ?
5. ตัวเลขเงินเดือนควรให้ระบบแปลง `เงินเดือนTEXT` อัตโนมัติหรือให้ผู้ใช้กรอกเอง?
6. ต้องรองรับ template หลายชุด/หลายปีงบประมาณหรือไม่?
7. เกณฑ์สำเร็จที่วัดได้: generate 5 ไฟล์ในกี่วินาที, tag ต้องเหลือ 0, และ layout ต้องเทียบกับ template ผ่านการตรวจใน Word กี่ครั้ง?

## Tags ที่พบ

รวมทั้งหมด 29 tag จาก 5 template ดูรายละเอียดใน `template_tags.json`

## ข้อควรแก้ใน Template

พบ split tag ในไฟล์:

- `3. ใบส่งมอบงาน.docx`
- `4. ใบตรวจรับ.docx`
- `8. ใบสำคัญรับเงิน.docx`

แอพรองรับกรณีนี้แล้ว แต่ระยะยาวควร normalize template โดยลบ tag นั้นแล้วพิมพ์ใหม่ใน Word ให้ tag ทั้งก้อนอยู่ใน style/run เดียวกัน

from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from document_generator import render_docx


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_TEMPLATE_DIR = Path(r"C:\Users\MSI\Desktop\Template")
DEFAULT_OUTPUT_DIR = BASE_DIR / "output"
TAG_MANIFEST = BASE_DIR / "template_tags.json"


class ReimbursementApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("ออกเอกสารการเบิกจ่าย")
        self.geometry("980x720")
        self.minsize(860, 620)

        self.template_dir = tk.StringVar(value=str(DEFAULT_TEMPLATE_DIR))
        self.output_dir = tk.StringVar(value=str(DEFAULT_OUTPUT_DIR))
        self.fields: dict[str, tk.StringVar] = {}
        self.templates = self._load_manifest()
        self.selected_templates: dict[str, tk.BooleanVar] = {}

        self._build()

    def _load_manifest(self) -> dict[str, list[str]]:
        with TAG_MANIFEST.open("r", encoding="utf-8") as f:
            return json.load(f)

    @property
    def all_tags(self) -> list[str]:
        tags = {tag for values in self.templates.values() for tag in values}
        return sorted(tags)

    def _build(self) -> None:
        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        top = ttk.Frame(root)
        top.pack(fill="x")
        ttk.Label(top, text="Template").grid(row=0, column=0, sticky="w")
        ttk.Entry(top, textvariable=self.template_dir).grid(row=0, column=1, sticky="ew", padx=8)
        ttk.Button(top, text="เลือก", command=self._choose_template_dir).grid(row=0, column=2)
        ttk.Label(top, text="Output").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.output_dir).grid(row=1, column=1, sticky="ew", padx=8, pady=(8, 0))
        ttk.Button(top, text="เลือก", command=self._choose_output_dir).grid(row=1, column=2, pady=(8, 0))
        top.columnconfigure(1, weight=1)

        body = ttk.PanedWindow(root, orient="horizontal")
        body.pack(fill="both", expand=True, pady=12)

        left = ttk.Frame(body, padding=(0, 0, 10, 0))
        right = ttk.Frame(body)
        body.add(left, weight=1)
        body.add(right, weight=3)

        ttk.Label(left, text="เอกสารที่ต้องการออก").pack(anchor="w")
        for template_name in self.templates:
            var = tk.BooleanVar(value=True)
            self.selected_templates[template_name] = var
            ttk.Checkbutton(left, text=template_name, variable=var).pack(anchor="w", pady=2)

        ttk.Label(right, text="ข้อมูลสำหรับทุก Template").pack(anchor="w")
        canvas = tk.Canvas(right, highlightthickness=0)
        scroll = ttk.Scrollbar(right, orient="vertical", command=canvas.yview)
        form = ttk.Frame(canvas)
        form.bind("<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=form, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        for row, tag in enumerate(self.all_tags):
            clean = tag.strip("{}")
            var = tk.StringVar()
            self.fields[tag] = var
            ttk.Label(form, text=clean, width=24).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
            ttk.Entry(form, textvariable=var, width=64).grid(row=row, column=1, sticky="ew", pady=3)
        form.columnconfigure(1, weight=1)

        bottom = ttk.Frame(root)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="สร้างเอกสาร Word", command=self._generate).pack(side="right")

    def _choose_template_dir(self) -> None:
        path = filedialog.askdirectory(initialdir=self.template_dir.get())
        if path:
            self.template_dir.set(path)

    def _choose_output_dir(self) -> None:
        path = filedialog.askdirectory(initialdir=self.output_dir.get())
        if path:
            self.output_dir.set(path)

    def _generate(self) -> None:
        template_dir = Path(self.template_dir.get())
        output_dir = Path(self.output_dir.get())
        values = {tag: var.get().strip() for tag, var in self.fields.items()}
        missing = [tag.strip("{}") for tag, value in values.items() if not value]
        if missing:
            messagebox.showwarning("ข้อมูลยังไม่ครบ", "กรุณากรอก: " + ", ".join(missing[:8]))
            return

        created: list[str] = []
        for template_name, selected in self.selected_templates.items():
            if not selected.get():
                continue
            template_path = template_dir / template_name
            if not template_path.exists():
                messagebox.showerror("ไม่พบ Template", str(template_path))
                return
            output_path = output_dir / template_name
            render_docx(template_path, output_path, values)
            created.append(output_path.name)

        messagebox.showinfo("สำเร็จ", f"สร้างเอกสาร {len(created)} ไฟล์ที่\n{output_dir}")


if __name__ == "__main__":
    ReimbursementApp().mainloop()

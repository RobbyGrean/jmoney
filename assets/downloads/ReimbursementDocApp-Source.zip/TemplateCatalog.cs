using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Xml;

namespace ReimbursementDocApp
{
    internal sealed class DocumentTemplateCatalog
    {
        public int Version { get; set; }
        public List<DocumentGroupRecord> Groups { get; set; }
        public List<DocumentTemplateRecord> Templates { get; set; }
        public List<CustomTagDefinition> CustomTags { get; set; }

        public DocumentTemplateCatalog()
        {
            Version = 3;
            Groups = new List<DocumentGroupRecord>();
            Templates = new List<DocumentTemplateRecord>();
            CustomTags = new List<CustomTagDefinition>();
        }
    }

    internal static class TemplateLifecycle
    {
        public const string Draft = "Draft";
        public const string Invalid = "Invalid";
        public const string Active = "Active";
    }

    internal sealed class DocumentGroupRecord
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int SortOrder { get; set; }

        public DocumentGroupRecord()
        {
            Id = "";
            Name = "";
            Description = "";
        }

        public override string ToString()
        {
            return Name;
        }
    }

    internal sealed class DocumentTemplateRecord
    {
        public string Id { get; set; }
        public string GroupId { get; set; }
        public string FileName { get; set; }
        public string DisplayName { get; set; }
        public string Description { get; set; }
        public string Source { get; set; }
        public string CreatedAt { get; set; }
        public string Status { get; set; }
        public string LastValidatedAt { get; set; }
        public string ValidationMessage { get; set; }
        public List<string> Tags { get; set; }

        public DocumentTemplateRecord()
        {
            Id = "";
            GroupId = "";
            FileName = "";
            DisplayName = "";
            Description = "";
            Source = "user";
            CreatedAt = "";
            Status = TemplateLifecycle.Draft;
            LastValidatedAt = "";
            ValidationMessage = "ยังไม่ได้ตรวจสอบ";
            Tags = new List<string>();
        }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(DisplayName)
                ? Path.GetFileNameWithoutExtension(FileName)
                : DisplayName;
        }
    }

    internal sealed class CustomTagDefinition
    {
        public string Id { get; set; }
        public string Tag { get; set; }
        public string DisplayName { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string DataType { get; set; }
        public string DefaultValue { get; set; }
        public bool RememberLastValue { get; set; }
        public bool Required { get; set; }
        public List<string> Choices { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }

        public CustomTagDefinition()
        {
            Id = "";
            Tag = "";
            DisplayName = "";
            Description = "";
            Category = "ข้อมูลเพิ่มเติม";
            DataType = "Text";
            DefaultValue = "";
            Choices = new List<string>();
            CreatedAt = "";
            UpdatedAt = "";
        }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(DisplayName) ? Tag : DisplayName;
        }
    }

    internal sealed class TagDefinition
    {
        public string Tag { get; private set; }
        public string DisplayName { get; private set; }
        public string Category { get; private set; }
        public string Description { get; private set; }
        public string Example { get; private set; }
        public bool IsAlias { get; private set; }
        public bool IsSystem { get; private set; }
        public string DataType { get; private set; }
        public bool Required { get; private set; }
        public string DefaultValue { get; private set; }
        public bool RememberLastValue { get; private set; }
        public IList<string> Choices { get; private set; }

        public TagDefinition(string tag, string category, string description, string example)
            : this(tag, category, description, example, false)
        {
        }

        public TagDefinition(string tag, string category, string description, string example, bool isAlias)
        {
            Tag = tag;
            DisplayName = (tag ?? "").Trim('{', '}');
            Category = category;
            Description = description;
            Example = example;
            IsAlias = isAlias;
            IsSystem = true;
            DataType = "Text";
            Required = true;
            DefaultValue = "";
            Choices = new List<string>();
        }

        public TagDefinition(CustomTagDefinition custom)
        {
            Tag = custom.Tag;
            DisplayName = custom.DisplayName;
            Category = custom.Category;
            Description = custom.Description;
            Example = custom.DefaultValue;
            IsAlias = false;
            IsSystem = false;
            DataType = custom.DataType;
            Required = custom.Required;
            DefaultValue = custom.DefaultValue;
            RememberLastValue = custom.RememberLastValue;
            Choices = (custom.Choices ?? new List<string>()).ToList();
        }
    }

    internal static class SupportedTagCatalog
    {
        public static IList<TagDefinition> Create(DocumentTemplateCatalog catalog)
        {
            var definitions = Create().ToList();
            if (catalog != null && catalog.CustomTags != null)
            {
                definitions.AddRange(catalog.CustomTags.Select(x => new TagDefinition(x)));
            }
            return definitions;
        }

        public static IList<TagDefinition> Create()
        {
            return new List<TagDefinition>
            {
                new TagDefinition("{เดือนที่ส่งมอบ}", "งวดและวันที่", "ชื่อเดือนของงวดที่ส่งมอบ", "กรกฎาคม"),
                new TagDefinition("{ย่อเดือนที่ส่งมอบ}", "งวดและวันที่", "ลำดับงวดตามปีงบประมาณ (1–12)", "10"),
                new TagDefinition("{วันที่ส่งเบิก}", "งวดและวันที่", "วันที่ส่งเบิกที่อ้างอิงจากฐานข้อมูลปีงบประมาณ", "3 สิงหาคม 2569"),
                new TagDefinition("{ปีใบสั่งจ้าง}", "งวดและวันที่", "ปีงบประมาณที่ใช้กับใบสั่งจ้าง", "2569"),
                new TagDefinition("{ปีงบประมาณ}", "งวดและวันที่", "ชื่อเรียกอีกแบบของปีใบสั่งจ้าง", "2569", true),
                new TagDefinition("{ใบสั่งจ้าง}", "งวดและวันที่", "เลขที่ใบสั่งจ้าง", "25/2569"),
                new TagDefinition("{วันที่สั่งจ้าง}", "งวดและวันที่", "วันที่ลงนามในใบสั่งจ้าง", "27 กุมภาพันธ์ 2569"),

                new TagDefinition("{ชื่อโรงเรียน}", "หน่วยงาน", "ชื่อโรงเรียนหรือหน่วยงาน โดยระบบเติมคำว่า “โรงเรียน” ให้", "โรงเรียนบ้านตัวอย่าง"),

                new TagDefinition("{คำนำหน้าลูกจ้าง}", "ผู้รับจ้าง", "คำนำหน้าชื่อผู้รับจ้าง", "นาย"),
                new TagDefinition("{ชื่อลูกจ้าง}", "ผู้รับจ้าง", "ชื่อผู้รับจ้าง (ไม่รวมนามสกุล)", "สมชาย"),
                new TagDefinition("{นามสกุลลูกจ้าง}", "ผู้รับจ้าง", "นามสกุลผู้รับจ้าง", "ใจดี"),
                new TagDefinition("{ตำแหน่ง}", "ผู้รับจ้าง", "ตำแหน่งงานที่เลือก", "ธุรการโรงเรียน 9,000"),
                new TagDefinition("{เงินเดือน}", "ผู้รับจ้าง", "จำนวนเงินเดือนเป็นตัวเลข", "9,000"),
                new TagDefinition("{เงินเดือนTEXT}", "ผู้รับจ้าง", "จำนวนเงินเดือนเป็นคำอ่านภาษาไทย", "เก้าพันบาทถ้วน"),
                new TagDefinition("{บ้านเลขที่ลูกจ้าง}", "ที่อยู่ผู้รับจ้าง", "บ้านเลขที่ของผู้รับจ้าง; เว้นว่างได้", "99/1"),
                new TagDefinition("{ถนนลูกจ้าง}", "ที่อยู่ผู้รับจ้าง", "ถนนของผู้รับจ้าง; เว้นว่างได้", "ขุนลุมประพาส"),
                new TagDefinition("{ตำบลลูกจ้าง}", "ที่อยู่ผู้รับจ้าง", "ตำบลของผู้รับจ้าง; เว้นว่างได้", "จองคำ"),
                new TagDefinition("{อำเภอลูกจ้าง}", "ที่อยู่ผู้รับจ้าง", "อำเภอของผู้รับจ้าง; เว้นว่างได้", "เมืองแม่ฮ่องสอน"),
                new TagDefinition("{จังหวัดลูกจ้าง}", "ที่อยู่ผู้รับจ้าง", "จังหวัดของผู้รับจ้าง; เว้นว่างได้", "แม่ฮ่องสอน"),

                new TagDefinition("{คำนำหน้าผอ}", "ผู้ลงนาม", "คำนำหน้าชื่อผู้อำนวยการ", "นาง"),
                new TagDefinition("{ชื่อผอ}", "ผู้ลงนาม", "ชื่อผู้อำนวยการ", "สุดา"),
                new TagDefinition("{นามสกุลผอ}", "ผู้ลงนาม", "นามสกุลผู้อำนวยการ", "บริหารดี"),
                new TagDefinition("{คำนำหน้าพัสดุ}", "ผู้ลงนาม", "คำนำหน้าชื่อเจ้าหน้าที่พัสดุ", "นางสาว"),
                new TagDefinition("{ชื่อพัสดุ}", "ผู้ลงนาม", "ชื่อเจ้าหน้าที่พัสดุ", "มาลี"),
                new TagDefinition("{นามสกุลพัสดุ}", "ผู้ลงนาม", "นามสกุลเจ้าหน้าที่พัสดุ", "รอบคอบ"),
                new TagDefinition("{คำนำหน้าหพัสดุ}", "ผู้ลงนาม", "คำนำหน้าชื่อหัวหน้าเจ้าหน้าที่พัสดุ", "นาย"),
                new TagDefinition("{ชื่อหพัสดุ}", "ผู้ลงนาม", "ชื่อหัวหน้าเจ้าหน้าที่พัสดุ", "เกรียงไกร"),
                new TagDefinition("{นามสกุลหพัสดุ}", "ผู้ลงนาม", "นามสกุลหัวหน้าเจ้าหน้าที่พัสดุ", "โปร่งใส"),
                new TagDefinition("{คำนำหน้าการเงิน}", "ผู้ลงนาม", "คำนำหน้าชื่อเจ้าหน้าที่การเงิน", "นาง"),
                new TagDefinition("{ชื่อการเงิน}", "ผู้ลงนาม", "ชื่อเจ้าหน้าที่การเงิน", "วิภา"),
                new TagDefinition("{นามสกุลการเงิน}", "ผู้ลงนาม", "นามสกุลเจ้าหน้าที่การเงิน", "ตรวจสอบ"),
                new TagDefinition("{โซนหัวหน้าการเงิน}", "ผู้ลงนาม", "ชื่อเต็มหัวหน้าการเงิน; ว่างเมื่อไม่ได้เลือกหัวหน้าการเงิน", "นาย สมบัติ มั่นคง"),
                new TagDefinition("{หัวหน้าการเงิน}", "ผู้ลงนาม", "ข้อความตำแหน่งหัวหน้าเจ้าหน้าที่การเงิน", "หัวหน้าเจ้าหน้าที่การเงิน"),

                new TagDefinition("{กรรมการA}", "คณะกรรมการ", "ชื่อเต็มประธานกรรมการตรวจรับ", "นาย กิตติ ประธานดี"),
                new TagDefinition("{กรรมการB}", "คณะกรรมการ", "ชื่อเต็มกรรมการคนที่ 2", "นางสาว นภา รอบคอบ"),
                new TagDefinition("{กรรมการC}", "คณะกรรมการ", "ชื่อเต็มกรรมการคนที่ 3", "นาย วีระ ซื่อตรง"),

                new TagDefinition("{คำนำหน้าชื่อ}", "แท็กชื่อเดิม", "ชื่อเรียกเดิมของคำนำหน้าผู้รับจ้าง", "นาย", true),
                new TagDefinition("{กรรมการ B}", "แท็กชื่อเดิม", "ชื่อเรียกเดิมของกรรมการ B", "นางสาว นภา รอบคอบ", true),
                new TagDefinition("{กรรมการ C}", "แท็กชื่อเดิม", "ชื่อเรียกเดิมของกรรมการ C", "นาย วีระ ซื่อตรง", true)
            };
        }
    }

    internal static class TagDefinitionRules
    {
        private static readonly Regex ValidTagRegex = new Regex(
            @"^\{[^{}\[\]\r\n]{1,80}\}$",
            RegexOptions.Compiled);

        private static readonly HashSet<string> AllowedTypes = new HashSet<string>(
            new[] { "Text", "Multiline", "Number", "Date", "Choice" },
            StringComparer.OrdinalIgnoreCase);

        public static string Validate(
            CustomTagDefinition definition,
            IEnumerable<string> systemTags,
            IEnumerable<CustomTagDefinition> otherCustomTags)
        {
            if (definition == null) return "ไม่พบข้อมูลแท็ก";
            if (!ValidTagRegex.IsMatch(definition.Tag ?? ""))
            {
                return "ชื่อแท็กต้องอยู่ในรูป {ชื่อแท็ก} และห้ามมีวงเล็บซ้อนหรือขึ้นบรรทัดใหม่";
            }
            var inner = definition.Tag.Substring(1, definition.Tag.Length - 2).Trim();
            if (inner.Length == 0 || inner.StartsWith("__", StringComparison.Ordinal))
            {
                return "ชื่อแท็กนี้เป็นชื่อสงวนของระบบ";
            }
            if (string.IsNullOrWhiteSpace(definition.DisplayName)) return "กรุณากรอกชื่อที่แสดง";
            if (string.IsNullOrWhiteSpace(definition.Category)) return "กรุณาระบุหมวดข้อมูล";
            if (!AllowedTypes.Contains(definition.DataType ?? "")) return "ประเภทข้อมูลไม่ถูกต้อง";
            if (string.Equals(definition.DataType, "Choice", StringComparison.OrdinalIgnoreCase)
                && (definition.Choices == null || definition.Choices.Count == 0))
            {
                return "แท็กประเภทตัวเลือกต้องมีอย่างน้อย 1 ตัวเลือก";
            }
            if ((systemTags ?? Enumerable.Empty<string>()).Contains(definition.Tag, StringComparer.Ordinal))
            {
                return "ชื่อแท็กซ้ำกับ System Tag ซึ่งถูกล็อกไว้";
            }
            if ((otherCustomTags ?? Enumerable.Empty<CustomTagDefinition>()).Any(
                x => !ReferenceEquals(x, definition)
                    && !string.Equals(x.Id, definition.Id, StringComparison.OrdinalIgnoreCase)
                    && string.Equals(x.Tag, definition.Tag, StringComparison.Ordinal)))
            {
                return "มี Custom Tag ชื่อนี้แล้ว";
            }
            return "";
        }

        public static bool IsValidTag(string tag)
        {
            return ValidTagRegex.IsMatch(tag ?? "");
        }
    }

    internal sealed class TemplateInspectionResult
    {
        public string Error { get; set; }
        public List<string> Tags { get; private set; }
        public List<string> UnknownTags { get; private set; }
        public List<string> MalformedPlaceholders { get; private set; }
        public List<string> MissingTags { get; private set; }

        public TemplateInspectionResult()
        {
            Error = "";
            Tags = new List<string>();
            UnknownTags = new List<string>();
            MalformedPlaceholders = new List<string>();
            MissingTags = new List<string>();
        }

        public bool CanGenerate
        {
            get
            {
                return string.IsNullOrWhiteSpace(Error)
                    && UnknownTags.Count == 0
                    && MalformedPlaceholders.Count == 0
                    && MissingTags.Count == 0;
            }
        }
    }

    internal static class DocxTemplateInspector
    {
        private const string WordNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private static readonly Regex WordXmlRegex = new Regex(
            @"^word/(document|header\d+|footer\d+)\.xml$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly Regex TagRegex = new Regex(@"\{[^{}\r\n]{1,80}\}", RegexOptions.Compiled);

        public static TemplateInspectionResult Inspect(string path, IEnumerable<string> supportedTags)
        {
            var result = new TemplateInspectionResult();
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                result.Error = "ไม่พบไฟล์แบบเอกสาร";
                return result;
            }

            if (!string.Equals(Path.GetExtension(path), ".docx", StringComparison.OrdinalIgnoreCase))
            {
                result.Error = "รองรับเฉพาะไฟล์ .docx";
                return result;
            }

            try
            {
                var tags = new HashSet<string>(StringComparer.Ordinal);
                var malformed = new HashSet<string>(StringComparer.Ordinal);
                var foundDocumentXml = false;

                using (var archive = ZipFile.OpenRead(path))
                {
                    foreach (var entry in archive.Entries)
                    {
                        if (!WordXmlRegex.IsMatch(entry.FullName)) continue;
                        if (string.Equals(entry.FullName, "word/document.xml", StringComparison.OrdinalIgnoreCase))
                        {
                            foundDocumentXml = true;
                        }

                        var plainText = ReadPlainText(entry);
                        foreach (Match match in TagRegex.Matches(plainText))
                        {
                            tags.Add(match.Value);
                        }
                        foreach (var item in FindMalformedPlaceholders(plainText))
                        {
                            malformed.Add(item);
                        }
                    }
                }

                if (!foundDocumentXml)
                {
                    result.Error = "ไฟล์นี้ไม่ใช่ Word DOCX ที่สมบูรณ์ (ไม่พบ word/document.xml)";
                    return result;
                }

                result.Tags.AddRange(tags.OrderBy(x => x, StringComparer.Ordinal));
                result.MalformedPlaceholders.AddRange(malformed.OrderBy(x => x, StringComparer.Ordinal));
                var supported = new HashSet<string>(supportedTags ?? Enumerable.Empty<string>(), StringComparer.Ordinal);
                result.UnknownTags.AddRange(result.Tags.Where(x => !supported.Contains(x)));
            }
            catch (InvalidDataException)
            {
                result.Error = "ไฟล์ DOCX เสียหายหรือไม่ใช่ ZIP package ที่ Word อ่านได้";
            }
            catch (XmlException)
            {
                result.Error = "XML ภายในไฟล์ DOCX ไม่สมบูรณ์";
            }
            catch (Exception ex)
            {
                result.Error = "ตรวจแบบเอกสารไม่สำเร็จ: " + ex.Message;
            }

            return result;
        }

        public static IList<string> ExtractTags(string path)
        {
            return Inspect(path, Enumerable.Empty<string>()).Tags;
        }

        private static string ReadPlainText(ZipArchiveEntry entry)
        {
            using (var stream = entry.Open())
            using (var reader = new StreamReader(stream, Encoding.UTF8, true))
            {
                var xml = new XmlDocument { PreserveWhitespace = true };
                xml.LoadXml(reader.ReadToEnd());
                var namespaces = new XmlNamespaceManager(xml.NameTable);
                namespaces.AddNamespace("w", WordNamespace);
                var nodes = xml.SelectNodes("//w:t", namespaces);
                var builder = new StringBuilder();
                if (nodes != null)
                {
                    foreach (XmlNode node in nodes) builder.Append(node.InnerText ?? "");
                }
                return builder.ToString();
            }
        }

        private static IEnumerable<string> FindMalformedPlaceholders(string text)
        {
            var results = new HashSet<string>(StringComparer.Ordinal);
            var start = -1;

            for (var index = 0; index < text.Length; index++)
            {
                var value = text[index];
                if (value == '{')
                {
                    if (start >= 0)
                    {
                        results.Add(CreateSnippet(text, start, index));
                    }
                    start = index;
                    continue;
                }

                if (value != '}') continue;
                if (start < 0)
                {
                    results.Add(CreateSnippet(text, Math.Max(0, index - 20), index));
                    continue;
                }

                var candidate = text.Substring(start, index - start + 1);
                if (!TagRegex.IsMatch(candidate) || TagRegex.Match(candidate).Value != candidate)
                {
                    results.Add(CreateSnippet(text, start, index));
                }
                start = -1;
            }

            if (start >= 0)
            {
                results.Add(CreateSnippet(text, start, Math.Min(text.Length - 1, start + 80)));
            }

            return results;
        }

        private static string CreateSnippet(string text, int start, int end)
        {
            if (text.Length == 0) return "(ว่าง)";
            start = Math.Max(0, Math.Min(start, text.Length - 1));
            end = Math.Max(start, Math.Min(end, text.Length - 1));
            var value = text.Substring(start, end - start + 1).Replace("\r", " ").Replace("\n", " ").Trim();
            return value.Length > 84 ? value.Substring(0, 84) + "…" : value;
        }
    }

    internal static class TemplateCatalogStore
    {
        public const string CatalogFileName = "template_catalog.json";
        public const string LegacyManifestFileName = "template_tags.json";
        public const string DefaultGroupId = "payroll-reimbursement";

        private static readonly JavaScriptSerializer Serializer = new JavaScriptSerializer
        {
            MaxJsonLength = 4 * 1024 * 1024,
            RecursionLimit = 64
        };

        public static DocumentTemplateCatalog LoadOrMigrate(string baseDirectory)
        {
            var catalogPath = Path.Combine(baseDirectory, CatalogFileName);
            DocumentTemplateCatalog catalog;
            var migrated = false;

            if (File.Exists(catalogPath))
            {
                catalog = Serializer.Deserialize<DocumentTemplateCatalog>(
                    File.ReadAllText(catalogPath, Encoding.UTF8));
            }
            else
            {
                catalog = LoadLegacy(Path.Combine(baseDirectory, LegacyManifestFileName));
                migrated = true;
            }

            Normalize(catalog);
            var synchronized = SynchronizeTagsFromDocuments(baseDirectory, catalog);
            if (migrated || synchronized) Save(baseDirectory, catalog);
            return catalog;
        }

        public static DocumentTemplateCatalog LoadCatalogFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                throw new FileNotFoundException("ไม่พบไฟล์สำรองรายการแม่แบบ", path);
            }
            var catalog = Serializer.Deserialize<DocumentTemplateCatalog>(
                File.ReadAllText(path, Encoding.UTF8));
            Normalize(catalog);
            return catalog;
        }

        public static void Save(string baseDirectory, DocumentTemplateCatalog catalog)
        {
            if (catalog == null) throw new ArgumentNullException("catalog");
            Normalize(catalog);
            Directory.CreateDirectory(baseDirectory);

            var catalogPath = Path.Combine(baseDirectory, CatalogFileName);
            var manifestPath = Path.Combine(baseDirectory, LegacyManifestFileName);
            var manifest = new Dictionary<string, string[]>(StringComparer.Ordinal);
            foreach (var template in catalog.Templates)
            {
                manifest[template.FileName] = (template.Tags ?? new List<string>()).ToArray();
            }
            WriteTransaction(new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { catalogPath, Serializer.Serialize(catalog) },
                { manifestPath, Serializer.Serialize(manifest) }
            });
        }

        public static void CopyInto(DocumentTemplateCatalog target, DocumentTemplateCatalog source)
        {
            if (target == null || source == null) throw new ArgumentNullException();
            var clone = Clone(source);
            target.Version = clone.Version;
            target.Groups = clone.Groups;
            target.Templates = clone.Templates;
            target.CustomTags = clone.CustomTags;
        }

        public static string CreateConfigurationBackup(string baseDirectory)
        {
            var backupRoot = Path.Combine(baseDirectory, "admin-backups");
            var folder = Path.Combine(backupRoot, DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            Directory.CreateDirectory(folder);
            foreach (var fileName in new[] { CatalogFileName, LegacyManifestFileName })
            {
                var source = Path.Combine(baseDirectory, fileName);
                if (File.Exists(source)) File.Copy(source, Path.Combine(folder, fileName), true);
            }
            return folder;
        }

        public static DocumentTemplateCatalog Clone(DocumentTemplateCatalog source)
        {
            if (source == null) return new DocumentTemplateCatalog();
            return Serializer.Deserialize<DocumentTemplateCatalog>(Serializer.Serialize(source));
        }

        public static string CreateId()
        {
            return Guid.NewGuid().ToString("N");
        }

        public static TemplateInspectionResult ValidateTemplate(
            string baseDirectory,
            DocumentTemplateCatalog catalog,
            DocumentTemplateRecord template)
        {
            if (template == null) throw new ArgumentNullException("template");
            var templatePath = Path.Combine(baseDirectory, "Template", template.FileName ?? "");
            var supported = SupportedTagCatalog.Create(catalog).Select(x => x.Tag).ToArray();
            var inspection = DocxTemplateInspector.Inspect(templatePath, supported);
            var expectedTags = (template.Tags ?? new List<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.Ordinal)
                .ToList();
            inspection.MissingTags.AddRange(expectedTags
                .Where(x => !inspection.Tags.Contains(x, StringComparer.Ordinal))
                .OrderBy(x => x, StringComparer.Ordinal));
            template.LastValidatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
            if (!string.IsNullOrWhiteSpace(inspection.Error))
            {
                template.Status = TemplateLifecycle.Invalid;
                template.ValidationMessage = inspection.Error;
            }
            else if (inspection.MalformedPlaceholders.Count > 0)
            {
                template.Status = TemplateLifecycle.Invalid;
                template.ValidationMessage = "พบวงเล็บแท็กไม่สมบูรณ์: "
                    + string.Join(", ", inspection.MalformedPlaceholders.Take(3).ToArray());
            }
            else if (inspection.UnknownTags.Count > 0)
            {
                template.Status = TemplateLifecycle.Invalid;
                template.ValidationMessage = "พบแท็กที่ยังไม่ได้กำหนด: "
                    + string.Join(", ", inspection.UnknownTags.Take(3).ToArray());
            }
            else if (inspection.MissingTags.Count > 0)
            {
                template.Status = TemplateLifecycle.Invalid;
                template.ValidationMessage = "แท็กที่เคยมีหายจากไฟล์: "
                    + string.Join(", ", inspection.MissingTags.Take(3).ToArray());
            }
            else
            {
                if (string.Equals(template.Source, "built-in", StringComparison.OrdinalIgnoreCase)
                    || string.Equals(template.Status, TemplateLifecycle.Active, StringComparison.OrdinalIgnoreCase))
                {
                    template.Status = TemplateLifecycle.Active;
                }
                else
                {
                    template.Status = TemplateLifecycle.Draft;
                }
                template.ValidationMessage = inspection.Tags.Count == 0
                    ? "ตรวจผ่าน • เอกสารไม่มีแท็ก"
                    : "ตรวจผ่าน • " + inspection.Tags.Count + " แท็ก";
            }
            if (inspection.MissingTags.Count == 0) template.Tags = inspection.Tags.ToList();
            return inspection;
        }

        public static TemplateInspectionResult ActivateTemplate(
            string baseDirectory,
            DocumentTemplateCatalog catalog,
            DocumentTemplateRecord template)
        {
            var inspection = ValidateTemplate(baseDirectory, catalog, template);
            if (inspection.CanGenerate)
            {
                template.Status = TemplateLifecycle.Active;
                template.ValidationMessage = "พร้อมใช้งาน";
            }
            return inspection;
        }

        public static string GetUniqueFileName(string directory, string requestedFileName)
        {
            var safeName = Path.GetFileName(requestedFileName);
            var stem = Path.GetFileNameWithoutExtension(safeName);
            var extension = Path.GetExtension(safeName);
            if (string.IsNullOrWhiteSpace(stem)) stem = "document-template";
            if (string.IsNullOrWhiteSpace(extension)) extension = ".docx";

            var candidate = stem + extension;
            var counter = 2;
            while (File.Exists(Path.Combine(directory, candidate)))
            {
                candidate = stem + "_" + counter + extension;
                counter++;
            }
            return candidate;
        }

        private static DocumentTemplateCatalog LoadLegacy(string manifestPath)
        {
            if (!File.Exists(manifestPath))
            {
                throw new FileNotFoundException(
                    "ไม่พบ " + CatalogFileName + " หรือ " + LegacyManifestFileName,
                    manifestPath);
            }

            var legacy = Serializer.Deserialize<Dictionary<string, string[]>>(
                File.ReadAllText(manifestPath, Encoding.UTF8));
            var catalog = new DocumentTemplateCatalog();
            catalog.Groups.Add(new DocumentGroupRecord
            {
                Id = DefaultGroupId,
                Name = "ชุดส่งเบิกเงินเดือน",
                Description = "เอกสารมาตรฐานสำหรับกระบวนการส่งเบิกค่าจ้างรายเดือน",
                SortOrder = 0
            });

            var order = 0;
            foreach (var item in legacy)
            {
                catalog.Templates.Add(new DocumentTemplateRecord
                {
                    Id = "legacy-" + (++order),
                    GroupId = DefaultGroupId,
                    FileName = item.Key,
                    DisplayName = Path.GetFileNameWithoutExtension(item.Key),
                    Description = "",
                    Source = "built-in",
                    CreatedAt = "",
                    Status = TemplateLifecycle.Active,
                    LastValidatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                    ValidationMessage = "System Template พร้อมใช้",
                    Tags = item.Value == null ? new List<string>() : item.Value.Distinct().ToList()
                });
            }
            return catalog;
        }

        private static void Normalize(DocumentTemplateCatalog catalog)
        {
            if (catalog == null) throw new InvalidDataException("template catalog is empty");
            catalog.Version = 3;
            if (catalog.Groups == null) catalog.Groups = new List<DocumentGroupRecord>();
            if (catalog.Templates == null) catalog.Templates = new List<DocumentTemplateRecord>();
            if (catalog.CustomTags == null) catalog.CustomTags = new List<CustomTagDefinition>();

            foreach (var group in catalog.Groups.Where(x => x != null && string.IsNullOrWhiteSpace(x.Id)))
            {
                group.Id = CreateId();
            }

            catalog.Groups = catalog.Groups
                .Where(x => x != null && !string.IsNullOrWhiteSpace(x.Name))
                .GroupBy(x => x.Id, StringComparer.OrdinalIgnoreCase)
                .Select(x => x.First())
                .OrderBy(x => x.SortOrder)
                .ThenBy(x => x.Name, StringComparer.CurrentCulture)
                .ToList();

            if (catalog.Groups.Count == 0)
            {
                catalog.Groups.Add(new DocumentGroupRecord
                {
                    Id = DefaultGroupId,
                    Name = "ชุดส่งเบิกเงินเดือน",
                    Description = "เอกสารมาตรฐานสำหรับกระบวนการส่งเบิกค่าจ้างรายเดือน",
                    SortOrder = 0
                });
            }

            var defaultGroup = catalog.Groups[0];
            var groupIds = new HashSet<string>(catalog.Groups.Select(x => x.Id), StringComparer.OrdinalIgnoreCase);
            var fileNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var normalizedTemplates = new List<DocumentTemplateRecord>();
            foreach (var template in catalog.Templates.Where(x => x != null))
            {
                template.FileName = Path.GetFileName(template.FileName ?? "");
                if (string.IsNullOrWhiteSpace(template.FileName) || !fileNames.Add(template.FileName)) continue;
                if (string.IsNullOrWhiteSpace(template.Id)) template.Id = CreateId();
                if (!groupIds.Contains(template.GroupId ?? "")) template.GroupId = defaultGroup.Id;
                if (string.IsNullOrWhiteSpace(template.DisplayName))
                {
                    template.DisplayName = Path.GetFileNameWithoutExtension(template.FileName);
                }
                if (template.Description == null) template.Description = "";
                if (template.Source == null) template.Source = "user";
                if (template.CreatedAt == null) template.CreatedAt = "";
                if (string.IsNullOrWhiteSpace(template.Status))
                {
                    template.Status = string.Equals(template.Source, "built-in", StringComparison.OrdinalIgnoreCase)
                        ? TemplateLifecycle.Active
                        : TemplateLifecycle.Draft;
                }
                if (template.LastValidatedAt == null) template.LastValidatedAt = "";
                if (template.ValidationMessage == null) template.ValidationMessage = "";
                template.Tags = (template.Tags ?? new List<string>())
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Distinct(StringComparer.Ordinal)
                    .OrderBy(x => x, StringComparer.Ordinal)
                    .ToList();
                normalizedTemplates.Add(template);
            }
            catalog.Templates = normalizedTemplates;

            var systemTags = new HashSet<string>(SupportedTagCatalog.Create().Select(x => x.Tag), StringComparer.Ordinal);
            var customNames = new HashSet<string>(StringComparer.Ordinal);
            var normalizedCustomTags = new List<CustomTagDefinition>();
            foreach (var custom in catalog.CustomTags.Where(x => x != null))
            {
                if (string.IsNullOrWhiteSpace(custom.Id)) custom.Id = CreateId();
                if (custom.Choices == null) custom.Choices = new List<string>();
                custom.Choices = custom.Choices
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Select(x => x.Trim())
                    .Distinct(StringComparer.CurrentCultureIgnoreCase)
                    .ToList();
                if (custom.CreatedAt == null) custom.CreatedAt = "";
                if (custom.UpdatedAt == null) custom.UpdatedAt = "";
                if (!TagDefinitionRules.IsValidTag(custom.Tag)
                    || systemTags.Contains(custom.Tag)
                    || !customNames.Add(custom.Tag)) continue;
                normalizedCustomTags.Add(custom);
            }
            catalog.CustomTags = normalizedCustomTags.OrderBy(x => x.Category).ThenBy(x => x.DisplayName).ToList();
        }

        private static bool SynchronizeTagsFromDocuments(
            string baseDirectory,
            DocumentTemplateCatalog catalog)
        {
            var changed = false;
            var templateDirectory = Path.Combine(baseDirectory, "Template");
            if (!Directory.Exists(templateDirectory)) return false;

            foreach (var template in catalog.Templates)
            {
                var templatePath = Path.Combine(templateDirectory, template.FileName);
                if (!File.Exists(templatePath)) continue;
                var inspection = DocxTemplateInspector.Inspect(
                    templatePath,
                    SupportedTagCatalog.Create(catalog).Select(x => x.Tag));
                if (!string.IsNullOrWhiteSpace(inspection.Error)) continue;

                var previousStatus = template.Status;
                var previousMessage = template.ValidationMessage;
                if (string.Equals(template.Source, "built-in", StringComparison.OrdinalIgnoreCase)
                    || string.Equals(template.Status, TemplateLifecycle.Active, StringComparison.OrdinalIgnoreCase))
                {
                    var validation = ValidateTemplate(baseDirectory, catalog, template);
                    if (!string.Equals(previousStatus, template.Status, StringComparison.Ordinal)
                        || !string.Equals(previousMessage, template.ValidationMessage, StringComparison.Ordinal)) changed = true;
                    if (validation.MissingTags.Count > 0) continue;
                }

                var actualTags = inspection.Tags
                    .Distinct(StringComparer.Ordinal)
                    .OrderBy(x => x, StringComparer.Ordinal)
                    .ToList();
                var storedTags = (template.Tags ?? new List<string>())
                    .Distinct(StringComparer.Ordinal)
                    .OrderBy(x => x, StringComparer.Ordinal)
                    .ToList();
                if (actualTags.SequenceEqual(storedTags, StringComparer.Ordinal)) continue;
                template.Tags = actualTags;
                changed = true;
            }
            return changed;
        }

        private static void WriteTransaction(IDictionary<string, string> files)
        {
            var transactionId = Guid.NewGuid().ToString("N");
            var temporaryFiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var rollbackFiles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var committed = new List<string>();
            try
            {
                foreach (var item in files)
                {
                    var temporary = item.Key + ".tmp-" + transactionId;
                    File.WriteAllText(temporary, item.Value, new UTF8Encoding(false));
                    temporaryFiles[item.Key] = temporary;
                    if (File.Exists(item.Key))
                    {
                        var rollback = item.Key + ".rollback-" + transactionId;
                        File.Copy(item.Key, rollback, true);
                        rollbackFiles[item.Key] = rollback;
                    }
                }

                var commitIndex = 0;
                foreach (var item in temporaryFiles)
                {
                    if (File.Exists(item.Key)) File.Replace(item.Value, item.Key, null);
                    else File.Move(item.Value, item.Key);
                    committed.Add(item.Key);
                    commitIndex++;
                    if (commitIndex == 1 && string.Equals(
                        Environment.GetEnvironmentVariable("JMONEY_TEST_FAIL_SAVE_AFTER_FIRST"),
                        "1",
                        StringComparison.Ordinal))
                    {
                        throw new IOException("จำลองการบันทึกล้มเหลวหลังไฟล์แรก");
                    }
                }
            }
            catch
            {
                foreach (var path in committed)
                {
                    string rollback;
                    if (rollbackFiles.TryGetValue(path, out rollback) && File.Exists(rollback))
                    {
                        File.Copy(rollback, path, true);
                    }
                    else if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                }
                throw;
            }
            finally
            {
                foreach (var path in temporaryFiles.Values)
                {
                    if (File.Exists(path)) File.Delete(path);
                }
                foreach (var path in rollbackFiles.Values)
                {
                    if (File.Exists(path)) File.Delete(path);
                }
            }
        }
    }
}

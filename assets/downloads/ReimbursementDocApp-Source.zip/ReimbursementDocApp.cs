﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Xml;

[assembly: System.Reflection.AssemblyTitle("jmoney")]
[assembly: System.Reflection.AssemblyProduct("jmoney Office Document Generator")]
[assembly: System.Reflection.AssemblyDescription("Offline Word template and tag management for Thai office documents")]
[assembly: System.Reflection.AssemblyVersion("2.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("2.0.0.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("2.0.0")]

namespace ReimbursementDocApp
{
    internal static class Program
    {
        internal const string AppVersion = "2.0.0";
        private const string WordNs = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private const string XmlNs = "http://www.w3.org/XML/1998/namespace";
        private static readonly Regex TagRegex = new Regex(@"\{[^{}\r\n]{1,80}\}", RegexOptions.Compiled);
        private static readonly Regex WordXmlRegex = new Regex(@"^word/(document|header\d+|footer\d+)\.xml$", RegexOptions.Compiled);
        private static readonly Regex JsonStringRegex = new Regex("\"([^\"]+)\"", RegexOptions.Compiled);

        private static readonly string[] ThaiMonths = { "", "\u0e21\u0e01\u0e23\u0e32\u0e04\u0e21", "\u0e01\u0e38\u0e21\u0e20\u0e32\u0e1e\u0e31\u0e19\u0e18\u0e4c", "\u0e21\u0e35\u0e19\u0e32\u0e04\u0e21", "\u0e40\u0e21\u0e29\u0e32\u0e22\u0e19", "\u0e1e\u0e24\u0e29\u0e20\u0e32\u0e04\u0e21", "\u0e21\u0e34\u0e16\u0e38\u0e19\u0e32\u0e22\u0e19", "\u0e01\u0e23\u0e01\u0e0e\u0e32\u0e04\u0e21", "\u0e2a\u0e34\u0e07\u0e2b\u0e32\u0e04\u0e21", "\u0e01\u0e31\u0e19\u0e22\u0e32\u0e22\u0e19", "\u0e15\u0e38\u0e25\u0e32\u0e04\u0e21", "\u0e1e\u0e24\u0e28\u0e08\u0e34\u0e01\u0e32\u0e22\u0e19", "\u0e18\u0e31\u0e19\u0e27\u0e32\u0e04\u0e21" };
        private static readonly string[] ThaiMonthShort = { "", "\u0e21.\u0e04.", "\u0e01.\u0e1e.", "\u0e21\u0e35.\u0e04.", "\u0e40\u0e21.\u0e22.", "\u0e1e.\u0e04.", "\u0e21\u0e34.\u0e22.", "\u0e01.\u0e04.", "\u0e2a.\u0e04.", "\u0e01.\u0e22.", "\u0e15.\u0e04.", "\u0e1e.\u0e22.", "\u0e18.\u0e04." };
        private static readonly string TagDeliveryMonth = "{\u0e40\u0e14\u0e37\u0e2d\u0e19\u0e17\u0e35\u0e48\u0e2a\u0e48\u0e07\u0e21\u0e2d\u0e1a}";
        private static readonly string TagDeliveryMonthShort = "{\u0e22\u0e48\u0e2d\u0e40\u0e14\u0e37\u0e2d\u0e19\u0e17\u0e35\u0e48\u0e2a\u0e48\u0e07\u0e21\u0e2d\u0e1a}";
        private static readonly string TagPayDate = "{\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e2a\u0e48\u0e07\u0e40\u0e1a\u0e34\u0e01}";
        private static readonly string TagPurchaseOrderYear = "{\u0e1b\u0e35\u0e43\u0e1a\u0e2a\u0e31\u0e48\u0e07\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagFiscalYear = "{\u0e1b\u0e35\u0e07\u0e1a\u0e1b\u0e23\u0e30\u0e21\u0e32\u0e13}";
        private static readonly string TagOrderDate = "{\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e2a\u0e31\u0e48\u0e07\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagHeadFinanceZone = "{\u0e42\u0e0b\u0e19\u0e2b\u0e31\u0e27\u0e2b\u0e19\u0e49\u0e32\u0e01\u0e32\u0e23\u0e40\u0e07\u0e34\u0e19}";
        private static readonly string TagHeadFinanceTitle = "{\u0e2b\u0e31\u0e27\u0e2b\u0e19\u0e49\u0e32\u0e01\u0e32\u0e23\u0e40\u0e07\u0e34\u0e19}";
        private static readonly string TagEmployeeName = "{\u0e0a\u0e37\u0e48\u0e2d\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagEmployeeHouseNo = "{\u0e1a\u0e49\u0e32\u0e19\u0e40\u0e25\u0e02\u0e17\u0e35\u0e48\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagEmployeeRoad = "{\u0e16\u0e19\u0e19\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagEmployeeSubdistrict = "{\u0e15\u0e33\u0e1a\u0e25\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagEmployeeDistrict = "{\u0e2d\u0e33\u0e40\u0e20\u0e2d\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagEmployeeProvince = "{\u0e08\u0e31\u0e07\u0e2b\u0e27\u0e31\u0e14\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07}";
        private static readonly string TagSchoolName = "{\u0e0a\u0e37\u0e48\u0e2d\u0e42\u0e23\u0e07\u0e40\u0e23\u0e35\u0e22\u0e19}";
        private const string OptionalSpacingValue = "................................";
        private const string SavedTemplatesFileName = "saved_templates.json";

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                Application.Run(new MainForm(TemplateCatalogStore.LoadOrMigrate(baseDirectory)));
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "เปิดโปรแกรมไม่สำเร็จ\n\n" + ex.Message,
                    "jmoney",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private static string UnescapeJson(string value)
        {
            return Regex.Replace(value, @"\\u([0-9a-fA-F]{4})", m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString())
                .Replace("\\\"", "\"")
                .Replace("\\\\", "\\");
        }

        private sealed class MainForm : Form
        {
            private readonly Color Navy = Color.FromArgb(24, 56, 82);
            private readonly Color Primary = Color.FromArgb(31, 94, 140);
            private readonly Color PrimaryDark = Color.FromArgb(22, 72, 108);
            private readonly Color Accent = Color.FromArgb(15, 118, 110);
            private readonly Color Bg = Color.FromArgb(243, 246, 248);
            private readonly Color Border = Color.FromArgb(214, 224, 232);
            private readonly Color TextColor = Color.FromArgb(30, 41, 59);
            private readonly Color MutedText = Color.FromArgb(100, 116, 139);
            private readonly Font UiFont = new Font("Segoe UI", 10.0f, FontStyle.Regular);
            private readonly Font LabelFont = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            private readonly DocumentTemplateCatalog catalog;
            private readonly List<TagDefinition> tagDefinitions;
            private readonly TextBox templateBox = new TextBox();
            private readonly TextBox outputBox = new TextBox();
            private readonly ComboBox fiscalMonthBox = new ComboBox();
            private readonly NumericUpDown fiscalYearBox = new NumericUpDown();
            private readonly Label fiscalPreview = new Label();
            private readonly Label statusLabel = new Label();
            private readonly Label monthGuideLabel = new Label();
            private readonly Label templateSelectionLabel = new Label();
            private readonly ErrorProvider errorProvider = new ErrorProvider();
            private readonly TreeView templateTree = new TreeView();
            private readonly Dictionary<string, Control> fieldBoxes = new Dictionary<string, Control>();
            private readonly Dictionary<Control, List<string>> standardFieldSections = new Dictionary<Control, List<string>>();
            private readonly Dictionary<string, string> dynamicCustomValues = new Dictionary<string, string>(StringComparer.Ordinal);
            private readonly List<Control> customFieldSections = new List<Control>();
            private readonly List<string> prefixes = new List<string>();
            private readonly List<MonthOption> monthOptions = new List<MonthOption>();
            private readonly List<PositionOption> schoolPositions = new List<PositionOption>();
            private readonly List<PositionOption> khetPositions = new List<PositionOption>();
            private readonly List<SavedTemplateRecord> savedTemplates = new List<SavedTemplateRecord>();
            // Only the template selected by the quick-load action advances after a successful generation.
            private SavedTemplateRecord quickLoadedTemplate;
            private ComboBox positionBox;
            private TextBox salaryBox;
            private TextBox salaryTextBox;
            private TextBox payDateBox;
            private readonly CheckBox hasHeadFinanceBox = new CheckBox();
            private OptionalPersonRow headFinanceZoneRow;
            private ComboBox orderDayBox;
            private ComboBox orderMonthBox;
            private ComboBox orderYearBox;
            private bool suppressMonthGuideReset;
            private bool suppressTemplateChecks;
            private string payDatePeriodKey = "";
            private Panel fieldsPanel;

            public MainForm(DocumentTemplateCatalog catalog)
            {
                this.catalog = catalog;
                tagDefinitions = SupportedTagCatalog.Create(catalog).ToList();
                LoadLocalDatabase();
                Text = "jmoney — ระบบจัดทำเอกสารสำนักงาน";
                ClientSize = new Size(1220, 820);
                MinimumSize = new Size(1080, 720);
                StartPosition = FormStartPosition.CenterScreen;
                BackColor = Bg;
                Font = UiFont;
                AutoScaleMode = AutoScaleMode.Dpi;
                SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
                UpdateStyles();
                SuspendLayout();

                BuildHeader();
                BuildTopInputs();
                BuildFiscalControls();
                BuildTemplateList();
                BuildFields();
                BuildActions();
                LoadSavedTemplates();
                ApplyFiscalValues();
                NormalizeControlText(this);
                EnableDoubleBuffering(this);
                ResumeLayout(true);
            }

            private void BuildHeader()
            {
                var header = new Panel
                {
                    Location = new Point(0, 0),
                    Size = new Size(ClientSize.Width, 76),
                    BackColor = Navy,
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
                };
                Controls.Add(header);

                var title = new Label
                {
                    Text = "jmoney  |  ระบบจัดทำเอกสารสำนักงาน",
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 17f, FontStyle.Bold),
                    Location = new Point(24, 12),
                    Size = new Size(610, 32)
                };
                header.Controls.Add(title);

                var sub = new Label
                {
                    Text = "สร้างเอกสาร Word จากแม่แบบที่ตรวจสอบแล้ว — ทำงานแบบออฟไลน์และเก็บข้อมูลไว้ในเครื่อง",
                    ForeColor = Color.FromArgb(213, 229, 240),
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Regular),
                    Location = new Point(26, 46),
                    Size = new Size(730, 22)
                };
                header.Controls.Add(sub);

                statusLabel.Text = "พร้อมใช้งาน";
                statusLabel.TextAlign = ContentAlignment.MiddleRight;
                statusLabel.ForeColor = Color.White;
                statusLabel.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
                statusLabel.Location = new Point(ClientSize.Width - 390, 17);
                statusLabel.Size = new Size(360, 24);
                statusLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                header.Controls.Add(statusLabel);

                var privacy = new Label
                {
                    Text = "v" + Program.AppVersion + "  •  OFFLINE  •  LOCAL DATA",
                    ForeColor = Color.FromArgb(166, 202, 226),
                    Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleRight,
                    Location = new Point(ClientSize.Width - 260, 44),
                    Size = new Size(230, 20),
                    Anchor = AnchorStyles.Top | AnchorStyles.Right
                };
                header.Controls.Add(privacy);
            }

            private void BuildTopInputs()
            {
                var panel = CreateCard(new Point(20, 92), new Size(ClientSize.Width - 40, 72), "พื้นที่ทำงาน");
                panel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                Controls.Add(panel);

                templateBox.Text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Template");
                templateBox.Visible = false;
                panel.Controls.Add(templateBox);
                panel.Controls.Add(new Label
                {
                    Text = "แม่แบบเอกสาร",
                    Font = LabelFont,
                    Location = new Point(16, 34),
                    Size = new Size(105, 22),
                    ForeColor = TextColor
                });
                panel.Controls.Add(new Label
                {
                    Text = "จัดเก็บและจัดกลุ่มในโฟลเดอร์ Template ของโปรแกรม",
                    Location = new Point(124, 34),
                    Size = new Size(345, 22),
                    ForeColor = MutedText
                });

                panel.Controls.Add(new Label
                {
                    Text = "โฟลเดอร์ผลลัพธ์",
                    Font = LabelFont,
                    Location = new Point(500, 34),
                    Size = new Size(120, 22),
                    ForeColor = TextColor
                });
                outputBox.Text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "output");
                outputBox.Location = new Point(622, 30);
                outputBox.Size = new Size(panel.Width - 748, 26);
                outputBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                outputBox.BorderStyle = BorderStyle.FixedSingle;
                panel.Controls.Add(outputBox);

                var outputButton = CreateSecondaryButton("เลือก...", new Point(panel.Width - 112, 28), new Size(92, 30));
                outputButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                outputButton.Click += delegate { PickFolder(outputBox); };
                panel.Controls.Add(outputButton);
            }

            private void BuildFiscalControls()
            {
                var group = CreateCard(new Point(20, 176), new Size(ClientSize.Width - 40, 82), "งวดส่งมอบและปีงบประมาณ");
                group.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                Controls.Add(group);
                group.Controls.Add(new Label { Text = "เดือนส่งมอบ", Font = LabelFont, Location = new Point(16, 38), Size = new Size(105, 22), ForeColor = TextColor });

                fiscalMonthBox.DropDownStyle = ComboBoxStyle.DropDownList;
                if (monthOptions.Count > 0)
                {
                    foreach (var month in monthOptions) fiscalMonthBox.Items.Add(month.Month);
                    var currentMonthName = ThaiMonths[DateTime.Today.Month];
                    var currentMonthIndex = monthOptions.FindIndex(x => x.Month == currentMonthName);
                    fiscalMonthBox.SelectedIndex = currentMonthIndex >= 0 ? currentMonthIndex : 0;
                }
                else
                {
                    for (var i = 1; i <= 12; i++) fiscalMonthBox.Items.Add(ThaiMonths[i]);
                    fiscalMonthBox.SelectedIndex = DateTime.Today.Month - 1;
                }
                fiscalMonthBox.Location = new Point(126, 34);
                fiscalMonthBox.Size = new Size(160, 24);
                fiscalMonthBox.SelectedIndexChanged += delegate
                {
                    ApplyFiscalValues();
                    ResetMonthGuideIfNeeded();
                };
                group.Controls.Add(fiscalMonthBox);

                group.Controls.Add(new Label { Text = "ปี พ.ศ.", Font = LabelFont, Location = new Point(312, 38), Size = new Size(64, 22), ForeColor = TextColor });
                fiscalYearBox.Minimum = 2500;
                fiscalYearBox.Maximum = 2700;
                fiscalYearBox.Value = DateTime.Today.Year + 543;
                fiscalYearBox.Location = new Point(378, 34);
                fiscalYearBox.Size = new Size(90, 24);
                fiscalYearBox.ValueChanged += delegate { ApplyFiscalValues(); };
                group.Controls.Add(fiscalYearBox);

                fiscalPreview.Location = new Point(500, 34);
                fiscalPreview.Size = new Size(430, 26);
                fiscalPreview.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
                fiscalPreview.ForeColor = Primary;
                group.Controls.Add(fiscalPreview);

                monthGuideLabel.Text = "ตรวจแค่เดือนก่อนสร้างเอกสาร";
                monthGuideLabel.Location = new Point(500, 57);
                monthGuideLabel.Size = new Size(260, 20);
                monthGuideLabel.ForeColor = Color.FromArgb(161, 98, 7);
                monthGuideLabel.Visible = false;
                group.Controls.Add(monthGuideLabel);
            }

            private void BuildTemplateList()
            {
                var group = CreateCard(
                    new Point(20, 274),
                    new Size(350, ClientSize.Height - 356),
                    "กลุ่มและแม่แบบเอกสาร");
                group.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
                Controls.Add(group);

                templateTree.Location = new Point(12, 34);
                templateTree.Size = new Size(326, group.Height - 136);
                templateTree.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
                templateTree.BorderStyle = BorderStyle.FixedSingle;
                templateTree.BackColor = Color.White;
                templateTree.ForeColor = TextColor;
                templateTree.Font = UiFont;
                templateTree.ItemHeight = 26;
                templateTree.CheckBoxes = true;
                templateTree.HideSelection = false;
                templateTree.ShowNodeToolTips = true;
                templateTree.AfterCheck += delegate(object sender, TreeViewEventArgs args)
                {
                    if (suppressTemplateChecks) return;
                    suppressTemplateChecks = true;
                    try
                    {
                        if (args.Node.Tag is DocumentGroupRecord)
                        {
                            foreach (TreeNode child in args.Node.Nodes) child.Checked = args.Node.Checked;
                        }
                        else if (args.Node.Parent != null)
                        {
                            args.Node.Parent.Checked = args.Node.Parent.Nodes
                                .Cast<TreeNode>()
                                .All(x => x.Checked);
                        }
                    }
                    finally
                    {
                        suppressTemplateChecks = false;
                    }
                    UpdateTemplateSelectionSummary();
                    RebuildDynamicFields();
                };
                group.Controls.Add(templateTree);

                templateSelectionLabel.Location = new Point(12, group.Height - 96);
                templateSelectionLabel.Size = new Size(326, 20);
                templateSelectionLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
                templateSelectionLabel.ForeColor = MutedText;
                group.Controls.Add(templateSelectionLabel);

                var manageButton = CreateSecondaryButton(
                    "ตั้งค่า",
                    new Point(12, group.Height - 66),
                    new Size(104, 34));
                manageButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
                manageButton.Click += delegate { OpenDocumentTemplateManager(); };
                group.Controls.Add(manageButton);

                var helpButton = CreateSecondaryButton(
                    "?  คู่มือ {tag}",
                    new Point(group.Width - 140, group.Height - 66),
                    new Size(128, 34));
                helpButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
                helpButton.Click += delegate { ShowTagHelp(); };
                group.Controls.Add(helpButton);

                RefreshTemplateTree();
            }

            private void BuildFields()
            {
                fieldsPanel = new Panel
                {
                    Location = new Point(386, 274),
                    Size = new Size(ClientSize.Width - 406, ClientSize.Height - 356),
                    AutoScroll = true,
                    BackColor = Bg,
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
                };
                Controls.Add(fieldsPanel);
                var y = 0;

                AddDeliveryCard(fieldsPanel, ref y);
                AddSignerCard(fieldsPanel, ref y);
                AddCommitteeCard(fieldsPanel, ref y);
                CaptureStandardFieldSections();
                RebuildDynamicFields();
            }

            private void CaptureStandardFieldSections()
            {
                standardFieldSections.Clear();
                if (fieldsPanel == null) return;
                foreach (Control section in fieldsPanel.Controls)
                {
                    if (!(section is Panel)) continue;
                    var tags = fieldBoxes
                        .Where(x => IsInside(section, x.Value))
                        .Select(x => x.Key)
                        .Distinct(StringComparer.Ordinal)
                        .ToList();
                    if (tags.Count > 0) standardFieldSections[section] = tags;
                }
            }

            private bool IsInside(Control parent, Control child)
            {
                if (parent == null || child == null) return false;
                var combined = child as CombinedPersonControl;
                var current = combined == null ? child : combined.ParentContainer;
                while (current != null)
                {
                    if (ReferenceEquals(current, parent)) return true;
                    current = current.Parent;
                }
                return false;
            }

            private void RefreshTagDefinitions()
            {
                tagDefinitions.Clear();
                tagDefinitions.AddRange(SupportedTagCatalog.Create(catalog));
            }

            private void RebuildDynamicFields()
            {
                if (fieldsPanel == null || fieldsPanel.IsDisposed) return;

                foreach (var custom in catalog.CustomTags ?? new List<CustomTagDefinition>())
                {
                    Control existing;
                    if (custom.RememberLastValue && fieldBoxes.TryGetValue(custom.Tag, out existing))
                    {
                        dynamicCustomValues[custom.Tag] = GetControlValue(existing);
                    }
                    else if (!custom.RememberLastValue)
                    {
                        dynamicCustomValues.Remove(custom.Tag);
                    }
                }
                foreach (var section in customFieldSections.ToList())
                {
                    fieldsPanel.Controls.Remove(section);
                    section.Dispose();
                }
                customFieldSections.Clear();
                foreach (var custom in catalog.CustomTags ?? new List<CustomTagDefinition>()) fieldBoxes.Remove(custom.Tag);

                var selectedTemplates = GetSelectedDocumentTemplates();
                var neededTags = new HashSet<string>(
                    selectedTemplates.SelectMany(x => x.Tags ?? new List<string>()).Select(GetCanonicalInputTag),
                    StringComparer.Ordinal);
                var showAll = selectedTemplates.Count == 0;
                var y = 0;
                foreach (var section in standardFieldSections.Keys.OrderBy(x => x.Top).ToList())
                {
                    var visible = showAll || standardFieldSections[section].Any(neededTags.Contains);
                    section.Visible = visible;
                    if (!visible) continue;
                    section.Top = y;
                    y += section.Height + 12;
                }

                var customTags = (catalog.CustomTags ?? new List<CustomTagDefinition>())
                    .Where(x => neededTags.Contains(x.Tag))
                    .OrderBy(x => x.Category, StringComparer.CurrentCulture)
                    .ThenBy(x => x.DisplayName, StringComparer.CurrentCulture)
                    .ToList();
                foreach (var category in customTags.GroupBy(x => x.Category))
                {
                    var definitions = category.ToList();
                    var rows = (definitions.Count + 1) / 2;
                    var rowTops = new List<int>();
                    var rowCursor = 38;
                    for (var rowIndex = 0; rowIndex < rows; rowIndex++)
                    {
                        rowTops.Add(rowCursor);
                        var rowDefinitions = definitions.Skip(rowIndex * 2).Take(2).ToList();
                        var inputHeight = rowDefinitions.Any(x =>
                            string.Equals(x.DataType, "Multiline", StringComparison.OrdinalIgnoreCase))
                            ? 62
                            : 28;
                        rowCursor += Math.Max(76, 25 + inputHeight + 14);
                    }
                    var height = rowCursor + 12;
                    var card = CreateCard(
                        new Point(0, y),
                        new Size(Math.Max(560, fieldsPanel.ClientSize.Width - 22), height),
                        "ข้อมูลเพิ่มเติม • " + category.Key);
                    card.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                    fieldsPanel.Controls.Add(card);
                    customFieldSections.Add(card);

                    for (var index = 0; index < definitions.Count; index++)
                    {
                        var definition = definitions[index];
                        var column = index % 2;
                        var row = index / 2;
                        var left = 18 + column * ((card.Width - 54) / 2 + 18);
                        var top = rowTops[row];
                        var width = (card.Width - 54) / 2;
                        var label = new Label
                        {
                            Text = definition.DisplayName + (definition.Required ? " *" : ""),
                            Location = new Point(left, top),
                            Size = new Size(width, 22),
                            Font = LabelFont,
                            ForeColor = TextColor
                        };
                        card.Controls.Add(label);
                        var input = CreateCustomInput(definition);
                        input.Location = new Point(left, top + 25);
                        input.Width = width;
                        input.Anchor = column == 0
                            ? AnchorStyles.Top | AnchorStyles.Left
                            : AnchorStyles.Top | AnchorStyles.Right;
                        input.Tag = definition;
                        input.TabIndex = index;
                        card.Controls.Add(input);
                        fieldBoxes[definition.Tag] = input;

                        string remembered;
                        if (dynamicCustomValues.TryGetValue(definition.Tag, out remembered) && remembered.Length > 0)
                        {
                            SetCustomControlValue(input, remembered);
                        }
                        else if (!string.IsNullOrWhiteSpace(definition.DefaultValue))
                        {
                            SetCustomControlValue(input, definition.DefaultValue);
                        }
                        if (!string.IsNullOrWhiteSpace(definition.Description))
                        {
                            var tip = new ToolTip();
                            tip.SetToolTip(label, definition.Description);
                            tip.SetToolTip(input, definition.Description + "\n" + definition.Tag);
                        }
                    }
                    y += card.Height + 12;
                }
                fieldsPanel.AutoScrollMinSize = new Size(0, y + 10);
            }

            private Control CreateCustomInput(CustomTagDefinition definition)
            {
                if (string.Equals(definition.DataType, "Choice", StringComparison.OrdinalIgnoreCase))
                {
                    var combo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Height = 28 };
                    foreach (var choice in definition.Choices ?? new List<string>()) combo.Items.Add(choice);
                    if (combo.Items.Count > 0) combo.SelectedIndex = 0;
                    return combo;
                }
                if (string.Equals(definition.DataType, "Number", StringComparison.OrdinalIgnoreCase))
                {
                    return new NumericUpDown
                    {
                        Minimum = -1000000000m,
                        Maximum = 1000000000m,
                        DecimalPlaces = 2,
                        ThousandsSeparator = true,
                        Height = 28
                    };
                }
                if (string.Equals(definition.DataType, "Date", StringComparison.OrdinalIgnoreCase))
                {
                    return new DateTimePicker
                    {
                        Format = DateTimePickerFormat.Custom,
                        CustomFormat = "d MMMM yyyy",
                        Height = 28
                    };
                }
                if (string.Equals(definition.DataType, "Multiline", StringComparison.OrdinalIgnoreCase))
                {
                    return new TextBox { Multiline = true, Height = 62, ScrollBars = ScrollBars.Vertical };
                }
                return new TextBox { Height = 28 };
            }

            private void SetCustomControlValue(Control control, string value)
            {
                var number = control as NumericUpDown;
                decimal decimalValue;
                if (number != null && decimal.TryParse((value ?? "").Replace(",", ""), out decimalValue))
                {
                    number.Value = Math.Min(number.Maximum, Math.Max(number.Minimum, decimalValue));
                    return;
                }
                var date = control as DateTimePicker;
                DateTime dateValue;
                if (date != null && DateTime.TryParse(value, out dateValue))
                {
                    date.Value = dateValue; return;
                }
                var combo = control as ComboBox;
                if (combo != null)
                {
                    SelectComboText(combo, value); return;
                }
                control.Text = value ?? "";
            }

            private void RefreshTemplateTree()
            {
                var selectedIds = new HashSet<string>(
                    GetSelectedDocumentTemplates().Select(x => x.Id),
                    StringComparer.OrdinalIgnoreCase);
                var hadSelection = templateTree.Nodes.Count > 0;
                var supportedTags = tagDefinitions.Select(x => x.Tag).ToArray();

                suppressTemplateChecks = true;
                templateTree.BeginUpdate();
                try
                {
                    templateTree.Nodes.Clear();
                    foreach (var documentGroup in catalog.Groups
                        .OrderBy(x => x.SortOrder)
                        .ThenBy(x => x.Name, StringComparer.CurrentCulture))
                    {
                        var activeTemplates = catalog.Templates
                            .Where(x => string.Equals(x.GroupId, documentGroup.Id, StringComparison.OrdinalIgnoreCase)
                                && string.Equals(x.Status, TemplateLifecycle.Active, StringComparison.OrdinalIgnoreCase))
                            .ToList();
                        if (activeTemplates.Count == 0) continue;
                        var groupNode = new TreeNode(documentGroup.Name)
                        {
                            Tag = documentGroup,
                            NodeFont = new Font(UiFont, FontStyle.Bold),
                            ForeColor = Navy
                        };

                        foreach (var template in activeTemplates)
                        {
                            var templatePath = Path.Combine(templateBox.Text, template.FileName);
                            var inspection = DocxTemplateInspector.Inspect(templatePath, supportedTags);
                            var templateNode = new TreeNode(template.ToString())
                            {
                                Tag = template,
                                Checked = !hadSelection || selectedIds.Contains(template.Id),
                                ForeColor = inspection.CanGenerate ? TextColor : Color.FromArgb(180, 83, 9),
                                ToolTipText = BuildTemplateStatusText(inspection)
                            };
                            groupNode.Nodes.Add(templateNode);
                        }

                        groupNode.Checked = groupNode.Nodes.Count > 0
                            && groupNode.Nodes.Cast<TreeNode>().All(x => x.Checked);
                        templateTree.Nodes.Add(groupNode);
                        groupNode.Expand();
                    }
                }
                finally
                {
                    templateTree.EndUpdate();
                    suppressTemplateChecks = false;
                }
                UpdateTemplateSelectionSummary();
                RebuildDynamicFields();
            }

            private string BuildTemplateStatusText(TemplateInspectionResult inspection)
            {
                if (!string.IsNullOrWhiteSpace(inspection.Error)) return inspection.Error;
                if (inspection.MalformedPlaceholders.Count > 0)
                {
                    return "พบวงเล็บปีกกาไม่สมบูรณ์: "
                        + string.Join(", ", inspection.MalformedPlaceholders.Take(3).ToArray());
                }
                if (inspection.UnknownTags.Count > 0)
                {
                    return "พบแท็กที่ระบบไม่รู้จัก: "
                        + string.Join(", ", inspection.UnknownTags.Take(5).ToArray());
                }
                return inspection.Tags.Count == 0
                    ? "พร้อมใช้ (เอกสารนี้ไม่มีแท็ก)"
                    : "พร้อมใช้ • " + inspection.Tags.Count + " แท็ก";
            }

            private List<DocumentTemplateRecord> GetSelectedDocumentTemplates()
            {
                var selected = new List<DocumentTemplateRecord>();
                foreach (TreeNode groupNode in templateTree.Nodes)
                {
                    foreach (TreeNode templateNode in groupNode.Nodes)
                    {
                        var template = templateNode.Tag as DocumentTemplateRecord;
                        if (template != null && templateNode.Checked) selected.Add(template);
                    }
                }
                return selected;
            }

            private void UpdateTemplateSelectionSummary()
            {
                var selectedCount = GetSelectedDocumentTemplates().Count;
                var activeCount = catalog.Templates.Count(x => x.Status == TemplateLifecycle.Active);
                templateSelectionLabel.Text = selectedCount + " จาก " + activeCount + " เอกสารที่เลือก";
            }

            private void AddPositionCard(Panel parent, ref int y)
            {
                var card = AddSection(parent, ref y, "ข้อมูลตำแหน่ง (โรงเรียน)", Color.FromArgb(255, 145, 77), 126);
                AddLabel(card, "ตำแหน่งในโรงเรียน *", 22, 42, 210);
                positionBox = AddCombo(card, 22, 66, 250);
                positionBox.Items.Add("-- เลือกตำแหน่ง --");
                foreach (var p in schoolPositions) positionBox.Items.Add(p);
                positionBox.SelectedIndex = 0;
                positionBox.SelectedIndexChanged += delegate { ApplyPositionAutoFill(); };

                AddLabel(card, "เงินเดือน", 290, 42, 120);
                salaryBox = AddText(card, "{เงินเดือน}", 290, 66, 160, true);
                AddLabel(card, "คำอ่าน", 470, 42, 120);
                salaryTextBox = AddText(card, "{เงินเดือนTEXT}", 470, 66, 220, true);
                fieldBoxes["{ตำแหน่ง}"] = positionBox;
            }

            private void AddSchoolCard(Panel parent, ref int y)
            {
                var card = AddSection(parent, ref y, "ชื่อโรงเรียน / หน่วยงาน", Color.FromArgb(244, 112, 132), 96);
                AddLabel(card, "ชื่อหน่วยงานที่ระบุในเอกสาร *", 22, 42, 240);
                AddText(card, TagSchoolName, 22, 66, 668, false);
            }

            private void AddDeliveryCard(Panel parent, ref int y)
            {
                var card = AddSection(parent, ref y, "1 · ข้อมูลการส่งมอบ ใบสั่งจ้าง และผู้รับจ้าง", Color.FromArgb(61, 128, 214), 640);
                AddLabel(card, "เดือนที่ส่งมอบ", 22, 42, 160);
                AddText(card, TagDeliveryMonth, 22, 66, 190, true);
                AddLabel(card, "งวดงาน", 230, 42, 100);
                AddText(card, TagDeliveryMonthShort, 230, 66, 90, true);
                AddLabel(card, "วันที่ส่งเบิก", 340, 42, 140);
                payDateBox = AddText(card, TagPayDate, 340, 66, 180, true);
                AddLabel(card, "ปีใบสั่งจ้าง", 540, 42, 140);
                AddText(card, TagPurchaseOrderYear, 540, 66, 140, true);

                AddLabel(card, "เลขที่ใบสั่งจ้าง *", 22, 108, 160);
                AddText(card, "{ใบสั่งจ้าง}", 22, 132, 180, false);
                AddLabel(card, "เช่น 25/2569", 22, 158, 160).ForeColor = Color.FromArgb(100, 110, 125);
                AddLabel(card, "ลงวันที่ในใบสั่งจ้าง *", 230, 108, 180);
                AddOrderDateInputs(card, 230, 132);

                AddLabel(card, "ชื่อหน่วยงานที่ระบุในเอกสาร *", 22, 198, 240);
                AddText(card, TagSchoolName, 22, 222, 668, false);

                AddLabel(card, "ตำแหน่งในโรงเรียน *", 22, 264, 210);
                positionBox = AddCombo(card, 22, 288, 250);
                positionBox.Items.Add("-- เลือกตำแหน่ง --");
                foreach (var p in schoolPositions) positionBox.Items.Add(p);
                positionBox.SelectedIndex = 0;
                positionBox.SelectedIndexChanged += delegate { ApplyPositionAutoFill(); };
                AddLabel(card, "เงินเดือน", 290, 264, 120);
                salaryBox = AddText(card, "{เงินเดือน}", 290, 288, 160, true);
                AddLabel(card, "คำอ่าน", 470, 264, 120);
                salaryTextBox = AddText(card, "{เงินเดือนTEXT}", 470, 288, 220, true);
                fieldBoxes["{ตำแหน่ง}"] = positionBox;

                AddPersonRow(card, 22, 390, "ผู้รับจ้าง", "{คำนำหน้าลูกจ้าง}", TagEmployeeName, "{นามสกุลลูกจ้าง}");
                AddAddressFields(card, 22, 500);
            }

            private void AddSignerCard(Panel parent, ref int y)
            {
                var card = AddSection(parent, ref y, "2 · รายชื่อเจ้าหน้าที่ผู้ลงนาม", Color.FromArgb(130, 124, 204), 430);
                AddPersonRow(card, 22, 64, "ผู้อำนวยการโรงเรียน", "{คำนำหน้าผอ}", "{ชื่อผอ}", "{นามสกุลผอ}");
                AddPersonRow(card, 22, 136, "เจ้าหน้าที่พัสดุ", "{คำนำหน้าพัสดุ}", "{ชื่อพัสดุ}", "{นามสกุลพัสดุ}");
                AddPersonRow(card, 22, 208, "หัวหน้าเจ้าหน้าที่พัสดุ", "{คำนำหน้าหพัสดุ}", "{ชื่อหพัสดุ}", "{นามสกุลหพัสดุ}");
                AddPersonRow(card, 22, 280, "เจ้าหน้าที่การเงิน", "{คำนำหน้าการเงิน}", "{ชื่อการเงิน}", "{นามสกุลการเงิน}");
                hasHeadFinanceBox.Text = "มีหัวหน้าการเงิน";
                hasHeadFinanceBox.Location = new Point(22, 344);
                hasHeadFinanceBox.Size = new Size(180, 24);
                hasHeadFinanceBox.CheckedChanged += delegate { ToggleHeadFinance(); };
                card.Controls.Add(hasHeadFinanceBox);
                headFinanceZoneRow = AddOptionalCombinedPersonRow(card, 22, 374, "หัวหน้าการเงิน", TagHeadFinanceZone);
                ToggleHeadFinance();
            }

            private void AddCommitteeCard(Panel parent, ref int y)
            {
                var card = AddSection(parent, ref y, "3 · คณะกรรมการตรวจรับพัสดุ", Color.FromArgb(79, 181, 139), 260);
                AddCommitteeRow(card, 22, 64, "ประธานกรรมการ (A)", "{กรรมการA}");
                AddCommitteeRow(card, 22, 136, "กรรมการ (B)", "{กรรมการB}");
                AddCommitteeRow(card, 22, 208, "กรรมการ (C)", "{กรรมการC}");
            }

            private Panel AddSection(Panel parent, ref int y, string title, Color color, int height)
            {
                var card = new Panel
                {
                    Location = new Point(0, y),
                    Size = new Size(782, height),
                    BackColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle
                };
                parent.Controls.Add(card);
                var accentBar = new Panel
                {
                    Location = new Point(0, 0),
                    Size = new Size(5, 36),
                    BackColor = color
                };
                card.Controls.Add(accentBar);
                var head = new Label
                {
                    Text = title,
                    Location = new Point(5, 0),
                    Size = new Size(775, 36),
                    BackColor = Color.FromArgb(248, 250, 252),
                    ForeColor = TextColor,
                    Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Padding = new Padding(14, 0, 0, 0)
                };
                card.Controls.Add(head);
                y += height + 16;
                return card;
            }

            private void AddPersonRow(Panel card, int x, int y, string title, string prefixTag, string nameTag, string surnameTag)
            {
                if (y == 390) y -= 12;
                if (y == 136 || y == 208 || y == 280) AddRowDivider(card, y - 26);
                AddLabel(card, title, x, y - 22, 230);
                AddLabel(card, "คำนำหน้า", x, y - 4, 120);
                AddLabel(card, "ชื่อ", x + 136, y - 4, 120);
                AddLabel(card, "นามสกุล", x + 452, y - 4, 120);
                y += 18;
                AddPrefixCombo(card, prefixTag, x, y, 120);
                AddText(card, nameTag, x + 136, y, 300, false);
                AddText(card, surnameTag, x + 452, y, 216, false);
            }

            private void AddCommitteeRow(Panel card, int x, int y, string title, string tag)
            {
                if (y == 136 || y == 208) AddRowDivider(card, y - 26);
                AddLabel(card, title, x, y - 22, 220);
                AddLabel(card, "คำนำหน้า", x, y - 4, 120);
                AddLabel(card, "ชื่อ", x + 136, y - 4, 120);
                AddLabel(card, "นามสกุล", x + 452, y - 4, 120);
                AddCombinedPersonControl(card, tag, x, y + 18, 668);
            }

            private OptionalPersonRow AddOptionalCombinedPersonRow(Panel card, int x, int y, string title, string tag)
            {
                var titleLabel = AddLabel(card, title, x, y - 22, 220);
                var prefixLabel = AddLabel(card, "คำนำหน้า", x, y - 4, 120);
                var nameLabel = AddLabel(card, "ชื่อ", x + 136, y - 4, 120);
                var surnameLabel = AddLabel(card, "นามสกุล", x + 452, y - 4, 120);
                var prefix = AddPrefixCombo(card, tag + "#prefix", x, y + 18, 120);
                var name = AddText(card, tag + "#name", x + 136, y + 18, 300, false);
                var surname = AddText(card, tag + "#surname", x + 452, y + 18, 216, false);
                fieldBoxes.Remove(FixThai(tag + "#prefix"));
                fieldBoxes.Remove(FixThai(tag + "#name"));
                fieldBoxes.Remove(FixThai(tag + "#surname"));
                var combined = new CombinedPersonControl(prefix, name, surname);
                fieldBoxes[FixThai(tag)] = combined;
                return new OptionalPersonRow(titleLabel, prefixLabel, nameLabel, surnameLabel, combined);
            }

            private void AddAddressFields(Panel card, int x, int y)
            {
                AddRowDivider(card, y - 28);
                AddLabel(card, "ที่อยู่ผู้รับจ้าง (เว้นว่างได้ ระบบจะเติมเส้นจุดให้)", x, y - 22, 380);

                AddLabel(card, "บ้านเลขที่", x, y + 4, 100);
                AddText(card, TagEmployeeHouseNo, x, y + 28, 120, false);
                AddLabel(card, "ถนน", x + 140, y + 4, 80);
                AddText(card, TagEmployeeRoad, x + 140, y + 28, 160, false);
                AddLabel(card, "ตำบล", x + 320, y + 4, 80);
                AddText(card, TagEmployeeSubdistrict, x + 320, y + 28, 140, false);
                AddLabel(card, "อำเภอ", x + 480, y + 4, 80);
                AddText(card, TagEmployeeDistrict, x + 480, y + 28, 140, false);

                AddLabel(card, "จังหวัด", x, y + 72, 100);
                AddText(card, TagEmployeeProvince, x, y + 96, 200, false);
                AddLabel(card, "ปล่อยว่างได้ และถ้ากรอกไว้ ระบบจะบันทึกไว้ใช้ในครั้งถัดไปได้", x + 220, y + 98, 430).ForeColor = Color.FromArgb(100, 110, 125);
            }

            private void AddRowDivider(Control parent, int y)
            {
                var divider = new Panel { Location = new Point(22, y), Size = new Size(720, 1), BackColor = Color.FromArgb(226, 232, 240) };
                parent.Controls.Add(divider);
                divider.BringToFront();
            }

            private Label AddLabel(Control parent, string text, int x, int y, int width)
            {
                var label = new Label { Text = text, Font = LabelFont, Location = new Point(x, y), Size = new Size(width, 20), ForeColor = TextColor };
                parent.Controls.Add(label);
                return label;
            }

            private TextBox AddText(Control parent, string tag, int x, int y, int width, bool readOnly)
            {
                var box = new TextBox { Location = new Point(x, y), Size = new Size(width, 26), ReadOnly = readOnly, BorderStyle = BorderStyle.FixedSingle };
                if (readOnly)
                {
                    box.BackColor = Color.FromArgb(239, 246, 250);
                    box.ForeColor = PrimaryDark;
                    box.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
                }
                box.TextChanged += delegate { errorProvider.SetError(box, ""); };
                parent.Controls.Add(box);
                fieldBoxes[FixThai(tag)] = box;
                return box;
            }

            private ComboBox AddCombo(Control parent, int x, int y, int width)
            {
                var box = new ComboBox { Location = new Point(x, y), Size = new Size(width, 26), DropDownStyle = ComboBoxStyle.DropDownList };
                parent.Controls.Add(box);
                return box;
            }

            private ComboBox AddPrefixCombo(Control parent, string tag, int x, int y, int width)
            {
                var box = AddCombo(parent, x, y, width);
                foreach (var prefix in GetOrderedPrefixes()) box.Items.Add(FixThai(prefix));
                if (box.Items.Count > 0) box.SelectedIndex = 0;
                box.SelectedIndexChanged += delegate { errorProvider.SetError(box, ""); };
                fieldBoxes[FixThai(tag)] = box;
                return box;
            }

            private IEnumerable<string> GetOrderedPrefixes()
            {
                var preferredOrder = new[] { "--", "นาย", "นาง", "นางสาว", "ว่าที่ร้อยตรี", "ดร.", "........" };
                var ordered = new List<string>();

                foreach (var prefix in preferredOrder)
                {
                    var match = prefixes.FirstOrDefault(x => string.Equals(x, prefix, StringComparison.Ordinal));
                    if (!string.IsNullOrWhiteSpace(match) && !ordered.Contains(match)) ordered.Add(match);
                }

                foreach (var prefix in prefixes)
                {
                    if (!ordered.Contains(prefix)) ordered.Add(prefix);
                }

                return ordered;
            }

            private void AddCombinedPersonControl(Control parent, string tag, int x, int y, int width)
            {
                var prefix = AddPrefixCombo(parent, tag + "#prefix", x, y, 120);
                var name = AddText(parent, tag + "#name", x + 136, y, 300, false);
                var surname = AddText(parent, tag + "#surname", x + 452, y, width - 452, false);
                fieldBoxes.Remove(FixThai(tag + "#prefix"));
                fieldBoxes.Remove(FixThai(tag + "#name"));
                fieldBoxes.Remove(FixThai(tag + "#surname"));
                fieldBoxes[FixThai(tag)] = new CombinedPersonControl(prefix, name, surname);
            }

            private void AddOrderDateInputs(Control parent, int x, int y)
            {
                orderDayBox = AddCombo(parent, x, y, 64);
                for (var i = 1; i <= 31; i++) orderDayBox.Items.Add(i.ToString());
                orderDayBox.SelectedIndex = DateTime.Today.Day - 1;

                orderMonthBox = AddCombo(parent, x + 72, y, 118);
                for (var i = 1; i <= 12; i++) orderMonthBox.Items.Add(ThaiMonths[i]);
                orderMonthBox.SelectedIndex = DateTime.Today.Month - 1;

                orderYearBox = AddCombo(parent, x + 198, y, 86);
                var currentBuddhistYear = DateTime.Today.Year + 543;
                for (var year = currentBuddhistYear - 5; year <= currentBuddhistYear + 10; year++)
                {
                    orderYearBox.Items.Add(year.ToString());
                }
                SelectComboText(orderYearBox, currentBuddhistYear.ToString());

                orderDayBox.SelectedIndexChanged += delegate { ApplyOrderDateInputs(); };
                orderMonthBox.SelectedIndexChanged += delegate { ApplyOrderDateInputs(); };
                orderYearBox.SelectedIndexChanged += delegate { ApplyOrderDateInputs(); };

                var hidden = new TextBox { Visible = false };
                parent.Controls.Add(hidden);
                fieldBoxes[TagOrderDate] = hidden;
                ApplyOrderDateInputs();
            }

            private void ApplyOrderDateInputs()
            {
                if (orderDayBox == null || orderMonthBox == null || orderYearBox == null) return;
                if (orderDayBox.SelectedItem == null || orderMonthBox.SelectedItem == null || orderYearBox.SelectedItem == null) return;
                var selectedYear = orderYearBox.SelectedItem.ToString();
                SetField(TagOrderDate, orderDayBox.SelectedItem + " " + orderMonthBox.SelectedItem + " " + selectedYear);
            }

            private void ToggleHeadFinance()
            {
                if (headFinanceZoneRow == null) return;
                headFinanceZoneRow.SetVisible(hasHeadFinanceBox.Checked);
                if (!hasHeadFinanceBox.Checked) headFinanceZoneRow.Combined.Text = "";
            }

            private void ApplyPositionAutoFill()
            {
                if (positionBox == null || positionBox.SelectedIndex <= 0) return;
                var match = positionBox.SelectedItem as PositionOption;
                if (match == null) return;
                salaryBox.Text = match.Salary;
                salaryTextBox.Text = match.SalaryText;
            }

            private void LoadLocalDatabase()
            {
                prefixes.Clear();
                monthOptions.Clear();
                schoolPositions.Clear();
                khetPositions.Clear();

                var databasePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app_database.json");
                if (!File.Exists(databasePath)) databasePath = Path.Combine(Environment.CurrentDirectory, "app_database.json");
                var json = File.Exists(databasePath) ? File.ReadAllText(databasePath, Encoding.UTF8) : "";

                prefixes.AddRange(LoadStringArray(json, "prefixes"));
                if (prefixes.Count == 0) prefixes.AddRange(new[] { "--", "นาย", "นาง", "นางสาว", "ว่าที่ร้อยตรี", "ดร.", "........" });
                monthOptions.AddRange(LoadMonthArray(json, "months"));
                schoolPositions.AddRange(LoadPositionArray(json, "schoolPositions"));
                khetPositions.AddRange(LoadPositionArray(json, "khetPositions"));
            }

            private List<MonthOption> LoadMonthArray(string json, string key)
            {
                var values = new List<MonthOption>();
                var section = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\\[(.*?)\\]\\s*(,|})", RegexOptions.Singleline);
                if (!section.Success) return values;
                foreach (var body in ExtractJsonObjects(section.Groups[1].Value))
                {
                    values.Add(new MonthOption
                    {
                        Month = ExtractJsonValue(body, "month"),
                        PayDate = ExtractJsonValue(body, "payDate"),
                        ShortMonth = ExtractJsonValue(body, "shortMonth"),
                        OrderYear = ExtractJsonValue(body, "orderYear"),
                        PayDatesByFiscalYear = ExtractJsonMap(body, "payDatesByFiscalYear")
                    });
                }
                return values.Where(x => !string.IsNullOrWhiteSpace(x.Month)).ToList();
            }

            private List<string> LoadStringArray(string json, string key)
            {
                var values = new List<string>();
                var match = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\\[(.*?)\\]", RegexOptions.Singleline);
                if (!match.Success) return values;
                foreach (Match item in JsonStringRegex.Matches(match.Groups[1].Value))
                {
                    values.Add(UnescapeJson(item.Groups[1].Value));
                }
                return values;
            }

            private List<PositionOption> LoadPositionArray(string json, string key)
            {
                var values = new List<PositionOption>();
                var section = Regex.Match(json, "\"" + key + "\"\\s*:\\s*\\[(.*?)\\]\\s*(,|})", RegexOptions.Singleline);
                if (!section.Success) return values;
                foreach (var body in ExtractJsonObjects(section.Groups[1].Value))
                {
                    values.Add(new PositionOption
                    {
                        Position = ExtractJsonValue(body, "position"),
                        Salary = ExtractJsonValue(body, "salary"),
                        SalaryText = ExtractJsonValue(body, "salaryText")
                    });
                }
                return values.Where(x => !string.IsNullOrWhiteSpace(x.Position)).ToList();
            }

            private string ExtractJsonValue(string text, string key)
            {
                var match = Regex.Match(text, "\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
                return match.Success ? UnescapeJson(match.Groups[1].Value) : "";
            }

            private Dictionary<string, string> ExtractJsonMap(string text, string key)
            {
                var result = new Dictionary<string, string>();
                var match = Regex.Match(text, "\"" + key + "\"\\s*:\\s*\\{(.*?)\\}", RegexOptions.Singleline);
                if (!match.Success) return result;
                foreach (Match pair in Regex.Matches(match.Groups[1].Value, "\"([^\"]+)\"\\s*:\\s*\"([^\"]*)\""))
                {
                    result[UnescapeJson(pair.Groups[1].Value)] = UnescapeJson(pair.Groups[2].Value);
                }
                return result;
            }

            private List<string> ExtractJsonObjects(string text)
            {
                var results = new List<string>();
                var depth = 0;
                var start = -1;

                for (var i = 0; i < text.Length; i++)
                {
                    var ch = text[i];
                    if (ch == '{')
                    {
                        if (depth == 0) start = i + 1;
                        depth++;
                    }
                    else if (ch == '}')
                    {
                        depth--;
                        if (depth == 0 && start >= 0)
                        {
                            results.Add(text.Substring(start, i - start));
                            start = -1;
                        }
                    }
                }

                return results;
            }

            private string GetSavedTemplatesPath()
            {
                return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, SavedTemplatesFileName);
            }

            private void LoadSavedTemplates()
            {
                savedTemplates.Clear();
                var path = GetSavedTemplatesPath();
                if (!File.Exists(path)) return;
                try
                {
                    var serializer = new JavaScriptSerializer
                    {
                        MaxJsonLength = 4 * 1024 * 1024,
                        RecursionLimit = 64
                    };
                    var file = serializer.Deserialize<SavedTemplateFile>(
                        File.ReadAllText(path, Encoding.UTF8));
                    if (file != null && file.Templates != null)
                    {
                        savedTemplates.AddRange(file.Templates.Where(
                            x => x != null && !string.IsNullOrWhiteSpace(x.Name)));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "อ่านชุดข้อมูลที่บันทึกไว้ไม่สำเร็จ\n\n" + ex.Message
                        + "\n\nไฟล์เดิมยังไม่ถูกแก้ไข: " + path,
                        "ข้อมูลบันทึกเสียหาย",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }

            private void SaveSavedTemplates()
            {
                var path = GetSavedTemplatesPath();
                var temporaryPath = path + ".tmp";
                var backupPath = path + ".backup";
                var serializer = new JavaScriptSerializer
                {
                    MaxJsonLength = 4 * 1024 * 1024,
                    RecursionLimit = 64
                };
                var file = new SavedTemplateFile
                {
                    Version = 2,
                    Templates = savedTemplates.ToList()
                };
                File.WriteAllText(
                    temporaryPath,
                    serializer.Serialize(file),
                    new UTF8Encoding(false));
                if (File.Exists(path))
                {
                    File.Replace(temporaryPath, path, backupPath);
                }
                else
                {
                    File.Move(temporaryPath, path);
                }
            }

            private TemplateFormData CaptureFormData()
            {
                ApplyFiscalValues();
                ApplyOrderDateInputs();
                var data = new TemplateFormData();
                foreach (var item in fieldBoxes)
                {
                    if (ShouldPersistField(item.Key)) data.Values[item.Key] = GetControlValue(item.Value);
                }
                data.FiscalMonth = fiscalMonthBox.SelectedItem == null ? "" : fiscalMonthBox.SelectedItem.ToString();
                data.FiscalYear = ((int)fiscalYearBox.Value).ToString();
                data.OrderDay = orderDayBox == null || orderDayBox.SelectedItem == null ? "" : orderDayBox.SelectedItem.ToString();
                data.OrderMonth = orderMonthBox == null || orderMonthBox.SelectedItem == null ? "" : orderMonthBox.SelectedItem.ToString();
                data.OrderYear = orderYearBox == null || orderYearBox.SelectedItem == null ? "" : orderYearBox.SelectedItem.ToString();
                data.HasHeadFinance = hasHeadFinanceBox.Checked ? "true" : "false";
                return data;
            }

            private void ApplyTemplateData(TemplateFormData data, bool focusMonthAfterLoad)
            {
                if (data == null) return;

                suppressMonthGuideReset = true;
                try
                {
                    SelectComboText(fiscalMonthBox, data.FiscalMonth);
                    int fiscalYearValue;
                    if (int.TryParse(data.FiscalYear, out fiscalYearValue) && fiscalYearValue >= fiscalYearBox.Minimum && fiscalYearValue <= fiscalYearBox.Maximum)
                    {
                        fiscalYearBox.Value = fiscalYearValue;
                    }

                    SelectComboText(orderDayBox, data.OrderDay);
                    SelectComboText(orderMonthBox, data.OrderMonth);
                    SelectComboText(orderYearBox, data.OrderYear);
                    ApplyOrderDateInputs();

                    hasHeadFinanceBox.Checked = string.Equals(data.HasHeadFinance, "true", StringComparison.OrdinalIgnoreCase);
                    ToggleHeadFinance();

                    foreach (var item in data.Values)
                    {
                        if (!ShouldPersistField(item.Key)) continue;
                        ApplySavedField(item.Key, item.Value);
                    }

                    ApplyFiscalValues();
                    ApplyPositionFromSavedValue(data.Values);
                    NormalizeLiveFieldsAfterApply();
                }
                finally
                {
                    suppressMonthGuideReset = false;
                }

                if (focusMonthAfterLoad) HighlightMonthGuide();
                else ResetMonthGuide();
            }

            private void ApplySavedField(string key, string value)
            {
                Control control;
                if (!fieldBoxes.TryGetValue(key, out control)) return;

                if (control.Tag is CustomTagDefinition)
                {
                    SetCustomControlValue(control, value);
                    return;
                }

                var combo = control as ComboBox;
                if (combo != null)
                {
                    if (!SelectComboText(combo, value)) combo.SelectedIndex = combo.Items.Count > 0 ? 0 : -1;
                    return;
                }

                control.Text = value ?? "";
            }

            private void ApplyPositionFromSavedValue(Dictionary<string, string> values)
            {
                string positionValue;
                if (positionBox == null || !values.TryGetValue("{ตำแหน่ง}", out positionValue)) return;
                if (SelectPosition(positionValue))
                {
                    ApplyPositionAutoFill();
                    string salaryValue;
                    if (values.TryGetValue("{เงินเดือน}", out salaryValue) && !string.IsNullOrWhiteSpace(salaryValue)) salaryBox.Text = salaryValue;
                    string salaryTextValue;
                    if (values.TryGetValue("{เงินเดือนTEXT}", out salaryTextValue) && !string.IsNullOrWhiteSpace(salaryTextValue)) salaryTextBox.Text = salaryTextValue;
                }
            }

            private void NormalizeLiveFieldsAfterApply()
            {
                var schoolName = GetControlValue(fieldBoxes[TagSchoolName]);
                if (!string.IsNullOrWhiteSpace(schoolName)) SetField(TagSchoolName, NormalizeSchoolName(schoolName));
            }

            private bool ShouldPersistField(string key)
            {
                return key != TagDeliveryMonth
                    && key != TagDeliveryMonthShort
                    && key != TagPayDate
                    && key != TagPurchaseOrderYear
                    && key != TagHeadFinanceTitle
                    && key != TagOrderDate;
            }

            private bool SelectPosition(string value)
            {
                if (positionBox == null) return false;
                for (var i = 0; i < positionBox.Items.Count; i++)
                {
                    var option = positionBox.Items[i] as PositionOption;
                    if (option != null && string.Equals(option.Position, value, StringComparison.Ordinal))
                    {
                        positionBox.SelectedIndex = i;
                        return true;
                    }
                }
                return false;
            }

            private bool SelectComboText(ComboBox combo, string value)
            {
                if (combo == null || combo.Items.Count == 0) return false;
                for (var i = 0; i < combo.Items.Count; i++)
                {
                    var item = combo.Items[i];
                    if (string.Equals(item == null ? "" : item.ToString(), value ?? "", StringComparison.Ordinal))
                    {
                        combo.SelectedIndex = i;
                        return true;
                    }
                }
                return false;
            }

            private void SaveTemplateFlow()
            {
                using (var modeDialog = new TemplateSaveModeDialog())
                {
                    if (modeDialog.ShowDialog(this) != DialogResult.OK) return;
                    if (modeDialog.SaveMode == TemplateSaveMode.SaveNew)
                    {
                        SaveTemplateAsNew();
                    }
                    else
                    {
                        OverwriteExistingTemplate();
                    }
                }
            }

            private void SaveTemplateAsNew()
            {
                using (var editor = new TemplateEditorDialog("บันทึกชุดข้อมูลใหม่", "", ""))
                {
                    if (editor.ShowDialog(this) != DialogResult.OK) return;
                    if (savedTemplates.Any(x => string.Equals(x.Name, editor.TemplateName, StringComparison.OrdinalIgnoreCase)))
                    {
                        MessageBox.Show("มีชื่อชุดข้อมูลนี้แล้ว กรุณาใช้ชื่ออื่น", "ชื่อซ้ำ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    var now = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                    var data = CaptureFormData();
                    savedTemplates.Add(new SavedTemplateRecord
                    {
                        Id = Guid.NewGuid().ToString("N"),
                        Name = editor.TemplateName,
                        Note = editor.TemplateNote,
                        CreatedAt = now,
                        UpdatedAt = now,
                        LastGeneratedFiscalMonth = "",
                        LastGeneratedFiscalYear = "",
                        Data = data.ToDictionary()
                    });
                    SaveSavedTemplates();
                    MessageBox.Show("บันทึกชุดข้อมูลแล้ว", "สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            private void OverwriteExistingTemplate()
            {
                if (!savedTemplates.Any())
                {
                    MessageBox.Show("ยังไม่มีชุดข้อมูลให้บันทึกทับ", "ยังไม่มีชุดข้อมูล", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                using (var picker = new TemplatePickerDialog(savedTemplates, "เลือกชุดข้อมูลที่ต้องการบันทึกทับ", true))
                {
                    if (picker.ShowDialog(this) != DialogResult.OK || picker.SelectedTemplate == null) return;
                    if (MessageBox.Show("ยืนยันการบันทึกทับชุดข้อมูล \"" + picker.SelectedTemplate.Name + "\" ?", "ยืนยัน", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

                    picker.SelectedTemplate.UpdatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                    picker.SelectedTemplate.Data = CaptureFormData().ToDictionary();
                    SaveSavedTemplates();
                    MessageBox.Show("บันทึกทับชุดข้อมูลแล้ว", "สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            private void QuickLoadTemplateFlow()
            {
                if (!savedTemplates.Any())
                {
                    MessageBox.Show("ยังไม่มีชุดข้อมูลที่บันทึกไว้", "ยังไม่มีชุดข้อมูล", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                using (var picker = new TemplatePickerDialog(savedTemplates, "เลือกชุดข้อมูลเดิม", false))
                {
                    if (picker.ShowDialog(this) != DialogResult.OK || picker.SelectedTemplate == null) return;

                    string nextMonth;
                    int nextYear;
                    GetNextPeriodForQuickLoad(picker.SelectedTemplate, out nextMonth, out nextYear);
                    using (var confirmation = new QuickLoadConfirmationDialog(nextMonth, nextYear))
                    {
                        if (confirmation.ShowDialog(this) != DialogResult.OK) return;
                    }

                    ApplyTemplateData(TemplateFormData.FromDictionary(picker.SelectedTemplate.Data), true);
                    ApplyLastGeneratedPeriodForQuickLoad(picker.SelectedTemplate);
                    quickLoadedTemplate = picker.SelectedTemplate;
                    AdvanceMonthForQuickLoad();
                    var payDateMissing = string.IsNullOrWhiteSpace(GetControlValue(fieldBoxes[TagPayDate]));
                    MessageBox.Show(
                        payDateMissing
                            ? "โหลดชุดข้อมูลแล้ว เลื่อนเดือนไปเดือนถัดไปให้แล้ว แต่ยังไม่มีวันที่ส่งเบิกของปีงบนี้ในฐานข้อมูล กรุณาตรวจเอง"
                            : "โหลดชุดข้อมูลแล้ว เลื่อนเดือนไปเดือนถัดไปให้แล้ว กรุณาตรวจเดือนก่อนสร้างเอกสาร",
                        "พร้อมแก้ไข",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }

            private void OpenTemplateManager()
            {
                quickLoadedTemplate = null;
                using (var manager = new TemplateManagerDialog(savedTemplates))
                {
                    var result = manager.ShowDialog(this);
                    if (manager.IsDirty) SaveSavedTemplates();
                    if (result == DialogResult.OK && manager.SelectedTemplate != null)
                    {
                        ApplyTemplateData(TemplateFormData.FromDictionary(manager.SelectedTemplate.Data), false);
                        MessageBox.Show("โหลดชุดข้อมูลแล้ว", "สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            private void OpenDocumentTemplateManager()
            {
                using (var entry = new AdminEntryDialog())
                {
                    if (entry.ShowDialog(this) != DialogResult.OK) return;
                }
                using (var manager = new TemplateAdminCenterDialog(
                    catalog,
                    AppDomain.CurrentDomain.BaseDirectory))
                {
                    if (manager.ShowDialog(this) == DialogResult.OK && manager.IsDirty)
                    {
                        RefreshTagDefinitions();
                    }
                }
                RefreshTemplateTree();
            }

            private void ShowTagHelp()
            {
                using (var dialog = new TagHelpDialog(tagDefinitions, catalog))
                {
                    dialog.ShowDialog(this);
                }
            }

            private void HighlightMonthGuide()
            {
                monthGuideLabel.Visible = true;
                fiscalMonthBox.BackColor = Color.FromArgb(255, 248, 204);
                fiscalMonthBox.Focus();
            }

            private void ResetMonthGuide()
            {
                monthGuideLabel.Visible = false;
                fiscalMonthBox.BackColor = SystemColors.Window;
            }

            private void ResetMonthGuideIfNeeded()
            {
                if (suppressMonthGuideReset) return;
                ResetMonthGuide();
            }

            private void AdvanceMonthForQuickLoad()
            {
                if (fiscalMonthBox.Items.Count == 0 || fiscalMonthBox.SelectedIndex < 0) return;

                var currentMonthName = fiscalMonthBox.SelectedItem == null ? "" : fiscalMonthBox.SelectedItem.ToString();
                var currentMonthNumber = GetMonthNumber(currentMonthName);
                if (currentMonthNumber == 0) return;

                var nextMonthNumber = currentMonthNumber == 12 ? 1 : currentMonthNumber + 1;
                var nextYearValue = (int)fiscalYearBox.Value + (currentMonthNumber == 12 ? 1 : 0);

                suppressMonthGuideReset = true;
                try
                {
                    if (nextYearValue >= fiscalYearBox.Minimum && nextYearValue <= fiscalYearBox.Maximum)
                    {
                        fiscalYearBox.Value = nextYearValue;
                    }
                    SelectComboText(fiscalMonthBox, ThaiMonths[nextMonthNumber]);
                    ApplyFiscalValues();
                }
                finally
                {
                    suppressMonthGuideReset = false;
                }

                HighlightMonthGuide();
            }

            private void ApplyLastGeneratedPeriodForQuickLoad(SavedTemplateRecord template)
            {
                if (template == null) return;

                // Old templates do not yet have this metadata. Their saved period is the safe migration fallback.
                var month = template.LastGeneratedFiscalMonth;
                var year = template.LastGeneratedFiscalYear;
                if (string.IsNullOrWhiteSpace(month) || string.IsNullOrWhiteSpace(year))
                {
                    var savedData = TemplateFormData.FromDictionary(template.Data);
                    month = savedData.FiscalMonth;
                    year = savedData.FiscalYear;
                }

                suppressMonthGuideReset = true;
                try
                {
                    SelectComboText(fiscalMonthBox, month);
                    int yearValue;
                    if (int.TryParse(year, out yearValue) && yearValue >= fiscalYearBox.Minimum && yearValue <= fiscalYearBox.Maximum)
                    {
                        fiscalYearBox.Value = yearValue;
                    }
                    ApplyFiscalValues();
                }
                finally
                {
                    suppressMonthGuideReset = false;
                }
            }

            private void GetNextPeriodForQuickLoad(SavedTemplateRecord template, out string nextMonth, out int nextYear)
            {
                var month = template == null ? "" : template.LastGeneratedFiscalMonth;
                var year = template == null ? "" : template.LastGeneratedFiscalYear;
                if (string.IsNullOrWhiteSpace(month) || string.IsNullOrWhiteSpace(year))
                {
                    var savedData = TemplateFormData.FromDictionary(template.Data);
                    month = savedData.FiscalMonth;
                    year = savedData.FiscalYear;
                }

                var monthNumber = GetMonthNumber(month);
                if (monthNumber == 0) monthNumber = DateTime.Today.Month;
                int parsedYear;
                if (!int.TryParse(year, out parsedYear)) parsedYear = DateTime.Today.Year + 543;

                var nextMonthNumber = monthNumber == 12 ? 1 : monthNumber + 1;
                nextMonth = ThaiMonths[nextMonthNumber];
                nextYear = parsedYear + (monthNumber == 12 ? 1 : 0);
            }

            private void UpdateQuickLoadedTemplatePeriodAfterGenerate()
            {
                if (quickLoadedTemplate == null) return;

                var month = fiscalMonthBox.SelectedItem == null ? "" : fiscalMonthBox.SelectedItem.ToString();
                var year = (int)fiscalYearBox.Value;
                var savedMonthNumber = GetMonthNumber(quickLoadedTemplate.LastGeneratedFiscalMonth);
                int savedYear;
                int.TryParse(quickLoadedTemplate.LastGeneratedFiscalYear, out savedYear);
                var currentMonthNumber = GetMonthNumber(month);
                if (savedMonthNumber > 0 && savedYear > 0 && currentMonthNumber > 0
                    && (year < savedYear || (year == savedYear && currentMonthNumber < savedMonthNumber))) return;

                quickLoadedTemplate.LastGeneratedFiscalMonth = month;
                quickLoadedTemplate.LastGeneratedFiscalYear = year.ToString();
                quickLoadedTemplate.LastGeneratedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                SaveSavedTemplates();
            }

            private void BuildActions()
            {
                var actionBar = new Panel
                {
                    Dock = DockStyle.Bottom,
                    Height = 68,
                    BackColor = Color.White,
                    Padding = new Padding(20, 12, 20, 12)
                };
                actionBar.Paint += delegate(object sender, PaintEventArgs args)
                {
                    using (var pen = new Pen(Border))
                    {
                        args.Graphics.DrawLine(pen, 0, 0, actionBar.Width, 0);
                    }
                };
                Controls.Add(actionBar);
                actionBar.BringToFront();

                var hint = new Label
                {
                    Text = "ตรวจงวดและปีงบประมาณก่อนสร้างทุกครั้ง",
                    Location = new Point(20, 23),
                    Size = new Size(315, 24),
                    ForeColor = MutedText,
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Regular)
                };
                actionBar.Controls.Add(hint);

                var manageButton = CreateSecondaryButton(
                    "จัดการชุดข้อมูล",
                    new Point(actionBar.Width - 758, 12),
                    new Size(145, 42));
                manageButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                manageButton.Click += delegate { OpenTemplateManager(); };
                actionBar.Controls.Add(manageButton);

                var saveButton = CreateSecondaryButton(
                    "บันทึกชุดข้อมูล",
                    new Point(actionBar.Width - 603, 12),
                    new Size(145, 42));
                saveButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                saveButton.Click += delegate { SaveTemplateFlow(); };
                actionBar.Controls.Add(saveButton);

                var quickLoadButton = CreateSecondaryButton(
                    "ใช้ข้อมูลเดิม / เดือนถัดไป",
                    new Point(actionBar.Width - 448, 12),
                    new Size(208, 42));
                quickLoadButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                quickLoadButton.Click += delegate { QuickLoadTemplateFlow(); };
                actionBar.Controls.Add(quickLoadButton);

                var button = CreatePrimaryButton(
                    "ตรวจสอบและสร้าง Word",
                    new Point(actionBar.Width - 226, 12),
                    new Size(206, 42));
                button.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                button.Click += delegate { GenerateDocuments(); };
                actionBar.Controls.Add(button);
            }

            private void ApplyFiscalValues()
            {
                if (fiscalMonthBox.SelectedIndex < 0) return;
                var selectedMonth = fiscalMonthBox.SelectedItem == null ? "" : fiscalMonthBox.SelectedItem.ToString();
                var month = GetMonthNumber(selectedMonth);
                if (month == 0) month = fiscalMonthBox.SelectedIndex + 1;
                var buddhistYear = (int)fiscalYearBox.Value;
                var fiscalYear = month >= 10 ? buddhistYear + 1 : buddhistYear;
                var period = month >= 10 ? month - 9 : month + 3;
                var dbMonth = monthOptions.FirstOrDefault(x => x.Month == selectedMonth);
                var calculatedPayDate = GetPayDateForFiscalYear(dbMonth, fiscalYear);
                var payDateKey = selectedMonth + "|" + fiscalYear;
                SetField(TagDeliveryMonth, string.IsNullOrWhiteSpace(selectedMonth) ? ThaiMonths[month] : selectedMonth);
                SetField(TagDeliveryMonthShort, dbMonth == null || string.IsNullOrWhiteSpace(dbMonth.ShortMonth) ? ThaiMonthShort[month] : dbMonth.ShortMonth);
                if (payDateBox != null)
                {
                    if (!string.Equals(payDatePeriodKey, payDateKey, StringComparison.Ordinal))
                    {
                        payDateBox.Text = calculatedPayDate;
                        payDatePeriodKey = payDateKey;
                    }
                    if (!string.IsNullOrWhiteSpace(calculatedPayDate))
                    {
                        payDateBox.Text = calculatedPayDate;
                        payDateBox.ReadOnly = true;
                        payDateBox.BackColor = Color.FromArgb(239, 246, 250);
                        payDateBox.ForeColor = PrimaryDark;
                    }
                    else
                    {
                        payDateBox.ReadOnly = false;
                        payDateBox.BackColor = Color.FromArgb(255, 251, 235);
                        payDateBox.ForeColor = TextColor;
                    }
                }
                SetField(TagPurchaseOrderYear, fiscalYear.ToString());
                fiscalPreview.Text = "\u0e07\u0e27\u0e14\u0e17\u0e35\u0e48 " + period + " / \u0e1b\u0e35\u0e07\u0e1a\u0e1b\u0e23\u0e30\u0e21\u0e32\u0e13 " + fiscalYear;
                statusLabel.Text = "\u0e07\u0e27\u0e14 " + period + " | FY " + fiscalYear;
            }

            private string GetPayDateForFiscalYear(MonthOption month, int fiscalYear)
            {
                if (month == null) return "";

                string payDate;
                if (month.PayDatesByFiscalYear != null && month.PayDatesByFiscalYear.TryGetValue(fiscalYear.ToString(), out payDate))
                {
                    return payDate;
                }

                return month.PayDate ?? "";
            }

            private int GetMonthNumber(string monthName)
            {
                for (var i = 1; i < ThaiMonths.Length; i++)
                {
                    if (ThaiMonths[i] == monthName) return i;
                }
                return 0;
            }

            private void SetField(string tag, string value)
            {
                Control box;
                if (fieldBoxes.TryGetValue(tag, out box)) box.Text = value;
            }

            private static void PickFolder(TextBox box)
            {
                using (var dialog = new FolderBrowserDialog { SelectedPath = box.Text })
                {
                    if (dialog.ShowDialog() == DialogResult.OK) box.Text = dialog.SelectedPath;
                }
            }

            private void EnableDoubleBuffering(Control root)
            {
                var prop = typeof(Control).GetProperty("DoubleBuffered", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (prop != null) prop.SetValue(root, true, null);
                foreach (Control child in root.Controls) EnableDoubleBuffering(child);
            }

            private void GenerateDocuments()
            {
                ApplyFiscalValues();
                errorProvider.Clear();
                var selectedTemplates = GetSelectedDocumentTemplates();
                if (selectedTemplates.Count == 0)
                {
                    MessageBox.Show(
                        "กรุณาเลือกเอกสารอย่างน้อย 1 รายการ",
                        "ยังไม่ได้เลือกเอกสาร",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                if (!Directory.Exists(templateBox.Text))
                {
                    MessageBox.Show(
                        "ไม่พบโฟลเดอร์แม่แบบเอกสาร\n" + templateBox.Text,
                        "ไม่พบแม่แบบเอกสาร",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(outputBox.Text))
                {
                    MessageBox.Show(
                        "กรุณาเลือกโฟลเดอร์ผลลัพธ์",
                        "ยังไม่ได้เลือกโฟลเดอร์",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                var supportedTags = tagDefinitions.Select(x => x.Tag).ToArray();
                var inspections = new Dictionary<DocumentTemplateRecord, TemplateInspectionResult>();
                var preflightErrors = new List<string>();
                foreach (var template in selectedTemplates)
                {
                    var templatePath = Path.Combine(templateBox.Text, template.FileName);
                    var inspection = DocxTemplateInspector.Inspect(templatePath, supportedTags);
                    inspections[template] = inspection;
                    if (!inspection.CanGenerate)
                    {
                        preflightErrors.Add(
                            "• " + template + ": " + BuildTemplateStatusText(inspection));
                    }
                }

                if (preflightErrors.Count > 0)
                {
                    MessageBox.Show(
                        "ยังสร้างเอกสารไม่ได้ เพราะพบปัญหาในแม่แบบที่เลือก\n\n"
                        + string.Join("\n", preflightErrors.Take(8).ToArray())
                        + "\n\nเปิด “จัดการแบบเอกสาร” เพื่อแก้ไฟล์ หรือกด “คู่มือ {tag}” เพื่อดูแท็กที่รองรับ",
                        "ตรวจแม่แบบเอกสารไม่ผ่าน",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    RefreshTemplateTree();
                    return;
                }

                var values = fieldBoxes.ToDictionary(x => x.Key, x => GetControlValue(x.Value));
                NormalizeValues(values);
                var usedInputTags = new HashSet<string>(
                    inspections.Values
                        .SelectMany(x => x.Tags)
                        .Select(GetCanonicalInputTag),
                    StringComparer.Ordinal);
                var missingFields = fieldBoxes
                    .Where(x => usedInputTags.Contains(x.Key)
                        && IsRequiredField(x.Key)
                        && IsEmptyControl(x.Value))
                    .Take(8)
                    .ToArray();
                var missing = missingFields.Select(x => x.Key.Trim('{', '}')).ToArray();
                if (missing.Length > 0)
                {
                    foreach (var item in missingFields) errorProvider.SetError(item.Value, "จำเป็นต้องกรอก");
                    MessageBox.Show(
                        "กรุณากรอกข้อมูลที่แม่แบบซึ่งเลือกใช้งานต้องใช้:\n"
                        + string.Join(", ", missing),
                        "ข้อมูลยังไม่ครบ",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                var confirm = MessageBox.Show(BuildPreview(values), "\u0e15\u0e23\u0e27\u0e08\u0e17\u0e32\u0e19\u0e01\u0e48\u0e2d\u0e19\u0e2a\u0e23\u0e49\u0e32\u0e07", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (confirm != DialogResult.OK) return;

                var created = 0;
                var createdPaths = new List<string>();
                Cursor.Current = Cursors.WaitCursor;
                statusLabel.Text = "\u0e01\u0e33\u0e25\u0e31\u0e07\u0e2a\u0e23\u0e49\u0e32\u0e07...";
                try
                {
                    Directory.CreateDirectory(outputBox.Text);
                    foreach (var template in selectedTemplates)
                    {
                        var templatePath = Path.Combine(templateBox.Text, template.FileName);
                        var outputPath = Path.Combine(
                            outputBox.Text,
                            BuildOutputFileName(template.FileName, values));
                        createdPaths.Add(RenderDocx(templatePath, outputPath, values));
                        created++;
                    }
                }
                catch (Exception ex)
                {
                    statusLabel.Text = "สร้างเอกสารไม่สำเร็จ";
                    MessageBox.Show(
                        "สร้างเอกสารไม่ครบ\n\n" + ex.Message
                        + (createdPaths.Count == 0
                            ? ""
                            : "\n\nไฟล์ที่สร้างสำเร็จก่อนเกิดปัญหา:\n"
                                + string.Join("\n", createdPaths.Select(Path.GetFileName).ToArray())),
                        "เกิดข้อผิดพลาด",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
                finally
                {
                    Cursor.Current = Cursors.Default;
                    if (created == selectedTemplates.Count)
                    {
                        statusLabel.Text = "สร้างเสร็จ " + created + " ไฟล์";
                    }
                }
                if (created == selectedTemplates.Count && created > 0)
                {
                    UpdateQuickLoadedTemplatePeriodAfterGenerate();
                }
                var openOutput = MessageBox.Show(
                    "\u0e2a\u0e23\u0e49\u0e32\u0e07\u0e40\u0e2d\u0e01\u0e2a\u0e32\u0e23 " + created + " \u0e44\u0e1f\u0e25\u0e4c\u0e41\u0e25\u0e49\u0e27\n" + outputBox.Text + "\n\n\u0e15\u0e49\u0e2d\u0e07\u0e01\u0e32\u0e23\u0e40\u0e1b\u0e34\u0e14\u0e42\u0e1f\u0e25\u0e40\u0e14\u0e2d\u0e23\u0e4c output \u0e15\u0e2d\u0e19\u0e19\u0e35\u0e49\u0e2b\u0e23\u0e37\u0e2d\u0e44\u0e21\u0e48?",
                    "\u0e2a\u0e33\u0e40\u0e23\u0e47\u0e08",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information);
                if (openOutput == DialogResult.Yes)
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = outputBox.Text,
                        UseShellExecute = true
                    });
                }
            }

            private string GetCanonicalInputTag(string tag)
            {
                if (string.Equals(tag, "{คำนำหน้าชื่อ}", StringComparison.Ordinal))
                {
                    return "{คำนำหน้าลูกจ้าง}";
                }
                if (string.Equals(tag, "{กรรมการ B}", StringComparison.Ordinal))
                {
                    return "{กรรมการB}";
                }
                if (string.Equals(tag, "{กรรมการ C}", StringComparison.Ordinal))
                {
                    return "{กรรมการC}";
                }
                if (string.Equals(tag, TagFiscalYear, StringComparison.Ordinal))
                {
                    return TagPurchaseOrderYear;
                }
                return tag;
            }

            private Panel CreateCard(Point location, Size size, string title)
            {
                var panel = new Panel
                {
                    Location = location,
                    Size = size,
                    BackColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle
                };
                panel.Controls.Add(new Label
                {
                    Text = FixThai(title),
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                    ForeColor = Navy,
                    Location = new Point(12, 6),
                    Size = new Size(size.Width - 24, 22),
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
                });
                return panel;
            }

            private Button CreateSecondaryButton(string text, Point location, Size size)
            {
                var button = new Button
                {
                    Text = text,
                    Location = location,
                    Size = size,
                    BackColor = Color.White,
                    ForeColor = PrimaryDark,
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    Cursor = Cursors.Hand
                };
                button.FlatAppearance.BorderColor = Border;
                button.FlatAppearance.MouseOverBackColor = Color.FromArgb(241, 247, 251);
                return button;
            }

            private Button CreatePrimaryButton(string text, Point location, Size size)
            {
                var button = new Button
                {
                    Text = text,
                    Location = location,
                    Size = size,
                    BackColor = Primary,
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                    Cursor = Cursors.Hand
                };
                button.FlatAppearance.BorderSize = 0;
                button.FlatAppearance.MouseOverBackColor = PrimaryDark;
                return button;
            }

            private void NormalizeControlText(Control root)
            {
                root.Text = FixThai(root.Text);
                foreach (Control child in root.Controls)
                {
                    child.Text = FixThai(child.Text);
                    NormalizeControlText(child);
                }
            }

            private string FixThai(string value)
            {
                if (string.IsNullOrEmpty(value) || !LooksMojibake(value)) return value;
                try
                {
                    return Encoding.UTF8.GetString(Encoding.GetEncoding(874).GetBytes(value));
                }
                catch
                {
                    return value;
                }
            }

            private bool LooksMojibake(string value)
            {
                return value.IndexOf("เธ", StringComparison.Ordinal) >= 0 || value.IndexOf("เน", StringComparison.Ordinal) >= 0;
            }

            private TabPage CreateTab(string title)
            {
                var page = new TabPage(title) { BackColor = Color.White };
                page.Controls.Add(new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.White });
                return page;
            }

            private TabPage PickFieldPage(string tag, TabPage main, TabPage people, TabPage money, TabPage other)
            {
                if (tag.Contains("\u0e40\u0e07\u0e34\u0e19") || tag.Contains("\u0e43\u0e1a\u0e2a\u0e31\u0e48\u0e07") || tag.Contains("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48")) return money;
                if (tag.Contains("\u0e0a\u0e37\u0e48\u0e2d") || tag.Contains("\u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25") || tag.Contains("\u0e04\u0e33\u0e19\u0e33\u0e2b\u0e19\u0e49\u0e32") || tag.Contains("\u0e01\u0e23\u0e23\u0e21\u0e01\u0e32\u0e23")) return people;
                if (tag == TagDeliveryMonth || tag == TagDeliveryMonthShort || tag.Contains("\u0e42\u0e23\u0e07\u0e40\u0e23\u0e35\u0e22\u0e19") || tag.Contains("\u0e15\u0e33\u0e41\u0e2b\u0e19\u0e48\u0e07")) return main;
                return other;
            }

            private string BuildPreview(Dictionary<string, string> values)
            {
                var selected = GetSelectedDocumentTemplates().Count;
                return "\u0e01\u0e33\u0e25\u0e31\u0e07\u0e08\u0e30\u0e2a\u0e23\u0e49\u0e32\u0e07 " + selected + " \u0e40\u0e2d\u0e01\u0e2a\u0e32\u0e23\n\n"
                    + "\u0e40\u0e14\u0e37\u0e2d\u0e19\u0e2a\u0e48\u0e07\u0e21\u0e2d\u0e1a: " + SafeValue(values, TagDeliveryMonth) + "\n"
                    + "\u0e1b\u0e35\u0e43\u0e1a\u0e2a\u0e31\u0e48\u0e07\u0e08\u0e49\u0e32\u0e07/FY: " + SafeValue(values, TagPurchaseOrderYear) + "\n"
                    + "\u0e42\u0e1f\u0e25\u0e40\u0e14\u0e2d\u0e23\u0e4c\u0e1b\u0e25\u0e32\u0e22\u0e17\u0e32\u0e07: " + outputBox.Text + "\n\n"
                    + "\u0e01\u0e14 OK \u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e2a\u0e23\u0e49\u0e32\u0e07 \u0e2b\u0e23\u0e37\u0e2d Cancel \u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e01\u0e25\u0e31\u0e1a\u0e44\u0e1b\u0e41\u0e01\u0e49\u0e44\u0e02";
            }

            private string SafeValue(Dictionary<string, string> values, string tag)
            {
                string value;
                return values.TryGetValue(tag, out value) ? value : "-";
            }

            private bool IsRequiredField(string tag)
            {
                var custom = (catalog.CustomTags ?? new List<CustomTagDefinition>())
                    .FirstOrDefault(x => string.Equals(x.Tag, tag, StringComparison.Ordinal));
                if (custom != null) return custom.Required;
                return tag != TagHeadFinanceZone
                    && tag != TagEmployeeHouseNo
                    && tag != TagEmployeeRoad
                    && tag != TagEmployeeSubdistrict
                    && tag != TagEmployeeDistrict
                    && tag != TagEmployeeProvince;
            }

            private string GetControlValue(Control control)
            {
                var number = control as NumericUpDown;
                if (number != null)
                {
                    return number.Value.ToString(
                        number.DecimalPlaces > 0 ? "0.##" : "0",
                        System.Globalization.CultureInfo.InvariantCulture);
                }
                var date = control as DateTimePicker;
                if (date != null)
                {
                    return date.Value.ToString("d MMMM yyyy", new System.Globalization.CultureInfo("th-TH"));
                }
                var combo = control as ComboBox;
                if (combo != null)
                {
                    var position = combo.SelectedItem as PositionOption;
                    if (position != null) return position.Position;
                }
                var value = control.Text == null ? "" : control.Text.Trim();
                return value == "--" || value.StartsWith("-- ") ? "" : value;
            }

            private bool IsEmptyControl(Control control)
            {
                return string.IsNullOrWhiteSpace(GetControlValue(control));
            }

            private void NormalizeValues(Dictionary<string, string> values)
            {
                if (values.ContainsKey(TagHeadFinanceZone) && string.IsNullOrWhiteSpace(values[TagHeadFinanceZone]))
                {
                    values[TagHeadFinanceZone] = "";
                }
                values[TagHeadFinanceTitle] = string.IsNullOrWhiteSpace(SafeValue(values, TagHeadFinanceZone))
                    ? ""
                    : "\u0e2b\u0e31\u0e27\u0e2b\u0e19\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e2b\u0e19\u0e49\u0e32\u0e17\u0e35\u0e48\u0e01\u0e32\u0e23\u0e40\u0e07\u0e34\u0e19";
                if (values.ContainsKey(TagSchoolName))
                {
                    values[TagSchoolName] = NormalizeSchoolName(values[TagSchoolName]);
                    SetField(TagSchoolName, values[TagSchoolName]);
                }
                if (values.ContainsKey(TagOrderDate))
                {
                    values[TagOrderDate] = SmartFormatThaiDate(values[TagOrderDate]);
                    SetField(TagOrderDate, values[TagOrderDate]);
                }
                ApplyOptionalSpacing(values, TagEmployeeHouseNo);
                ApplyOptionalSpacing(values, TagEmployeeRoad);
                ApplyOptionalSpacing(values, TagEmployeeSubdistrict);
                ApplyOptionalSpacing(values, TagEmployeeDistrict);
                ApplyOptionalSpacing(values, TagEmployeeProvince);
                NormalizePrefixSpacing(values);
                AddTemplateAliases(values);
            }

            private void NormalizePrefixSpacing(Dictionary<string, string> values)
            {
                var prefixTags = new[]
                {
                    "{คำนำหน้าผอ}", "{คำนำหน้าพัสดุ}", "{คำนำหน้าหพัสดุ}",
                    "{คำนำหน้าการเงิน}", "{คำนำหน้าลูกจ้าง}"
                };
                foreach (var tag in prefixTags)
                {
                    string prefix;
                    if (!values.TryGetValue(tag, out prefix)) continue;
                    prefix = (prefix ?? "").Trim();
                    if (prefix.Contains("ร้อยตรี") || prefix == "ดร.") values[tag] = prefix + " ";
                }
            }

            private void ApplyOptionalSpacing(Dictionary<string, string> values, string tag)
            {
                if (!values.ContainsKey(tag) || string.IsNullOrWhiteSpace(values[tag]))
                {
                    values[tag] = OptionalSpacingValue;
                }
            }

            private void AddTemplateAliases(Dictionary<string, string> values)
            {
                values["{คำนำหน้าชื่อ}"] = SafeValue(values, "{คำนำหน้าลูกจ้าง}");
                values["{กรรมการ B}"] = SafeValue(values, "{กรรมการB}");
                values["{กรรมการ C}"] = SafeValue(values, "{กรรมการC}");
                values[TagFiscalYear] = SafeValue(values, TagPurchaseOrderYear);
            }

            private string NormalizeSchoolName(string input)
            {
                var value = (input ?? "").Trim();
                while (value.StartsWith("โรงเรียนโรงเรียน", StringComparison.Ordinal))
                {
                    value = value.Substring("โรงเรียน".Length).TrimStart();
                }
                if (!value.StartsWith("โรงเรียน", StringComparison.Ordinal)) value = "โรงเรียน" + value;
                return value;
            }

            private string BuildOutputFileName(string templateName, Dictionary<string, string> values)
            {
                var documentName = SafeFilePart(Path.GetFileNameWithoutExtension(templateName));
                var employeeName = SafeFilePart(SafeValue(values, TagEmployeeName));
                var datePart = BuildOutputDatePart();
                return employeeName + "_" + documentName + "_" + datePart + ".docx";
            }

            private string SafeFilePart(string value)
            {
                var safe = string.IsNullOrWhiteSpace(value) ? "-" : value.Trim();
                foreach (var c in Path.GetInvalidFileNameChars()) safe = safe.Replace(c, '_');
                return safe.Length > 80 ? safe.Substring(0, 80) : safe;
            }

            private string SmartFormatThaiDate(string input)
            {
                if (string.IsNullOrWhiteSpace(input)) return "";
                DateTime date;
                var value = input.Trim();
                var formats = new[] { "d/M/yyyy", "dd/MM/yyyy", "yyyy-MM-dd", "d-M-yyyy", "dd-MM-yyyy" };
                if (!DateTime.TryParseExact(value, formats, null, System.Globalization.DateTimeStyles.None, out date)
                    && !DateTime.TryParse(value, out date))
                {
                    return value;
                }
                var year = date.Year < 2450 ? date.Year + 543 : date.Year;
                return date.Day + " " + ThaiMonths[date.Month] + " " + year;
            }

            private string FormatThaiDate(DateTime date)
            {
                return date.Day + " " + ThaiMonths[date.Month] + " " + (date.Year + 543);
            }

            private string BuildOutputDatePart()
            {
                var now = DateTime.Now;
                var buddhistYear = now.Year + 543;
                return now.ToString("ddMM") + (buddhistYear % 100).ToString("00");
            }
        }

        private enum TemplateSaveMode
        {
            SaveNew,
            Overwrite
        }

        private sealed class TemplateFormData
        {
            public readonly Dictionary<string, string> Values = new Dictionary<string, string>();
            public string FiscalMonth = "";
            public string FiscalYear = "";
            public string OrderDay = "";
            public string OrderMonth = "";
            public string OrderYear = "";
            public string HasHeadFinance = "false";

            public Dictionary<string, string> ToDictionary()
            {
                var data = new Dictionary<string, string>(Values);
                data["__fiscalMonth"] = FiscalMonth ?? "";
                data["__fiscalYear"] = FiscalYear ?? "";
                data["__orderDay"] = OrderDay ?? "";
                data["__orderMonth"] = OrderMonth ?? "";
                data["__orderYear"] = OrderYear ?? "";
                data["__hasHeadFinance"] = HasHeadFinance ?? "false";
                return data;
            }

            public static TemplateFormData FromDictionary(Dictionary<string, string> data)
            {
                var result = new TemplateFormData();
                if (data == null) return result;
                foreach (var item in data)
                {
                    switch (item.Key)
                    {
                        case "__fiscalMonth": result.FiscalMonth = item.Value; break;
                        case "__fiscalYear": result.FiscalYear = item.Value; break;
                        case "__orderDay": result.OrderDay = item.Value; break;
                        case "__orderMonth": result.OrderMonth = item.Value; break;
                        case "__orderYear": result.OrderYear = item.Value; break;
                        case "__hasHeadFinance": result.HasHeadFinance = item.Value; break;
                        default: result.Values[item.Key] = item.Value; break;
                    }
                }
                return result;
            }
        }

        private sealed class SavedTemplateRecord
        {
            public string Id = "";
            public string Name = "";
            public string Note = "";
            public string CreatedAt = "";
            public string UpdatedAt = "";
            public string LastGeneratedFiscalMonth = "";
            public string LastGeneratedFiscalYear = "";
            public string LastGeneratedAt = "";
            public Dictionary<string, string> Data = new Dictionary<string, string>();

            public override string ToString()
            {
                return Name;
            }
        }

        private sealed class SavedTemplateFile
        {
            public int Version { get; set; }
            public List<SavedTemplateRecord> Templates { get; set; }

            public SavedTemplateFile()
            {
                Templates = new List<SavedTemplateRecord>();
            }
        }

        private sealed class QuickLoadConfirmationDialog : Form
        {
            public QuickLoadConfirmationDialog(string month, int year)
            {
                Text = "ยืนยันการใช้ข้อมูลเดิม";
                FormBorderStyle = FormBorderStyle.FixedDialog;
                StartPosition = FormStartPosition.CenterParent;
                MaximizeBox = false;
                MinimizeBox = false;
                ShowInTaskbar = false;
                ClientSize = new Size(510, 190);

                Controls.Add(new Label
                {
                    Text = "ยืนยันที่จะใช้ข้อมูลเดียวกันนี้ เพื่อส่งเบิกในเดือน",
                    Location = new Point(28, 30),
                    Size = new Size(455, 30),
                    Font = new Font("Tahoma", 11f, FontStyle.Regular),
                    TextAlign = ContentAlignment.MiddleCenter
                });
                Controls.Add(new Label
                {
                    Text = month + " " + year,
                    Location = new Point(28, 66),
                    Size = new Size(455, 38),
                    Font = new Font("Tahoma", 15f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(35, 105, 180),
                    TextAlign = ContentAlignment.MiddleCenter
                });

                var confirm = new Button
                {
                    Text = "ยืนยัน",
                    Location = new Point(272, 125),
                    Size = new Size(105, 36),
                    BackColor = Color.FromArgb(62, 133, 207),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    DialogResult = DialogResult.OK
                };
                confirm.FlatAppearance.BorderColor = Color.FromArgb(35, 105, 180);
                Controls.Add(confirm);
                Controls.Add(new Button
                {
                    Text = "ยกเลิก",
                    Location = new Point(387, 125),
                    Size = new Size(95, 36),
                    DialogResult = DialogResult.Cancel
                });
                AcceptButton = confirm;
                CancelButton = Controls[Controls.Count - 1] as Button;
            }
        }

        private sealed class TemplateSaveModeDialog : Form
        {
            public TemplateSaveMode SaveMode = TemplateSaveMode.SaveNew;

            public TemplateSaveModeDialog()
            {
                Text = "บันทึกชุดข้อมูล";
                FormBorderStyle = FormBorderStyle.FixedDialog;
                StartPosition = FormStartPosition.CenterParent;
                MinimizeBox = false;
                MaximizeBox = false;
                ClientSize = new Size(360, 170);

                var saveNew = new RadioButton { Text = "บันทึกเป็นชุดข้อมูลใหม่", Location = new Point(24, 24), Size = new Size(250, 24), Checked = true };
                var overwrite = new RadioButton { Text = "บันทึกทับชุดข้อมูลเดิม", Location = new Point(24, 58), Size = new Size(250, 24) };
                Controls.Add(saveNew);
                Controls.Add(overwrite);

                var ok = new Button { Text = "ตกลง", Location = new Point(184, 112), Size = new Size(72, 30) };
                var cancel = new Button { Text = "ยกเลิก", Location = new Point(268, 112), Size = new Size(72, 30) };
                ok.Click += delegate
                {
                    SaveMode = overwrite.Checked ? TemplateSaveMode.Overwrite : TemplateSaveMode.SaveNew;
                    DialogResult = DialogResult.OK;
                    Close();
                };
                cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
                Controls.Add(ok);
                Controls.Add(cancel);
                AcceptButton = ok;
                CancelButton = cancel;
            }
        }

        private sealed class TemplateEditorDialog : Form
        {
            private readonly TextBox nameBox = new TextBox();
            private readonly TextBox noteBox = new TextBox();

            public string TemplateName { get { return nameBox.Text.Trim(); } }
            public string TemplateNote { get { return noteBox.Text.Trim(); } }

            public TemplateEditorDialog(string title, string name, string note)
            {
                Text = title;
                FormBorderStyle = FormBorderStyle.FixedDialog;
                StartPosition = FormStartPosition.CenterParent;
                MinimizeBox = false;
                MaximizeBox = false;
                ClientSize = new Size(420, 220);

                Controls.Add(new Label { Text = "ชื่อชุดข้อมูล *", Location = new Point(20, 20), Size = new Size(140, 20) });
                nameBox.Location = new Point(20, 46);
                nameBox.Size = new Size(376, 24);
                nameBox.Text = name ?? "";
                Controls.Add(nameBox);

                Controls.Add(new Label { Text = "หมายเหตุ *", Location = new Point(20, 84), Size = new Size(140, 20) });
                noteBox.Location = new Point(20, 110);
                noteBox.Size = new Size(376, 54);
                noteBox.Multiline = true;
                noteBox.Text = note ?? "";
                Controls.Add(noteBox);

                var ok = new Button { Text = "บันทึก", Location = new Point(240, 178), Size = new Size(72, 30) };
                var cancel = new Button { Text = "ยกเลิก", Location = new Point(324, 178), Size = new Size(72, 30) };
                ok.Click += delegate
                {
                    if (TemplateName.Length == 0)
                    {
                        MessageBox.Show("กรุณากรอกชื่อชุดข้อมูล", "ข้อมูลไม่ครบ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (TemplateNote.Length == 0)
                    {
                        MessageBox.Show("กรุณากรอกหมายเหตุ", "ข้อมูลไม่ครบ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    DialogResult = DialogResult.OK;
                    Close();
                };
                cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
                Controls.Add(ok);
                Controls.Add(cancel);
                AcceptButton = ok;
                CancelButton = cancel;
            }
        }

        private sealed class TemplatePickerDialog : Form
        {
            private readonly ListBox list = new ListBox();
            private readonly List<SavedTemplateRecord> templates;
            public SavedTemplateRecord SelectedTemplate { get; private set; }

            public TemplatePickerDialog(List<SavedTemplateRecord> templates, string title, bool overwriteMode)
            {
                this.templates = templates;
                Text = title;
                FormBorderStyle = FormBorderStyle.FixedDialog;
                StartPosition = FormStartPosition.CenterParent;
                MinimizeBox = false;
                MaximizeBox = false;
                ClientSize = new Size(460, 320);

                list.Location = new Point(20, 20);
                list.Size = new Size(420, 220);
                list.DisplayMember = "Name";
                list.DataSource = templates.Select(x => x).ToList();
                Controls.Add(list);

                var hint = new Label
                {
                    Text = overwriteMode ? "เลือกชุดข้อมูลที่จะบันทึกทับ" : "เลือกชุดข้อมูลที่จะโหลดเข้าฟอร์ม",
                    Location = new Point(20, 248),
                    Size = new Size(300, 20)
                };
                Controls.Add(hint);

                var ok = new Button { Text = overwriteMode ? "เลือก" : "โหลด", Location = new Point(284, 278), Size = new Size(72, 30) };
                var cancel = new Button { Text = "ยกเลิก", Location = new Point(368, 278), Size = new Size(72, 30) };
                ok.Click += delegate
                {
                    SelectedTemplate = list.SelectedItem as SavedTemplateRecord;
                    if (SelectedTemplate == null)
                    {
                        MessageBox.Show("กรุณาเลือกรายการ", "ยังไม่ได้เลือก", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    DialogResult = DialogResult.OK;
                    Close();
                };
                cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
                Controls.Add(ok);
                Controls.Add(cancel);
                AcceptButton = ok;
                CancelButton = cancel;
            }
        }

        private sealed class TemplateManagerDialog : Form
        {
            private readonly List<SavedTemplateRecord> templates;
            private readonly ListBox list = new ListBox();
            private readonly TextBox previewBox = new TextBox();
            public bool IsDirty { get; private set; }
            public SavedTemplateRecord SelectedTemplate { get; private set; }

            public TemplateManagerDialog(List<SavedTemplateRecord> templates)
            {
                this.templates = templates;
                Text = "จัดการชุดข้อมูล";
                FormBorderStyle = FormBorderStyle.FixedDialog;
                StartPosition = FormStartPosition.CenterParent;
                MinimizeBox = false;
                MaximizeBox = false;
                ClientSize = new Size(760, 420);

                Controls.Add(new Label { Text = "รายการชุดข้อมูล", Location = new Point(20, 16), Size = new Size(160, 20) });
                list.Location = new Point(20, 44);
                list.Size = new Size(280, 300);
                list.DisplayMember = "Name";
                list.SelectedIndexChanged += delegate { RefreshPreview(); };
                Controls.Add(list);

                Controls.Add(new Label { Text = "รายละเอียด", Location = new Point(320, 16), Size = new Size(120, 20) });
                previewBox.Location = new Point(320, 44);
                previewBox.Size = new Size(420, 300);
                previewBox.Multiline = true;
                previewBox.ReadOnly = true;
                previewBox.ScrollBars = ScrollBars.Vertical;
                Controls.Add(previewBox);

                var apply = new Button { Text = "โหลดเข้าฟอร์ม", Location = new Point(320, 360), Size = new Size(110, 30) };
                var rename = new Button { Text = "แก้ชื่อ/หมายเหตุ", Location = new Point(442, 360), Size = new Size(120, 30) };
                var delete = new Button { Text = "ลบ", Location = new Point(574, 360), Size = new Size(72, 30) };
                var close = new Button { Text = "ปิด", Location = new Point(668, 360), Size = new Size(72, 30) };

                apply.Click += delegate
                {
                    SelectedTemplate = list.SelectedItem as SavedTemplateRecord;
                    if (SelectedTemplate == null)
                    {
                        MessageBox.Show("กรุณาเลือกรายการ", "ยังไม่ได้เลือก", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    DialogResult = DialogResult.OK;
                    Close();
                };
                rename.Click += delegate
                {
                    var record = list.SelectedItem as SavedTemplateRecord;
                    if (record == null)
                    {
                        MessageBox.Show("กรุณาเลือกรายการ", "ยังไม่ได้เลือก", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    using (var editor = new TemplateEditorDialog("แก้ไขชุดข้อมูล", record.Name, record.Note))
                    {
                        if (editor.ShowDialog(this) != DialogResult.OK) return;
                        if (templates.Any(x => !ReferenceEquals(x, record) && string.Equals(x.Name, editor.TemplateName, StringComparison.OrdinalIgnoreCase)))
                        {
                            MessageBox.Show("มีชื่อชุดข้อมูลนี้แล้ว", "ชื่อซ้ำ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        record.Name = editor.TemplateName;
                        record.Note = editor.TemplateNote;
                        record.UpdatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                        IsDirty = true;
                        RebindList(record);
                    }
                };
                delete.Click += delegate
                {
                    var record = list.SelectedItem as SavedTemplateRecord;
                    if (record == null)
                    {
                        MessageBox.Show("กรุณาเลือกรายการ", "ยังไม่ได้เลือก", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (MessageBox.Show("ลบชุดข้อมูล \"" + record.Name + "\" ?", "ยืนยัน", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                    templates.Remove(record);
                    IsDirty = true;
                    RebindList(null);
                };
                close.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };

                Controls.Add(apply);
                Controls.Add(rename);
                Controls.Add(delete);
                Controls.Add(close);

                RebindList(templates.FirstOrDefault());
                CancelButton = close;
            }

            private void RebindList(SavedTemplateRecord selected)
            {
                list.DataSource = null;
                list.DataSource = templates.Select(x => x).ToList();
                list.DisplayMember = "Name";
                if (selected != null)
                {
                    for (var i = 0; i < list.Items.Count; i++)
                    {
                        if (ReferenceEquals(list.Items[i], selected))
                        {
                            list.SelectedIndex = i;
                            break;
                        }
                    }
                }
                if (list.SelectedIndex < 0 && list.Items.Count > 0) list.SelectedIndex = 0;
                RefreshPreview();
            }

            private void RefreshPreview()
            {
                var record = list.SelectedItem as SavedTemplateRecord;
                if (record == null)
                {
                    previewBox.Text = "ยังไม่มีรายการ";
                    return;
                }
                previewBox.Text = "ชื่อ: " + record.Name + Environment.NewLine
                    + "หมายเหตุ: " + record.Note + Environment.NewLine
                    + "แก้ไขล่าสุด: " + record.UpdatedAt + Environment.NewLine
                    + Environment.NewLine
                    + "ฟิลด์ที่บันทึกไว้: " + record.Data.Keys.Count(x => !x.StartsWith("__", StringComparison.Ordinal));
            }
        }

        private sealed class CombinedPersonControl : Control
        {
            private readonly ComboBox prefix;
            private readonly TextBox name;
            private readonly TextBox surname;

            public CombinedPersonControl(ComboBox prefix, TextBox name, TextBox surname)
            {
                this.prefix = prefix;
                this.name = name;
                this.surname = surname;
            }

            public Control ParentContainer { get { return prefix.Parent; } }

            public override string Text
            {
                get
                {
                    var title = Clean(prefix.Text);
                    var givenName = Clean(name.Text);
                    var familyName = Clean(surname.Text);
                    var fullName = title;
                    if (givenName.Length > 0)
                    {
                        fullName += title.Length == 0 || title.Contains("ร้อยตรี") || title == "ดร." ? " " + givenName : givenName;
                    }
                    if (familyName.Length > 0)
                    {
                        fullName += (fullName.Length == 0 ? "" : " ") + familyName;
                    }
                    return fullName.Trim();
                }
                set
                {
                    var fullName = Clean(value);
                    var matchedPrefix = prefix.Items.Cast<object>()
                        .Select(x => Clean(x == null ? "" : x.ToString()))
                        .Where(x => x.Length > 0 && x != "--" && x != "........" && fullName.StartsWith(x, StringComparison.Ordinal))
                        .OrderByDescending(x => x.Length)
                        .FirstOrDefault();

                    if (!string.IsNullOrWhiteSpace(matchedPrefix))
                    {
                        for (var i = 0; i < prefix.Items.Count; i++)
                        {
                            if (string.Equals(Clean(prefix.Items[i] == null ? "" : prefix.Items[i].ToString()), matchedPrefix, StringComparison.Ordinal))
                            {
                                prefix.SelectedIndex = i;
                                break;
                            }
                        }
                        fullName = fullName.Substring(matchedPrefix.Length).Trim();
                    }
                    else if (prefix.Items.Count > 0)
                    {
                        prefix.SelectedIndex = 0;
                    }

                    var parts = fullName.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    name.Text = parts.Length > 0 ? parts[0] : "";
                    surname.Text = parts.Length > 1 ? string.Join(" ", parts.Skip(1).ToArray()) : "";
                }
            }

            public void SetChildrenVisible(bool visible)
            {
                prefix.Visible = visible;
                name.Visible = visible;
                surname.Visible = visible;
            }

            private static string Clean(string value)
            {
                value = (value ?? "").Trim();
                return value == "--" || value.StartsWith("-- ") ? "" : value;
            }
        }

        private sealed class OptionalPersonRow
        {
            private readonly Control titleLabel;
            private readonly Control prefixLabel;
            private readonly Control nameLabel;
            private readonly Control surnameLabel;
            public readonly CombinedPersonControl Combined;

            public OptionalPersonRow(Control titleLabel, Control prefixLabel, Control nameLabel, Control surnameLabel, CombinedPersonControl combined)
            {
                this.titleLabel = titleLabel;
                this.prefixLabel = prefixLabel;
                this.nameLabel = nameLabel;
                this.surnameLabel = surnameLabel;
                Combined = combined;
            }

            public void SetVisible(bool visible)
            {
                titleLabel.Visible = visible;
                prefixLabel.Visible = visible;
                nameLabel.Visible = visible;
                surnameLabel.Visible = visible;
                Combined.SetChildrenVisible(visible);
            }
        }

        private sealed class TextSpan
        {
            public int Start;
            public int End;
            public XmlNode Node;
        }

        private sealed class PositionOption
        {
            public string Position;
            public string Salary;
            public string SalaryText;

            public override string ToString()
            {
                if (Position == "ครูในโรงเรียนโครงการตามพระราชดำริและโรงเรียนเฉลิมพระเกียรติ 9,000") return "ครูพระราชดำริ 9,000";
                if (Position == "ครูในโรงเรียนโครงการตามพระราชดำริและโรงเรียนเฉลิมพระเกียรติ 15,000") return "ครูพระราชดำริ 15,000";
                return Position;
            }
        }

        private sealed class MonthOption
        {
            public string Month;
            public string PayDate;
            public string ShortMonth;
            public string OrderYear;
            public Dictionary<string, string> PayDatesByFiscalYear = new Dictionary<string, string>();
        }

        internal static string RenderDocx(string templatePath, string outputPath, Dictionary<string, string> values)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            outputPath = EnsureUniqueOutputPath(outputPath);
            try
            {
                WriteDocxPackage(templatePath, outputPath, values, true);

                var remainingTags = DocxTemplateInspector.ExtractTags(outputPath);
                if (remainingTags.Count > 0)
                {
                    throw new InvalidDataException(
                        "ยังมีแท็กที่ไม่ได้แทนค่าใน "
                        + Path.GetFileName(outputPath)
                        + ": "
                        + string.Join(", ", remainingTags.Take(8).ToArray()));
                }

                return outputPath;
            }
            catch
            {
                if (File.Exists(outputPath)) File.Delete(outputPath);
                throw;
            }
        }

        internal static void RewriteTagInDocx(string templatePath, string outputPath, string oldTag, string newTag)
        {
            if (string.IsNullOrWhiteSpace(oldTag) || string.IsNullOrWhiteSpace(newTag))
            {
                throw new ArgumentException("ชื่อแท็กเดิมและชื่อแท็กใหม่ต้องไม่ว่าง");
            }
            WriteDocxPackage(
                templatePath,
                outputPath,
                new Dictionary<string, string>(StringComparer.Ordinal) { { oldTag, newTag } },
                false);
            var tags = DocxTemplateInspector.ExtractTags(outputPath);
            if (tags.Contains(oldTag, StringComparer.Ordinal) || !tags.Contains(newTag, StringComparer.Ordinal))
            {
                if (File.Exists(outputPath)) File.Delete(outputPath);
                throw new InvalidDataException("เปลี่ยนชื่อแท็กใน " + Path.GetFileName(templatePath) + " ไม่สมบูรณ์");
            }
        }

        private static void WriteDocxPackage(
            string templatePath,
            string outputPath,
            Dictionary<string, string> values,
            bool normalizeSignatureAlignment)
        {
            using (var source = ZipFile.OpenRead(templatePath))
            using (var target = ZipFile.Open(outputPath, ZipArchiveMode.Create))
            {
                foreach (var entry in source.Entries)
                {
                    var newEntry = target.CreateEntry(entry.FullName, CompressionLevel.Optimal);
                    byte[] bytes;
                    using (var input = entry.Open())
                    using (var memory = new MemoryStream())
                    {
                        input.CopyTo(memory);
                        bytes = memory.ToArray();
                    }
                    if (WordXmlRegex.IsMatch(entry.FullName))
                    {
                        bytes = ReplaceTagsInXml(bytes, values, normalizeSignatureAlignment);
                    }
                    using (var output = newEntry.Open()) output.Write(bytes, 0, bytes.Length);
                }
            }
        }

        private static string EnsureUniqueOutputPath(string outputPath)
        {
            if (!File.Exists(outputPath)) return outputPath;

            var directory = Path.GetDirectoryName(outputPath);
            var fileName = Path.GetFileNameWithoutExtension(outputPath);
            var extension = Path.GetExtension(outputPath);
            var counter = 2;
            string candidate;
            do
            {
                candidate = Path.Combine(directory, fileName + "_" + counter + extension);
                counter++;
            }
            while (File.Exists(candidate));
            return candidate;
        }

        private static byte[] ReplaceTagsInXml(
            byte[] bytes,
            Dictionary<string, string> values,
            bool normalizeSignatureAlignment)
        {
            var xml = new XmlDocument { PreserveWhitespace = true };
            xml.LoadXml(Encoding.UTF8.GetString(bytes));
            var nsm = new XmlNamespaceManager(xml.NameTable);
            nsm.AddNamespace("w", WordNs);
            var nodes = xml.SelectNodes("//w:t", nsm);
            if (nodes == null || nodes.Count == 0) return bytes;
            var builder = new StringBuilder();
            var spans = new List<TextSpan>();
            var cursor = 0;
            foreach (XmlNode node in nodes)
            {
                var text = node.InnerText ?? "";
                builder.Append(text);
                spans.Add(new TextSpan { Start = cursor, End = cursor + text.Length, Node = node });
                cursor += text.Length;
            }
            var matches = TagRegex.Matches(builder.ToString()).Cast<Match>().Reverse().ToArray();
            foreach (var match in matches)
            {
                string replacement;
                if (!values.TryGetValue(match.Value, out replacement)) continue;
                var touched = spans.Where(x => x.Start < match.Index + match.Length && x.End > match.Index).ToArray();
                if (touched.Length == 0) continue;
                var first = touched[0];
                var last = touched[touched.Length - 1];
                var firstText = first.Node.InnerText ?? "";
                var lastText = last.Node.InnerText ?? "";
                var prefix = firstText.Substring(0, Math.Max(0, match.Index - first.Start));
                var suffixStart = Math.Max(0, match.Index + match.Length - last.Start);
                var suffix = suffixStart < lastText.Length ? lastText.Substring(suffixStart) : "";
                first.Node.InnerText = prefix + replacement + suffix;
                var attr = xml.CreateAttribute("xml", "space", XmlNs);
                attr.Value = "preserve";
                first.Node.Attributes.SetNamedItem(attr);
                for (var i = 1; i < touched.Length; i++) touched[i].Node.InnerText = "";
            }
            if (normalizeSignatureAlignment) CenterSignatureParagraphs(xml, nsm);
            using (var memory = new MemoryStream())
            {
                var settings = new XmlWriterSettings { Encoding = new UTF8Encoding(false), OmitXmlDeclaration = false };
                using (var writer = XmlWriter.Create(memory, settings)) xml.Save(writer);
                return memory.ToArray();
            }
        }

        private static void CenterSignatureParagraphs(XmlDocument xml, XmlNamespaceManager nsm)
        {
            var paragraphs = xml.SelectNodes("//w:p", nsm);
            if (paragraphs == null) return;
            foreach (XmlNode paragraph in paragraphs)
            {
                var textNodes = paragraph.SelectNodes(".//w:t", nsm);
                if (textNodes == null || textNodes.Count == 0) continue;
                var builder = new StringBuilder();
                foreach (XmlNode node in textNodes) builder.Append(node.InnerText ?? "");
                if (ShouldCenterSignatureLine(builder.ToString())) SetParagraphAlignment(xml, nsm, paragraph, "center");
            }
        }

        private static bool ShouldCenterSignatureLine(string text)
        {
            var value = (text ?? "").Trim();
            if (value.Length == 0 || value.Length > 110) return false;
            if (value.StartsWith("ลงชื่อ")) return false;
            if (value.StartsWith("เรียน")) return false;
            if (value.StartsWith("ตามที่")) return false;
            if (value.StartsWith("บัดนี้")) return false;
            if (value.StartsWith("จึง")) return false;
            if (value.StartsWith("(") && value.EndsWith(")")) return true;
            return value == "เจ้าหน้าที่"
                || value == "เจ้าหน้าที่พัสดุ"
                || value == "หัวหน้าเจ้าหน้าที่พัสดุ"
                || value == "เจ้าหน้าที่การเงิน"
                || value == "หัวหน้าเจ้าหน้าที่การเงิน"
                || value == "กรรมการตรวจรับพัสดุ"
                || value == "ประธานกรรมการตรวจรับพัสดุ"
                || value.StartsWith("ผู้อำนวยการโรงเรียน");
        }

        private static void SetParagraphAlignment(XmlDocument xml, XmlNamespaceManager nsm, XmlNode paragraph, string alignment)
        {
            var pPr = paragraph.SelectSingleNode("./w:pPr", nsm);
            if (pPr == null)
            {
                pPr = xml.CreateElement("w", "pPr", WordNs);
                paragraph.PrependChild(pPr);
            }
            var jc = pPr.SelectSingleNode("./w:jc", nsm);
            if (jc == null)
            {
                jc = xml.CreateElement("w", "jc", WordNs);
                pPr.AppendChild(jc);
            }
            var attr = jc.Attributes["w:val"];
            if (attr == null) attr = xml.CreateAttribute("w", "val", WordNs);
            attr.Value = alignment;
            jc.Attributes.SetNamedItem(attr);
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

internal static class DocxSmokeTest
{
    private static readonly Regex TagRegex = new Regex(@"\{[^{}\r\n]{1,80}\}", RegexOptions.Compiled);
    private static readonly Regex WordXmlRegex = new Regex(@"^word/(document|header\d+|footer\d+)\.xml$", RegexOptions.Compiled);
    private const string WordNs = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

    private static int Main()
    {
        var root = AppDomain.CurrentDomain.BaseDirectory;
        var appExe = Path.Combine(root, "dist", "ReimbursementDocApp.exe");
        var templateDir = Path.Combine(root, "dist", "Template");
        var outputDir = Path.Combine(root, "smoke-output");
        var templateTagsPath = Path.Combine(root, "template_tags.json");

        if (!File.Exists(appExe) || !Directory.Exists(templateDir) || !File.Exists(templateTagsPath))
        {
            Console.WriteLine("Missing test inputs.");
            return 1;
        }

        Directory.CreateDirectory(outputDir);
        var templates = LoadTemplates(templateTagsPath);
        var values = BuildSampleValues();

        var assembly = Assembly.LoadFrom(appExe);
        var programType = assembly.GetType("ReimbursementDocApp.Program", true);
        var render = programType.GetMethod("RenderDocx", BindingFlags.NonPublic | BindingFlags.Static);
        if (render == null)
        {
            Console.WriteLine("RenderDocx not found.");
            return 1;
        }

        var failures = new List<string>();
        foreach (var template in templates.Keys)
        {
            var templatePath = Path.Combine(templateDir, template);
            var outputPath = Path.Combine(outputDir, Path.GetFileNameWithoutExtension(template) + "_SMOKE.docx");
            if (!File.Exists(templatePath))
            {
                failures.Add("Missing template: " + template);
                continue;
            }

            if (File.Exists(outputPath)) File.Delete(outputPath);
            render.Invoke(null, new object[] { templatePath, outputPath, values });
            var leftovers = FindUnreplacedTags(outputPath).ToArray();
            if (leftovers.Length > 0)
            {
                failures.Add(template + " has unreplaced tags: " + string.Join(", ", leftovers));
            }
            else
            {
                Console.WriteLine("OK: " + template);
            }
        }

        if (failures.Count > 0)
        {
            Console.WriteLine("FAIL");
            foreach (var failure in failures) Console.WriteLine(failure);
            return 2;
        }

        Console.WriteLine("PASS");
        return 0;
    }

    private static Dictionary<string, string[]> LoadTemplates(string path)
    {
        var json = File.ReadAllText(path, Encoding.UTF8);
        var blockRegex = new Regex("\"([^\"]+)\"\\s*:\\s*\\[(.*?)\\]", RegexOptions.Singleline);
        var stringRegex = new Regex("\"([^\"]+)\"");
        var result = new Dictionary<string, string[]>();
        foreach (Match block in blockRegex.Matches(json))
        {
            var name = UnescapeJson(block.Groups[1].Value);
            var tags = stringRegex.Matches(block.Groups[2].Value).Cast<Match>().Select(x => UnescapeJson(x.Groups[1].Value)).ToArray();
            result[name] = tags;
        }
        return result;
    }

    private static IEnumerable<string> FindUnreplacedTags(string docxPath)
    {
        using (var archive = ZipFile.OpenRead(docxPath))
        {
            foreach (var entry in archive.Entries.Where(x => WordXmlRegex.IsMatch(x.FullName)))
            {
                using (var stream = entry.Open())
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                {
                    var xml = new XmlDocument { PreserveWhitespace = true };
                    xml.LoadXml(reader.ReadToEnd());
                    var nsm = new XmlNamespaceManager(xml.NameTable);
                    nsm.AddNamespace("w", WordNs);
                    var paragraphs = xml.SelectNodes("//w:p", nsm);
                    if (paragraphs == null) continue;
                    foreach (XmlNode paragraph in paragraphs)
                    {
                        var textNodes = paragraph.SelectNodes(".//w:t", nsm);
                        if (textNodes == null) continue;
                        var builder = new StringBuilder();
                        foreach (XmlNode node in textNodes) builder.Append(node.InnerText ?? "");
                        var text = builder.ToString();
                        foreach (Match match in TagRegex.Matches(text))
                        {
                            yield return match.Value;
                        }
                    }
                }
            }
        }
    }

    private static string UnescapeJson(string value)
    {
        return Regex.Replace(value, @"\\u([0-9a-fA-F]{4})", m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString())
            .Replace("\\\"", "\"")
            .Replace("\\\\", "\\");
    }

    private static Dictionary<string, string> BuildSampleValues()
    {
        return new Dictionary<string, string>
        {
            { "{เดือนที่ส่งมอบ}", "กรกฎาคม" },
            { "{ย่อเดือนที่ส่งมอบ}", "ก.ค." },
            { "{วันที่ส่งเบิก}", "3 สิงหาคม 2569" },
            { "{ปีใบสั่งจ้าง}", "2569" },
            { "{ปีงบประมาณ}", "2569" },
            { "{วันที่สั่งจ้าง}", "1 กรกฎาคม 2569" },
            { "{ใบสั่งจ้าง}", "25/2569" },
            { "{ชื่อโรงเรียน}", "โรงเรียนบ้านช่างหม้อ" },
            { "{ตำแหน่ง}", "ครูอัตราจ้าง" },
            { "{เงินเดือน}", "9,000" },
            { "{เงินเดือนTEXT}", "เก้าพันบาทถ้วน" },
            { "{คำนำหน้าผอ}", "นาย" },
            { "{ชื่อผอ}", "ผอทดสอบ" },
            { "{นามสกุลผอ}", "โรงเรียน" },
            { "{คำนำหน้าพัสดุ}", "นาง" },
            { "{ชื่อพัสดุ}", "พัสดุ" },
            { "{นามสกุลพัสดุ}", "ทดสอบ" },
            { "{คำนำหน้าหพัสดุ}", "นาย" },
            { "{ชื่อหพัสดุ}", "หัวหน้า" },
            { "{นามสกุลหพัสดุ}", "พัสดุ" },
            { "{คำนำหน้าการเงิน}", "นางสาว" },
            { "{ชื่อการเงิน}", "การเงิน" },
            { "{นามสกุลการเงิน}", "ทดสอบ" },
            { "{คำนำหน้าลูกจ้าง}", "นาย" },
            { "{คำนำหน้าชื่อ}", "นาย" },
            { "{ชื่อลูกจ้าง}", "สมชาย" },
            { "{นามสกุลลูกจ้าง}", "ใจดี" },
            { "{บ้านเลขที่ลูกจ้าง}", "99/1" },
            { "{ถนนลูกจ้าง}", "ประชาร่วมใจ" },
            { "{ตำบลลูกจ้าง}", "ช้างเผือก" },
            { "{อำเภอลูกจ้าง}", "เมือง" },
            { "{จังหวัดลูกจ้าง}", "เชียงใหม่" },
            { "{กรรมการA}", "นาย ประธาน หนึ่ง" },
            { "{กรรมการ B}", "นาย กรรมการ สอง" },
            { "{กรรมการ C}", "นาย กรรมการ สาม" },
            { "{กรรมการB}", "นาย กรรมการ สอง" },
            { "{กรรมการC}", "นาย กรรมการ สาม" },
            { "{โซนหัวหน้าการเงิน}", "" },
            { "{หัวหน้าการเงิน}", "" }
        };
    }
}

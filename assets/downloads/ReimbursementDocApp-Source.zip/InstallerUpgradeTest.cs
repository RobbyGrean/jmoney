using System;
using System.IO;
using System.Linq;
using System.Text;
using ReimbursementDocInstaller;

internal static class InstallerUpgradeTest
{
    private static int checks;

    private static int Main()
    {
        var sourceRoot = AppDomain.CurrentDomain.BaseDirectory;
        var testRoot = Path.Combine(sourceRoot, "test-artifacts", "installer-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(testRoot);
        try
        {
            var payload = CreatePayload(testRoot);
            TestFreshInstall(payload, Path.Combine(testRoot, "fresh"));
            TestLegacyUpgrade(payload, Path.Combine(testRoot, "legacy"));
            TestModernUpgrade(payload, Path.Combine(testRoot, "modern"));
            Console.WriteLine("PASS — " + checks + " installer checks");
            Directory.Delete(testRoot, true);
            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine("FAIL after " + checks + " checks");
            Console.WriteLine(ex);
            Console.WriteLine("Artifacts: " + testRoot);
            return 1;
        }
    }

    private static string CreatePayload(string root)
    {
        var payload = Path.Combine(root, "Payload");
        var template = Path.Combine(payload, "Template");
        Directory.CreateDirectory(template);
        Write(payload, "ReimbursementDocApp.exe", "new-exe");
        Write(payload, "Uninstall ReimbursementDocApp.exe", "new-uninstaller");
        Write(payload, "app_database.json", "new-database");
        Write(payload, "template_catalog.json", "new-catalog");
        Write(payload, "template_tags.json", "new-manifest");
        Write(payload, "VERSION.txt", "2.0.0");
        Write(template, "system.docx", "new-system-template");
        return payload;
    }

    private static void TestFreshInstall(string payload, string install)
    {
        var backup = InstallerEngine.InstallPayload(payload, install);
        Check(backup == "", "fresh install does not create an upgrade backup");
        Check(Read(install, "template_catalog.json") == "new-catalog", "fresh install receives the v2.0 catalog");
        Check(Read(Path.Combine(install, "Template"), "system.docx") == "new-system-template",
            "fresh install receives system template");
        Check(Directory.Exists(Path.Combine(install, "output")), "fresh install creates output folder");
    }

    private static void TestLegacyUpgrade(string payload, string install)
    {
        Directory.CreateDirectory(Path.Combine(install, "Template"));
        Directory.CreateDirectory(Path.Combine(install, "output"));
        Write(install, "ReimbursementDocApp.exe", "old-exe");
        Write(install, "template_tags.json", "old-manifest");
        Write(install, "app_database.json", "old-database");
        Write(install, "saved_templates.json", "private-saved-data");
        Write(Path.Combine(install, "output"), "private-output.docx", "private-output");
        Write(Path.Combine(install, "Template"), "system.docx", "old-system-template");
        Write(Path.Combine(install, "Template"), "user-added.docx", "user-template");

        var backup = InstallerEngine.InstallPayload(payload, install);
        Check(Directory.Exists(backup), "legacy upgrade creates a backup");
        Check(Read(install, "saved_templates.json") == "private-saved-data",
            "legacy upgrade preserves saved form data");
        Check(Read(Path.Combine(install, "output"), "private-output.docx") == "private-output",
            "legacy upgrade preserves output documents");
        Check(Read(Path.Combine(install, "Template"), "user-added.docx") == "user-template",
            "legacy upgrade preserves user-added templates");
        Check(Read(Path.Combine(install, "Template"), "system.docx") == "new-system-template",
            "legacy upgrade refreshes system templates");
        Check(Read(install, "template_catalog.json") == "new-catalog",
            "legacy upgrade introduces the modern catalog");
        Check(Read(Path.Combine(backup, "Template"), "system.docx") == "old-system-template",
            "legacy upgrade backup contains the previous system template");
        Check(Read(backup, "app_database.json") == "old-database",
            "legacy upgrade backup contains the previous database");
    }

    private static void TestModernUpgrade(string payload, string install)
    {
        Directory.CreateDirectory(Path.Combine(install, "Template"));
        Directory.CreateDirectory(Path.Combine(install, "output"));
        Write(install, "ReimbursementDocApp.exe", "modern-exe");
        Write(install, "template_catalog.json", "catalog-with-custom-tags-and-groups");
        Write(install, "template_tags.json", "manifest-with-user-template");
        Write(install, "saved_templates.json", "modern-private-data");
        Write(Path.Combine(install, "output"), "modern-output.docx", "modern-output");
        Write(Path.Combine(install, "Template"), "system.docx", "modern-system-template");
        Write(Path.Combine(install, "Template"), "contract.docx", "custom-contract-template");

        var backup = InstallerEngine.InstallPayload(payload, install);
        Check(Read(install, "template_catalog.json") == "catalog-with-custom-tags-and-groups",
            "modern upgrade preserves groups and custom tags");
        Check(Read(install, "template_tags.json") == "manifest-with-user-template",
            "modern upgrade preserves the live template manifest");
        Check(Read(install, "saved_templates.json") == "modern-private-data",
            "modern upgrade preserves saved form data");
        Check(Read(Path.Combine(install, "output"), "modern-output.docx") == "modern-output",
            "modern upgrade preserves output");
        Check(Read(Path.Combine(install, "Template"), "contract.docx") == "custom-contract-template",
            "modern upgrade preserves custom template files");
        Check(Read(Path.Combine(install, "Template"), "system.docx") == "new-system-template",
            "modern upgrade refreshes shipped system template files");
        Check(Read(Path.Combine(backup, "Template"), "system.docx") == "modern-system-template",
            "modern upgrade keeps the previous system template recoverable");
    }

    private static void Write(string directory, string fileName, string value)
    {
        Directory.CreateDirectory(directory);
        File.WriteAllText(Path.Combine(directory, fileName), value, new UTF8Encoding(false));
    }

    private static string Read(string directory, string fileName)
    {
        return File.ReadAllText(Path.Combine(directory, fileName), Encoding.UTF8);
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        checks++;
        Console.WriteLine("OK  " + message);
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;

namespace ReimbursementDocApp
{
    internal static class GoalAcceptanceTest
    {
        private static int checks;

        private static string GetAppExe(string sourceRoot)
        {
            var overridePath = Environment.GetEnvironmentVariable("JMONEY_TEST_APP_EXE");
            return string.IsNullOrWhiteSpace(overridePath)
                ? Path.Combine(sourceRoot, "dist", "ReimbursementDocApp.exe")
                : overridePath;
        }

        [STAThread]
        private static int Main()
        {
            var sourceRoot = AppDomain.CurrentDomain.BaseDirectory;
            var testRoot = Path.Combine(sourceRoot, "test-artifacts");
            if (Directory.Exists(testRoot)) Directory.Delete(testRoot, true);
            var runRoot = Path.Combine(testRoot, "acceptance-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(runRoot);
            try
            {
                TestTagInspection(runRoot);
                TestTagRules();
                TestAtomicCatalogSave(runRoot);
                TestCustomTemplateLifecycle(runRoot);
                TestRenderAndRename(sourceRoot, runRoot);
                TestFiveBuiltInTemplates(sourceRoot, runRoot);
                TestDynamicUiRegistration(sourceRoot);
                TestAdminCancelAndRemoval(sourceRoot, runRoot);
                Console.WriteLine("PASS — " + checks + " checks");
                Directory.Delete(runRoot, true);
                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("FAIL after " + checks + " checks");
                Console.WriteLine(ex);
                Console.WriteLine("Artifacts: " + runRoot);
                return 1;
            }
        }

        private static void TestTagInspection(string root)
        {
            var known = Path.Combine(root, "known-split.docx");
            CreateDocx(known, new[] { "{ชื่อ", "โรงเรียน}" }, "{คำนำหน้าผอ}", "{ชื่อพัสดุ}");
            var inspection = DocxTemplateInspector.Inspect(
                known,
                new[] { "{ชื่อโรงเรียน}", "{คำนำหน้าผอ}", "{ชื่อพัสดุ}" });
            Check(inspection.CanGenerate, "known tags including split runs pass");
            Check(inspection.Tags.Contains("{ชื่อโรงเรียน}"), "split-run body tag is detected");
            Check(inspection.Tags.Contains("{คำนำหน้าผอ}"), "header tag is detected");
            Check(inspection.Tags.Contains("{ชื่อพัสดุ}"), "footer tag is detected");

            var unknown = Path.Combine(root, "unknown.docx");
            CreateDocx(unknown, new[] { "{แท็กใหม่}" }, "", "");
            inspection = DocxTemplateInspector.Inspect(unknown, new[] { "{ชื่อโรงเรียน}" });
            Check(inspection.UnknownTags.SequenceEqual(new[] { "{แท็กใหม่}" }), "unknown tag is blocked");

            var malformed = Path.Combine(root, "malformed.docx");
            CreateDocx(malformed, new[] { "{แท็กผิด]" }, "", "");
            inspection = DocxTemplateInspector.Inspect(malformed, new string[0]);
            Check(inspection.MalformedPlaceholders.Count > 0, "malformed bracket is blocked");
        }

        private static void TestTagRules()
        {
            var custom = NewCustom("{เลขสัญญา}", "Number");
            Check(TagDefinitionRules.Validate(custom, SupportedTagCatalog.Create().Select(x => x.Tag), new CustomTagDefinition[0]) == "",
                "valid custom tag passes");
            var duplicate = NewCustom("{เลขสัญญา}", "Text");
            Check(TagDefinitionRules.Validate(duplicate, new string[0], new[] { custom }).Length > 0,
                "duplicate custom tag is blocked");
            var systemConflict = NewCustom("{ชื่อโรงเรียน}", "Text");
            Check(TagDefinitionRules.Validate(systemConflict, SupportedTagCatalog.Create().Select(x => x.Tag), new CustomTagDefinition[0]).Length > 0,
                "system tag conflict is blocked");
            var malformed = NewCustom("{ผิด]", "Text");
            Check(TagDefinitionRules.Validate(malformed, new string[0], new CustomTagDefinition[0]).Length > 0,
                "malformed custom tag name is blocked");
            var choice = NewCustom("{ประเภทสัญญา}", "Choice");
            Check(TagDefinitionRules.Validate(choice, new string[0], new CustomTagDefinition[0]).Length > 0,
                "choice without options is blocked");
        }

        private static void TestAtomicCatalogSave(string root)
        {
            var folder = Path.Combine(root, "atomic");
            Directory.CreateDirectory(folder);
            var catalog = BasicCatalog();
            TemplateCatalogStore.Save(folder, catalog);
            var catalogPath = Path.Combine(folder, TemplateCatalogStore.CatalogFileName);
            var manifestPath = Path.Combine(folder, TemplateCatalogStore.LegacyManifestFileName);
            var beforeCatalog = File.ReadAllBytes(catalogPath);
            var beforeManifest = File.ReadAllBytes(manifestPath);
            catalog.Groups[0].Name = "ค่าที่ต้องไม่หลุดเข้าไฟล์";
            Environment.SetEnvironmentVariable("JMONEY_TEST_FAIL_SAVE_AFTER_FIRST", "1");
            var failed = false;
            try { TemplateCatalogStore.Save(folder, catalog); }
            catch (IOException) { failed = true; }
            finally { Environment.SetEnvironmentVariable("JMONEY_TEST_FAIL_SAVE_AFTER_FIRST", null); }
            Check(failed, "simulated mid-save failure occurs");
            Check(beforeCatalog.SequenceEqual(File.ReadAllBytes(catalogPath)), "catalog rolls back byte-for-byte");
            Check(beforeManifest.SequenceEqual(File.ReadAllBytes(manifestPath)), "manifest rolls back byte-for-byte");

            File.WriteAllText(Path.Combine(folder, "same.docx"), "x");
            Check(TemplateCatalogStore.GetUniqueFileName(folder, "same.docx") == "same_2.docx",
                "duplicate file name receives a unique suffix");
        }

        private static void TestCustomTemplateLifecycle(string root)
        {
            var app = Path.Combine(root, "lifecycle");
            var templateFolder = Path.Combine(app, "Template");
            Directory.CreateDirectory(templateFolder);
            var custom = NewCustom("{เลขที่สัญญา}", "Text");
            custom.Required = true;
            var catalog = BasicCatalog();
            catalog.CustomTags.Add(custom);
            var group = new DocumentGroupRecord
            {
                Id = "contracts",
                Name = "กระบวนการทำสัญญา",
                Description = "ตัวอย่างกลุ่มที่รองรับการขยายเป็น 11 เอกสาร",
                SortOrder = 1
            };
            catalog.Groups.Add(group);
            var fileName = "contract-custom-tag.docx";
            CreateDocx(Path.Combine(templateFolder, fileName), new[] { "เลขที่ ", "{เลขที่สัญญา}" }, "", "");
            var template = new DocumentTemplateRecord
            {
                Id = TemplateCatalogStore.CreateId(),
                GroupId = group.Id,
                FileName = fileName,
                DisplayName = "ตัวอย่างสัญญา Custom Tag",
                Source = "user",
                Status = TemplateLifecycle.Draft,
                Tags = new List<string>()
            };
            catalog.Templates.Add(template);
            var inspection = TemplateCatalogStore.ValidateTemplate(app, catalog, template);
            Check(inspection.CanGenerate && template.Status == TemplateLifecycle.Draft,
                "valid imported custom template remains Draft before activation");
            TemplateCatalogStore.ActivateTemplate(app, catalog, template);
            Check(template.Status == TemplateLifecycle.Active, "validated custom template can activate");
            Check(template.Tags.SequenceEqual(new[] { "{เลขที่สัญญา}" }), "catalog tag list synchronizes with DOCX");

            CreateDocx(Path.Combine(templateFolder, fileName), new[] { "เลขที่ถูกลบออกจากแม่แบบ" }, "", "");
            inspection = TemplateCatalogStore.ValidateTemplate(app, catalog, template);
            Check(!inspection.CanGenerate && inspection.MissingTags.SequenceEqual(new[] { "{เลขที่สัญญา}" }),
                "tag missing from an established template is blocked");
            Check(template.Tags.SequenceEqual(new[] { "{เลขที่สัญญา}" }),
                "missing-tag validation preserves the expected baseline");
        }

        private static void TestRenderAndRename(string sourceRoot, string root)
        {
            var appExe = GetAppExe(sourceRoot);
            var assembly = Assembly.LoadFrom(appExe);
            var type = assembly.GetType("ReimbursementDocApp.Program", true);
            var render = type.GetMethod("RenderDocx", BindingFlags.NonPublic | BindingFlags.Static);
            var rename = type.GetMethod("RewriteTagInDocx", BindingFlags.NonPublic | BindingFlags.Static);
            Check(render != null && rename != null, "render and safe rename operations are available");

            var source = Path.Combine(root, "render-source.docx");
            CreateDocx(source, new[] { "{เลข", "ที่สัญญา}" }, "", "");
            var rendered = Path.Combine(root, "rendered.docx");
            render.Invoke(null, new object[]
            {
                source,
                rendered,
                new Dictionary<string, string>(StringComparer.Ordinal) { { "{เลขที่สัญญา}", "CN-2569-001" } }
            });
            Check(DocxTemplateInspector.ExtractTags(rendered).Count == 0,
                "custom tag render leaves no placeholder");

            var renamed = Path.Combine(root, "renamed.docx");
            rename.Invoke(null, new object[] { source, renamed, "{เลขที่สัญญา}", "{เลขสัญญาใหม่}" });
            var renamedTags = DocxTemplateInspector.ExtractTags(renamed);
            Check(renamedTags.SequenceEqual(new[] { "{เลขสัญญาใหม่}" }), "split-run custom tag renames safely");
        }

        private static void TestFiveBuiltInTemplates(string sourceRoot, string root)
        {
            var dist = Path.Combine(sourceRoot, "dist");
            var catalog = TemplateCatalogStore.LoadCatalogFile(Path.Combine(dist, TemplateCatalogStore.CatalogFileName));
            var builtIns = catalog.Templates.Where(x => string.Equals(x.Source, "built-in", StringComparison.OrdinalIgnoreCase)).ToList();
            Check(builtIns.Count == 5, "five original built-in templates remain registered");
            var values = SupportedTagCatalog.Create(catalog).ToDictionary(
                x => x.Tag,
                x => string.IsNullOrWhiteSpace(x.Example) ? "ทดสอบ" : x.Example,
                StringComparer.Ordinal);
            var assembly = Assembly.LoadFrom(GetAppExe(sourceRoot));
            var render = assembly.GetType("ReimbursementDocApp.Program", true)
                .GetMethod("RenderDocx", BindingFlags.NonPublic | BindingFlags.Static);
            foreach (var template in builtIns)
            {
                var inspection = DocxTemplateInspector.Inspect(
                    Path.Combine(dist, "Template", template.FileName),
                    values.Keys);
                Check(inspection.CanGenerate, template.DisplayName + " passes preflight");
                Check(
                    inspection.Tags.OrderBy(x => x, StringComparer.Ordinal)
                        .SequenceEqual(template.Tags.OrderBy(x => x, StringComparer.Ordinal), StringComparer.Ordinal),
                    template.DisplayName + " catalog matches DOCX tags");
                var output = Path.Combine(root, "built-in-" + template.Id + ".docx");
                render.Invoke(null, new object[]
                {
                    Path.Combine(dist, "Template", template.FileName),
                    output,
                    values
                });
                Check(DocxTemplateInspector.ExtractTags(output).Count == 0,
                    template.DisplayName + " renders without leftover tags");
            }
        }

        private static void TestDynamicUiRegistration(string sourceRoot)
        {
            var dist = Path.Combine(sourceRoot, "dist");
            var assembly = Assembly.LoadFrom(GetAppExe(sourceRoot));
            var store = assembly.GetType("ReimbursementDocApp.TemplateCatalogStore", true);
            var catalog = store.GetMethod("LoadCatalogFile", BindingFlags.Public | BindingFlags.Static)
                .Invoke(null, new object[] { Path.Combine(dist, "template_catalog.json") });
            var catalogType = catalog.GetType();
            var customTagType = assembly.GetType("ReimbursementDocApp.CustomTagDefinition", true);
            var customTags = (System.Collections.IList)catalogType.GetProperty("CustomTags").GetValue(catalog, null);
            var number = CreateReflectedCustomTag(customTagType, "{จำนวนงวดสัญญา}", "Number");
            var multiline = CreateReflectedCustomTag(customTagType, "{รายละเอียดขอบเขตงาน}", "Multiline");
            customTags.Add(number);
            customTags.Add(multiline);
            var templates = (System.Collections.IList)catalogType.GetProperty("Templates").GetValue(catalog, null);
            var firstTemplate = templates[0];
            var templateTags = (System.Collections.IList)firstTemplate.GetType()
                .GetProperty("Tags").GetValue(firstTemplate, null);
            templateTags.Add("{จำนวนงวดสัญญา}");
            templateTags.Add("{รายละเอียดขอบเขตงาน}");

            var program = assembly.GetType("ReimbursementDocApp.Program", true);
            var mainFormType = program.GetNestedType("MainForm", BindingFlags.NonPublic);
            var constructor = mainFormType.GetConstructors(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Single();
            var form = constructor.Invoke(new[] { catalog });
            try
            {
                var sections = (System.Collections.IDictionary)mainFormType
                    .GetField("standardFieldSections", BindingFlags.Instance | BindingFlags.NonPublic)
                    .GetValue(form);
                Check(sections.Count == 3,
                    "delivery, signer and committee sections register for dynamic reflow");
                var fields = (System.Collections.IDictionary)mainFormType
                    .GetField("fieldBoxes", BindingFlags.Instance | BindingFlags.NonPublic)
                    .GetValue(form);
                Check(fields.Contains("{จำนวนงวดสัญญา}")
                    && fields["{จำนวนงวดสัญญา}"].GetType().Name == "NumericUpDown",
                    "Number custom tag creates a numeric field");
                Check(fields.Contains("{รายละเอียดขอบเขตงาน}")
                    && fields["{รายละเอียดขอบเขตงาน}"].GetType().Name == "TextBox",
                    "Multiline custom tag creates a text area");
            }
            finally
            {
                var disposable = form as IDisposable;
                if (disposable != null) disposable.Dispose();
            }
        }

        private static object CreateReflectedCustomTag(Type type, string tag, string dataType)
        {
            var definition = Activator.CreateInstance(type);
            type.GetProperty("Id").SetValue(definition, Guid.NewGuid().ToString("N"), null);
            type.GetProperty("Tag").SetValue(definition, tag, null);
            type.GetProperty("DisplayName").SetValue(definition, tag.Trim('{', '}'), null);
            type.GetProperty("Description").SetValue(definition, "ข้อมูลทดสอบ", null);
            type.GetProperty("Category").SetValue(definition, "สัญญา", null);
            type.GetProperty("DataType").SetValue(definition, dataType, null);
            type.GetProperty("Choices").SetValue(
                definition,
                Activator.CreateInstance(typeof(List<>).MakeGenericType(typeof(string))),
                null);
            return definition;
        }

        private static void TestAdminCancelAndRemoval(string sourceRoot, string root)
        {
            var dist = Path.Combine(sourceRoot, "dist");
            var assembly = Assembly.LoadFrom(GetAppExe(sourceRoot));
            var store = assembly.GetType("ReimbursementDocApp.TemplateCatalogStore", true);
            var adminType = assembly.GetType("ReimbursementDocApp.TemplateAdminCenterDialog", true);

            var cancelRoot = CreateAdminSandbox(root, "admin-cancel");
            var cancelCatalog = store.GetMethod("LoadCatalogFile", BindingFlags.Public | BindingFlags.Static)
                .Invoke(null, new object[] { Path.Combine(cancelRoot, "template_catalog.json") });
            var canceledCopy = Path.Combine(cancelRoot, "Template", "copied-draft.docx");
            CreateDocx(canceledCopy, new[] { "{ชื่อโรงเรียน}" }, "", "");
            var cancelDialog = CreateAdminDialog(adminType, cancelCatalog, cancelRoot);
            ((System.Collections.IList)adminType.GetField("importedFiles", BindingFlags.Instance | BindingFlags.NonPublic)
                .GetValue(cancelDialog)).Add(canceledCopy);
            adminType.GetMethod("OnAdminClosing", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(cancelDialog, new object[] { null, null });
            Check(!File.Exists(canceledCopy), "canceling admin changes removes the copied draft file");
            ((IDisposable)cancelDialog).Dispose();

            var keepRoot = CreateAdminSandbox(root, "admin-keep");
            var keepPath = Path.Combine(keepRoot, "Template", "user-template.docx");
            CreateDocx(keepPath, new[] { "{ชื่อโรงเรียน}" }, "", "");
            AddUserTemplateToCatalog(keepRoot, "user-template.docx");
            var keepCatalog = store.GetMethod("LoadCatalogFile", BindingFlags.Public | BindingFlags.Static)
                .Invoke(null, new object[] { Path.Combine(keepRoot, "template_catalog.json") });
            var keepDialog = CreateAdminDialog(adminType, keepCatalog, keepRoot);
            RemoveFirstWorkingTemplate(adminType, keepDialog);
            adminType.GetField("dirty", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(keepDialog, true);
            adminType.GetMethod("SaveChanges", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(keepDialog, null);
            Check(File.Exists(keepPath), "removing a catalog entry can keep its DOCX copy");
            ((IDisposable)keepDialog).Dispose();

            var recoverRoot = CreateAdminSandbox(root, "admin-recover");
            var recoverPath = Path.Combine(recoverRoot, "Template", "user-template.docx");
            CreateDocx(recoverPath, new[] { "{ชื่อโรงเรียน}" }, "", "");
            AddUserTemplateToCatalog(recoverRoot, "user-template.docx");
            var recoverCatalog = store.GetMethod("LoadCatalogFile", BindingFlags.Public | BindingFlags.Static)
                .Invoke(null, new object[] { Path.Combine(recoverRoot, "template_catalog.json") });
            var recoverDialog = CreateAdminDialog(adminType, recoverCatalog, recoverRoot);
            RemoveFirstWorkingTemplate(adminType, recoverDialog);
            ((System.Collections.IList)adminType.GetField("filesToRemove", BindingFlags.Instance | BindingFlags.NonPublic)
                .GetValue(recoverDialog)).Add(recoverPath);
            adminType.GetField("dirty", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(recoverDialog, true);
            adminType.GetMethod("SaveChanges", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(recoverDialog, null);
            Check(!File.Exists(recoverPath), "remove-with-recovery moves the DOCX out of Template");
            Check(Directory.GetFiles(Path.Combine(recoverRoot, "admin-backups"), "user-template.docx", SearchOption.AllDirectories).Length == 1,
                "removed DOCX remains recoverable");
            ((IDisposable)recoverDialog).Dispose();
        }

        private static string CreateAdminSandbox(string root, string name)
        {
            var folder = Path.Combine(root, name);
            Directory.CreateDirectory(Path.Combine(folder, "Template"));
            TemplateCatalogStore.Save(folder, BasicCatalog());
            return folder;
        }

        private static void AddUserTemplateToCatalog(string baseDirectory, string fileName)
        {
            var catalog = TemplateCatalogStore.LoadCatalogFile(
                Path.Combine(baseDirectory, TemplateCatalogStore.CatalogFileName));
            catalog.Templates.Add(new DocumentTemplateRecord
            {
                Id = TemplateCatalogStore.CreateId(),
                GroupId = catalog.Groups[0].Id,
                FileName = fileName,
                DisplayName = "แม่แบบผู้ใช้",
                Source = "user",
                Status = TemplateLifecycle.Draft,
                Tags = new List<string> { "{ชื่อโรงเรียน}" }
            });
            TemplateCatalogStore.Save(baseDirectory, catalog);
        }

        private static object CreateAdminDialog(Type adminType, object catalog, string baseDirectory)
        {
            var constructor = adminType.GetConstructors(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Single();
            return constructor.Invoke(new[] { catalog, baseDirectory });
        }

        private static void RemoveFirstWorkingTemplate(Type adminType, object dialog)
        {
            var workingCatalog = adminType.GetField("workingCatalog", BindingFlags.Instance | BindingFlags.NonPublic)
                .GetValue(dialog);
            var templates = (System.Collections.IList)workingCatalog.GetType()
                .GetProperty("Templates").GetValue(workingCatalog, null);
            templates.RemoveAt(0);
        }

        private static DocumentTemplateCatalog BasicCatalog()
        {
            var catalog = new DocumentTemplateCatalog();
            catalog.Groups.Add(new DocumentGroupRecord
            {
                Id = "group",
                Name = "กลุ่มทดสอบ",
                Description = "",
                SortOrder = 0
            });
            return catalog;
        }

        private static CustomTagDefinition NewCustom(string tag, string type)
        {
            return new CustomTagDefinition
            {
                Id = TemplateCatalogStore.CreateId(),
                Tag = tag,
                DisplayName = tag.Trim('{', '}'),
                Description = "ข้อมูลทดสอบ",
                Category = "สัญญา",
                DataType = type,
                Choices = new List<string>(),
                CreatedAt = DateTime.Now.ToString("s")
            };
        }

        private static void CreateDocx(string path, IEnumerable<string> bodyRuns, string header, string footer)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            if (File.Exists(path)) File.Delete(path);
            using (var archive = ZipFile.Open(path, ZipArchiveMode.Create))
            {
                WriteEntry(archive, "[Content_Types].xml",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"/>");
                WriteEntry(archive, "word/document.xml", WordXml(bodyRuns));
                if (header.Length > 0) WriteEntry(archive, "word/header1.xml", WordXml(new[] { header }));
                if (footer.Length > 0) WriteEntry(archive, "word/footer1.xml", WordXml(new[] { footer }));
            }
        }

        private static string WordXml(IEnumerable<string> runs)
        {
            return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body><w:p>"
                + string.Join("", runs.Select(x => "<w:r><w:t xml:space=\"preserve\">" + EscapeXml(x) + "</w:t></w:r>").ToArray())
                + "</w:p></w:body></w:document>";
        }

        private static string EscapeXml(string value)
        {
            return (value ?? "").Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
        }

        private static void WriteEntry(ZipArchive archive, string name, string value)
        {
            var entry = archive.CreateEntry(name);
            using (var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false))) writer.Write(value);
        }

        private static void Check(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
            checks++;
            Console.WriteLine("OK  " + message);
        }
    }
}

using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("jmoney Setup")]
[assembly: System.Reflection.AssemblyProduct("jmoney Office Document Generator")]
[assembly: System.Reflection.AssemblyVersion("2.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("2.0.0.0")]

namespace ReimbursementDocInstaller
{
    internal static class InstallerEngine
    {
        public static string InstallPayload(string payload, string installDir)
        {
            if (!Directory.Exists(payload)) throw new DirectoryNotFoundException("Payload folder was not found: " + payload);
            if (string.IsNullOrWhiteSpace(installDir)) throw new ArgumentException("Install directory is required.");

            var templateDir = Path.Combine(installDir, "Template");
            var outputDir = Path.Combine(installDir, "output");
            var payloadTemplateDir = Path.Combine(payload, "Template");
            var isUpgrade = File.Exists(Path.Combine(installDir, "ReimbursementDocApp.exe"));
            var hasModernCatalog = File.Exists(Path.Combine(installDir, "template_catalog.json"));
            var backupDir = isUpgrade
                ? Path.Combine(
                    installDir,
                    "admin-backups",
                    "installer-upgrade-" + DateTime.Now.ToString("yyyyMMdd-HHmmss")
                        + "-" + Guid.NewGuid().ToString("N").Substring(0, 6))
                : "";

            Directory.CreateDirectory(installDir);
            Directory.CreateDirectory(templateDir);
            Directory.CreateDirectory(outputDir);

            CopyRequiredWithBackup(payload, installDir, "ReimbursementDocApp.exe", backupDir);
            CopyRequiredWithBackup(payload, installDir, "app_database.json", backupDir);
            CopyRequiredWithBackup(payload, installDir, "Uninstall ReimbursementDocApp.exe", backupDir);
            CopyRequiredWithBackup(payload, installDir, "VERSION.txt", backupDir);

            if (!hasModernCatalog)
            {
                CopyRequiredWithBackup(payload, installDir, "template_catalog.json", backupDir);
                CopyRequiredWithBackup(payload, installDir, "template_tags.json", backupDir);
            }
            else
            {
                CopyRequiredIfMissing(payload, installDir, "template_tags.json");
            }

            var templateSourceDir = Directory.Exists(payloadTemplateDir) ? payloadTemplateDir : payload;
            foreach (var file in Directory.GetFiles(templateSourceDir, "*.docx").OrderBy(x => x))
            {
                var destination = Path.Combine(templateDir, Path.GetFileName(file));
                BackupExistingFile(destination, backupDir, "Template");
                CopyAtomic(file, destination);
            }

            return backupDir;
        }

        private static void CopyRequiredWithBackup(
            string sourceDir,
            string targetDir,
            string fileName,
            string backupDir)
        {
            var source = Path.Combine(sourceDir, fileName);
            if (!File.Exists(source)) throw new FileNotFoundException("Required file missing from Payload: " + fileName);
            var destination = Path.Combine(targetDir, fileName);
            BackupExistingFile(destination, backupDir, "");
            CopyAtomic(source, destination);
        }

        private static void CopyRequiredIfMissing(string sourceDir, string targetDir, string fileName)
        {
            var destination = Path.Combine(targetDir, fileName);
            if (File.Exists(destination)) return;
            var source = Path.Combine(sourceDir, fileName);
            if (!File.Exists(source)) throw new FileNotFoundException("Required file missing from Payload: " + fileName);
            CopyAtomic(source, destination);
        }

        private static void BackupExistingFile(string source, string backupDir, string relativeFolder)
        {
            if (!File.Exists(source) || string.IsNullOrWhiteSpace(backupDir)) return;
            var folder = string.IsNullOrWhiteSpace(relativeFolder)
                ? backupDir
                : Path.Combine(backupDir, relativeFolder);
            Directory.CreateDirectory(folder);
            File.Copy(source, Path.Combine(folder, Path.GetFileName(source)), true);
        }

        private static void CopyAtomic(string source, string destination)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(destination));
            var temporary = destination + ".install-" + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.Copy(source, temporary, true);
                if (File.Exists(destination)) File.Replace(temporary, destination, null);
                else File.Move(temporary, destination);
            }
            finally
            {
                if (File.Exists(temporary)) File.Delete(temporary);
            }
        }
    }

    internal static class Program
    {
        private const string AppName = "ReimbursementDocApp";

        [STAThread]
        private static void Main()
        {
            try
            {
                var baseDir = AppDomain.CurrentDomain.BaseDirectory;
                var payload = Path.Combine(baseDir, "Payload");
                if (!Directory.Exists(payload))
                {
                    MessageBox.Show("Payload folder was not found. Put Payload next to ReimbursementDocApp-Setup.exe.", "Installer");
                    return;
                }

                var installDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AppName);
                var backupDir = InstallerEngine.InstallPayload(payload, installDir);

                var appExe = Path.Combine(installDir, "ReimbursementDocApp.exe");
                var uninstallExe = Path.Combine(installDir, "Uninstall ReimbursementDocApp.exe");

                CreateShortcut(
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "ReimbursementDocApp.lnk"),
                    appExe,
                    installDir);

                var startMenuDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), AppName);
                Directory.CreateDirectory(startMenuDir);
                CreateShortcut(Path.Combine(startMenuDir, "ReimbursementDocApp.lnk"), appExe, installDir);
                CreateShortcut(Path.Combine(startMenuDir, "Uninstall ReimbursementDocApp.lnk"), uninstallExe, installDir);

                System.Diagnostics.Process.Start(appExe);
                MessageBox.Show(
                    (string.IsNullOrWhiteSpace(backupDir) ? "Installed successfully:\n" : "Updated successfully:\n")
                    + installDir
                    + (string.IsNullOrWhiteSpace(backupDir) ? "" : "\n\nBackup created at:\n" + backupDir),
                    "jmoney Setup");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Installer Error");
            }
        }

        private static void CreateShortcut(string shortcutPath, string targetPath, string workingDirectory)
        {
            var shellType = Type.GetTypeFromProgID("WScript.Shell");
            dynamic shell = Activator.CreateInstance(shellType);
            var shortcut = shell.CreateShortcut(shortcutPath);
            shortcut.TargetPath = targetPath;
            shortcut.WorkingDirectory = workingDirectory;
            shortcut.Save();
        }
    }
}

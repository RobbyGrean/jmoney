using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ReimbursementDocApp
{
    internal sealed class DocumentTemplateManagerDialog : Form
    {
        private readonly Color Navy = Color.FromArgb(24, 56, 82);
        private readonly Color Primary = Color.FromArgb(31, 94, 140);
        private readonly Color Border = Color.FromArgb(214, 224, 232);
        private readonly Color Muted = Color.FromArgb(100, 116, 139);
        private readonly DocumentTemplateCatalog catalog;
        private readonly string templateDirectory;
        private readonly IList<TagDefinition> tagDefinitions;
        private readonly ListBox groupList = new ListBox();
        private readonly ListView templateList = new ListView();
        private readonly Label summaryLabel = new Label();

        public bool IsDirty { get; private set; }

        public DocumentTemplateManagerDialog(
            DocumentTemplateCatalog catalog,
            string templateDirectory,
            IList<TagDefinition> tagDefinitions)
        {
            this.catalog = catalog;
            this.templateDirectory = templateDirectory;
            this.tagDefinitions = tagDefinitions;

            Text = "จัดการกลุ่มและแม่แบบเอกสาร";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(900, 600);
            ClientSize = new Size(1020, 640);
            Font = new Font("Segoe UI", 9.5f);
            BackColor = Color.FromArgb(243, 246, 248);

            BuildHeader();
            BuildGroupPanel();
            BuildTemplatePanel();
            BuildFooter();
            RefreshGroups(null);
        }

        private void BuildHeader()
        {
            var header = new Panel
            {
                Dock = DockStyle.Top,
                Height = 82,
                BackColor = Navy
            };
            Controls.Add(header);
            header.Controls.Add(new Label
            {
                Text = "คลังแม่แบบเอกสาร",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                Location = new Point(22, 12),
                Size = new Size(430, 30)
            });
            header.Controls.Add(new Label
            {
                Text = "แบ่งเอกสารตามกระบวนงาน และตรวจ {tag} ก่อนนำไปสร้าง Word",
                ForeColor = Color.FromArgb(206, 226, 239),
                Location = new Point(24, 47),
                Size = new Size(600, 22)
            });

            var help = CreateSecondaryButton("?  คู่มือ {tag}", new Point(ClientSize.Width - 164, 22), new Size(138, 36));
            help.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            help.Click += delegate
            {
                using (var dialog = new TagHelpDialog(tagDefinitions)) dialog.ShowDialog(this);
            };
            header.Controls.Add(help);
        }

        private void BuildGroupPanel()
        {
            var panel = CreatePanel(new Point(18, 100), new Size(260, ClientSize.Height - 174));
            panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            Controls.Add(panel);
            panel.Controls.Add(CreateSectionTitle("กลุ่มเอกสาร", 14, 12, 220));

            groupList.Location = new Point(14, 44);
            groupList.Size = new Size(230, panel.Height - 142);
            groupList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            groupList.BorderStyle = BorderStyle.FixedSingle;
            groupList.DisplayMember = "Name";
            groupList.SelectedIndexChanged += delegate { RefreshTemplates(); };
            panel.Controls.Add(groupList);

            var add = CreateSecondaryButton("เพิ่มกลุ่ม", new Point(14, panel.Height - 84), new Size(108, 32));
            add.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            add.Click += delegate { AddGroup(); };
            panel.Controls.Add(add);

            var rename = CreateSecondaryButton("เปลี่ยนชื่อ", new Point(136, panel.Height - 84), new Size(108, 32));
            rename.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            rename.Click += delegate { RenameGroup(); };
            panel.Controls.Add(rename);

            var remove = CreateTextButton("ลบกลุ่มว่าง", new Point(14, panel.Height - 44), new Size(108, 28));
            remove.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            remove.Click += delegate { RemoveEmptyGroup(); };
            panel.Controls.Add(remove);
        }

        private void BuildTemplatePanel()
        {
            var panel = CreatePanel(
                new Point(294, 100),
                new Size(ClientSize.Width - 312, ClientSize.Height - 174));
            panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(panel);
            panel.Controls.Add(CreateSectionTitle("แม่แบบในกลุ่ม", 14, 12, 220));

            summaryLabel.Location = new Point(panel.Width - 264, 14);
            summaryLabel.Size = new Size(248, 22);
            summaryLabel.TextAlign = ContentAlignment.MiddleRight;
            summaryLabel.ForeColor = Muted;
            summaryLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel.Controls.Add(summaryLabel);

            templateList.Location = new Point(14, 44);
            templateList.Size = new Size(panel.Width - 28, panel.Height - 116);
            templateList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            templateList.View = View.Details;
            templateList.FullRowSelect = true;
            templateList.HideSelection = false;
            templateList.MultiSelect = false;
            templateList.GridLines = true;
            templateList.Columns.Add("ชื่อเอกสาร", 250);
            templateList.Columns.Add("ไฟล์", 250);
            templateList.Columns.Add("สถานะ", 180);
            templateList.DoubleClick += delegate { EditSelectedTemplate(); };
            panel.Controls.Add(templateList);

            var add = CreatePrimaryButton("เพิ่มไฟล์ DOCX", new Point(14, panel.Height - 58), new Size(142, 36));
            add.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            add.Click += delegate { AddTemplate(); };
            panel.Controls.Add(add);

            var edit = CreateSecondaryButton("แก้ชื่อ / ย้ายกลุ่ม", new Point(168, panel.Height - 58), new Size(158, 36));
            edit.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            edit.Click += delegate { EditSelectedTemplate(); };
            panel.Controls.Add(edit);

            var remove = CreateSecondaryButton("นำออกจากรายการ", new Point(338, panel.Height - 58), new Size(150, 36));
            remove.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            remove.Click += delegate { RemoveSelectedTemplate(); };
            panel.Controls.Add(remove);

            var openFolder = CreateTextButton(
                "เปิดโฟลเดอร์ Template",
                new Point(panel.Width - 180, panel.Height - 54),
                new Size(166, 30));
            openFolder.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            openFolder.Click += delegate { OpenTemplateFolder(); };
            panel.Controls.Add(openFolder);
        }

        private void BuildFooter()
        {
            var footer = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 58,
                BackColor = Color.White
            };
            footer.Paint += delegate(object sender, PaintEventArgs args)
            {
                using (var pen = new Pen(Border)) args.Graphics.DrawLine(pen, 0, 0, footer.Width, 0);
            };
            Controls.Add(footer);
            footer.Controls.Add(new Label
            {
                Text = "การนำออกจากรายการจะไม่ลบไฟล์ Word ต้นฉบับ",
                Location = new Point(20, 20),
                Size = new Size(420, 22),
                ForeColor = Muted
            });
            var close = CreatePrimaryButton("เสร็จสิ้น", new Point(ClientSize.Width - 132, 11), new Size(106, 36));
            close.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            close.Click += delegate { DialogResult = DialogResult.OK; Close(); };
            footer.Controls.Add(close);
            AcceptButton = close;
        }

        private void AddGroup()
        {
            using (var prompt = new TextPromptDialog(
                "เพิ่มกลุ่มเอกสาร",
                "ชื่อกลุ่มเอกสาร",
                "เช่น กระบวนการทำสัญญา",
                ""))
            {
                if (prompt.ShowDialog(this) != DialogResult.OK) return;
                if (catalog.Groups.Any(x => string.Equals(x.Name, prompt.Value, StringComparison.CurrentCultureIgnoreCase)))
                {
                    MessageBox.Show("มีชื่อกลุ่มนี้แล้ว", "ชื่อกลุ่มซ้ำ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                var group = new DocumentGroupRecord
                {
                    Id = TemplateCatalogStore.CreateId(),
                    Name = prompt.Value,
                    Description = "",
                    SortOrder = catalog.Groups.Count
                };
                catalog.Groups.Add(group);
                IsDirty = true;
                RefreshGroups(group);
            }
        }

        private void RenameGroup()
        {
            var group = groupList.SelectedItem as DocumentGroupRecord;
            if (group == null) return;
            using (var prompt = new TextPromptDialog(
                "เปลี่ยนชื่อกลุ่มเอกสาร",
                "ชื่อกลุ่มเอกสาร",
                "",
                group.Name))
            {
                if (prompt.ShowDialog(this) != DialogResult.OK) return;
                if (catalog.Groups.Any(x => !ReferenceEquals(x, group)
                    && string.Equals(x.Name, prompt.Value, StringComparison.CurrentCultureIgnoreCase)))
                {
                    MessageBox.Show("มีชื่อกลุ่มนี้แล้ว", "ชื่อกลุ่มซ้ำ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                group.Name = prompt.Value;
                IsDirty = true;
                RefreshGroups(group);
            }
        }

        private void RemoveEmptyGroup()
        {
            var group = groupList.SelectedItem as DocumentGroupRecord;
            if (group == null) return;
            if (catalog.Groups.Count == 1)
            {
                MessageBox.Show("ต้องมีอย่างน้อย 1 กลุ่มเอกสาร", "ลบกลุ่มไม่ได้", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (catalog.Templates.Any(x => string.Equals(x.GroupId, group.Id, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(
                    "กรุณาย้ายหรือนำเอกสารออกจากกลุ่มนี้ก่อน",
                    "กลุ่มยังมีเอกสาร",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show(
                "ลบกลุ่ม \"" + group.Name + "\" ?",
                "ยืนยันการลบกลุ่ม",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes) return;
            catalog.Groups.Remove(group);
            IsDirty = true;
            RefreshGroups(catalog.Groups.FirstOrDefault());
        }

        private void AddTemplate()
        {
            var currentGroup = groupList.SelectedItem as DocumentGroupRecord;
            if (currentGroup == null)
            {
                MessageBox.Show("กรุณาเลือกกลุ่มเอกสารก่อน", "ยังไม่ได้เลือกกลุ่ม", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var picker = new OpenFileDialog
            {
                Title = "เลือกแม่แบบเอกสาร Word",
                Filter = "Word document (*.docx)|*.docx",
                CheckFileExists = true,
                Multiselect = false
            })
            {
                if (picker.ShowDialog(this) != DialogResult.OK) return;
                var inspection = DocxTemplateInspector.Inspect(
                    picker.FileName,
                    tagDefinitions.Select(x => x.Tag));
                using (var import = new TemplateImportDialog(
                    picker.FileName,
                    catalog.Groups,
                    currentGroup,
                    inspection))
                {
                    if (import.ShowDialog(this) != DialogResult.OK) return;
                    try
                    {
                        Directory.CreateDirectory(templateDirectory);
                        var storedFileName = TemplateCatalogStore.GetUniqueFileName(
                            templateDirectory,
                            Path.GetFileName(picker.FileName));
                        var destination = Path.Combine(templateDirectory, storedFileName);
                        File.Copy(picker.FileName, destination, false);

                        var template = new DocumentTemplateRecord
                        {
                            Id = TemplateCatalogStore.CreateId(),
                            GroupId = import.SelectedGroup.Id,
                            FileName = storedFileName,
                            DisplayName = import.DisplayName,
                            Description = import.Description,
                            Source = "user",
                            CreatedAt = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                            Tags = inspection.Tags.ToList()
                        };
                        catalog.Templates.Add(template);
                        IsDirty = true;
                        RefreshGroups(import.SelectedGroup);
                        SelectTemplate(template);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "เพิ่มแม่แบบไม่สำเร็จ\n\n" + ex.Message,
                            "เกิดข้อผิดพลาด",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void EditSelectedTemplate()
        {
            var template = GetSelectedTemplate();
            if (template == null) return;
            var currentGroup = catalog.Groups.FirstOrDefault(
                x => string.Equals(x.Id, template.GroupId, StringComparison.OrdinalIgnoreCase));
            using (var editor = new TemplatePropertiesDialog(template, catalog.Groups, currentGroup))
            {
                if (editor.ShowDialog(this) != DialogResult.OK) return;
                template.DisplayName = editor.DisplayName;
                template.Description = editor.Description;
                template.GroupId = editor.SelectedGroup.Id;
                IsDirty = true;
                RefreshGroups(editor.SelectedGroup);
                SelectTemplate(template);
            }
        }

        private void RemoveSelectedTemplate()
        {
            var template = GetSelectedTemplate();
            if (template == null) return;
            if (string.Equals(template.Source, "built-in", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(
                    "เอกสารมาตรฐานที่มากับโปรแกรมไม่สามารถนำออกได้ แต่สามารถย้ายกลุ่มหรือยกเลิกการเลือกในหน้าหลักได้",
                    "เอกสารมาตรฐาน",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show(
                "นำ \"" + template + "\" ออกจากรายการ?\n\nไฟล์ Word จะยังอยู่ในโฟลเดอร์ Template",
                "ยืนยัน",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes) return;
            catalog.Templates.Remove(template);
            IsDirty = true;
            RefreshTemplates();
        }

        private void OpenTemplateFolder()
        {
            try
            {
                Directory.CreateDirectory(templateDirectory);
                Process.Start(new ProcessStartInfo
                {
                    FileName = templateDirectory,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "เปิดโฟลเดอร์ไม่สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshGroups(DocumentGroupRecord selected)
        {
            var selectedId = selected == null ? "" : selected.Id;
            groupList.DataSource = null;
            groupList.DataSource = catalog.Groups
                .OrderBy(x => x.SortOrder)
                .ThenBy(x => x.Name, StringComparer.CurrentCulture)
                .ToList();
            groupList.DisplayMember = "Name";
            if (!string.IsNullOrWhiteSpace(selectedId))
            {
                for (var index = 0; index < groupList.Items.Count; index++)
                {
                    var item = groupList.Items[index] as DocumentGroupRecord;
                    if (item != null && string.Equals(item.Id, selectedId, StringComparison.OrdinalIgnoreCase))
                    {
                        groupList.SelectedIndex = index;
                        break;
                    }
                }
            }
            if (groupList.SelectedIndex < 0 && groupList.Items.Count > 0) groupList.SelectedIndex = 0;
            RefreshTemplates();
        }

        private void RefreshTemplates()
        {
            var selectedGroup = groupList.SelectedItem as DocumentGroupRecord;
            templateList.BeginUpdate();
            templateList.Items.Clear();
            if (selectedGroup != null)
            {
                var supported = tagDefinitions.Select(x => x.Tag).ToArray();
                foreach (var template in catalog.Templates
                    .Where(x => string.Equals(x.GroupId, selectedGroup.Id, StringComparison.OrdinalIgnoreCase)))
                {
                    var inspection = DocxTemplateInspector.Inspect(
                        Path.Combine(templateDirectory, template.FileName),
                        supported);
                    var item = new ListViewItem(template.ToString()) { Tag = template };
                    item.SubItems.Add(template.FileName);
                    item.SubItems.Add(GetStatus(inspection));
                    if (!inspection.CanGenerate) item.ForeColor = Color.FromArgb(180, 83, 9);
                    templateList.Items.Add(item);
                }
            }
            templateList.EndUpdate();
            summaryLabel.Text = templateList.Items.Count + " เอกสาร";
        }

        private string GetStatus(TemplateInspectionResult inspection)
        {
            if (!string.IsNullOrWhiteSpace(inspection.Error)) return inspection.Error;
            if (inspection.MalformedPlaceholders.Count > 0) return "วงเล็บ {tag} ไม่สมบูรณ์";
            if (inspection.UnknownTags.Count > 0) return "ไม่รู้จัก " + inspection.UnknownTags.Count + " แท็ก";
            if (inspection.MissingTags.Count > 0) return "แท็กเดิมหาย " + inspection.MissingTags.Count + " แท็ก";
            return inspection.Tags.Count == 0 ? "พร้อมใช้ • ไม่มีแท็ก" : "พร้อมใช้ • " + inspection.Tags.Count + " แท็ก";
        }

        private DocumentTemplateRecord GetSelectedTemplate()
        {
            if (templateList.SelectedItems.Count == 0)
            {
                MessageBox.Show("กรุณาเลือกแม่แบบเอกสาร", "ยังไม่ได้เลือก", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }
            return templateList.SelectedItems[0].Tag as DocumentTemplateRecord;
        }

        private void SelectTemplate(DocumentTemplateRecord template)
        {
            foreach (ListViewItem item in templateList.Items)
            {
                if (!ReferenceEquals(item.Tag, template)) continue;
                item.Selected = true;
                item.Focused = true;
                item.EnsureVisible();
                break;
            }
        }

        private Panel CreatePanel(Point location, Size size)
        {
            return new Panel
            {
                Location = location,
                Size = size,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
        }

        private Label CreateSectionTitle(string text, int x, int y, int width)
        {
            return new Label
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, 24),
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = Navy
            };
        }

        private Button CreatePrimaryButton(string text, Point location, Size size)
        {
            var button = new Button
            {
                Text = text,
                Location = location,
                Size = size,
                BackColor = Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private Button CreateSecondaryButton(string text, Point location, Size size)
        {
            var button = new Button
            {
                Text = text,
                Location = location,
                Size = size,
                BackColor = Color.White,
                ForeColor = Primary,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderColor = Border;
            return button;
        }

        private Button CreateTextButton(string text, Point location, Size size)
        {
            var button = CreateSecondaryButton(text, location, size);
            button.FlatAppearance.BorderSize = 0;
            return button;
        }
    }

    internal sealed class TemplateImportDialog : Form
    {
        private readonly TextBox nameBox = new TextBox();
        private readonly TextBox descriptionBox = new TextBox();
        private readonly ComboBox groupBox = new ComboBox();
        private readonly CheckBox acknowledge = new CheckBox();
        private readonly Button importButton = new Button();
        private readonly bool needsAcknowledgement;

        public string DisplayName { get { return nameBox.Text.Trim(); } }
        public string Description { get { return descriptionBox.Text.Trim(); } }
        public DocumentGroupRecord SelectedGroup { get { return groupBox.SelectedItem as DocumentGroupRecord; } }

        public TemplateImportDialog(
            string filePath,
            IList<DocumentGroupRecord> groups,
            DocumentGroupRecord selectedGroup,
            TemplateInspectionResult inspection)
        {
            Text = "ตรวจและเพิ่มแม่แบบเอกสาร";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(690, 520);
            Font = new Font("Segoe UI", 9.5f);
            BackColor = Color.White;

            Controls.Add(new Label
            {
                Text = "ตรวจแม่แบบก่อนนำเข้า",
                Location = new Point(24, 18),
                Size = new Size(390, 30),
                Font = new Font("Segoe UI", 15f, FontStyle.Bold),
                ForeColor = Color.FromArgb(24, 56, 82)
            });
            Controls.Add(new Label
            {
                Text = Path.GetFileName(filePath),
                Location = new Point(26, 52),
                Size = new Size(638, 22),
                ForeColor = Color.FromArgb(100, 116, 139)
            });

            Controls.Add(CreateLabel("ชื่อที่แสดง *", 26, 92, 140));
            nameBox.Location = new Point(26, 116);
            nameBox.Size = new Size(310, 26);
            nameBox.Text = Path.GetFileNameWithoutExtension(filePath);
            Controls.Add(nameBox);

            Controls.Add(CreateLabel("กลุ่มเอกสาร *", 354, 92, 140));
            groupBox.Location = new Point(354, 116);
            groupBox.Size = new Size(310, 26);
            groupBox.DropDownStyle = ComboBoxStyle.DropDownList;
            groupBox.DataSource = groups.ToList();
            groupBox.DisplayMember = "Name";
            Controls.Add(groupBox);
            if (selectedGroup != null)
            {
                for (var index = 0; index < groupBox.Items.Count; index++)
                {
                    var item = groupBox.Items[index] as DocumentGroupRecord;
                    if (item != null && string.Equals(item.Id, selectedGroup.Id, StringComparison.OrdinalIgnoreCase))
                    {
                        groupBox.SelectedIndex = index;
                        break;
                    }
                }
            }

            Controls.Add(CreateLabel("คำอธิบาย", 26, 158, 140));
            descriptionBox.Location = new Point(26, 182);
            descriptionBox.Size = new Size(638, 54);
            descriptionBox.Multiline = true;
            Controls.Add(descriptionBox);

            var resultBox = new TextBox
            {
                Location = new Point(26, 268),
                Size = new Size(638, 132),
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = Color.FromArgb(248, 250, 252),
                Text = BuildInspectionText(inspection)
            };
            Controls.Add(CreateLabel("ผลการตรวจ {tag}", 26, 244, 180));
            Controls.Add(resultBox);

            needsAcknowledgement = !inspection.CanGenerate || inspection.Tags.Count == 0;
            acknowledge.Text = inspection.CanGenerate
                ? "รับทราบว่าเอกสารนี้ไม่มีแท็ก และจะถูกสร้างเป็นสำเนาโดยไม่มีการแทนข้อมูล"
                : "รับทราบว่าแท็กที่ไม่ตรงกับระบบอาจค้างอยู่และทำให้เอกสารผิดเพี้ยน";
            acknowledge.Location = new Point(26, 412);
            acknowledge.Size = new Size(638, 34);
            acknowledge.Visible = needsAcknowledgement;
            acknowledge.ForeColor = Color.FromArgb(180, 83, 9);
            acknowledge.CheckedChanged += delegate { UpdateImportButton(inspection); };
            Controls.Add(acknowledge);

            importButton.Text = inspection.CanGenerate ? "เพิ่มแม่แบบ" : "เพิ่มไว้เพื่อแก้ไข";
            importButton.Location = new Point(438, 466);
            importButton.Size = new Size(130, 36);
            importButton.BackColor = Color.FromArgb(31, 94, 140);
            importButton.ForeColor = Color.White;
            importButton.FlatStyle = FlatStyle.Flat;
            importButton.FlatAppearance.BorderSize = 0;
            importButton.Click += delegate
            {
                if (DisplayName.Length == 0 || SelectedGroup == null)
                {
                    MessageBox.Show("กรุณากรอกชื่อและเลือกกลุ่มเอกสาร", "ข้อมูลไม่ครบ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult = DialogResult.OK;
                Close();
            };
            Controls.Add(importButton);

            var cancel = new Button
            {
                Text = "กลับไปแก้ Word",
                Location = new Point(578, 466),
                Size = new Size(86, 36),
                DialogResult = DialogResult.Cancel
            };
            Controls.Add(cancel);
            CancelButton = cancel;
            UpdateImportButton(inspection);
        }

        private void UpdateImportButton(TemplateInspectionResult inspection)
        {
            importButton.Enabled = string.IsNullOrWhiteSpace(inspection.Error)
                && (!needsAcknowledgement || acknowledge.Checked);
        }

        private string BuildInspectionText(TemplateInspectionResult inspection)
        {
            var lines = new List<string>();
            if (!string.IsNullOrWhiteSpace(inspection.Error))
            {
                lines.Add("ไม่สามารถนำเข้า: " + inspection.Error);
                return string.Join(Environment.NewLine, lines.ToArray());
            }
            lines.Add("แท็กที่พบ: " + inspection.Tags.Count);
            if (inspection.Tags.Count > 0)
            {
                lines.Add(string.Join(", ", inspection.Tags.ToArray()));
            }
            if (inspection.UnknownTags.Count > 0)
            {
                lines.Add("");
                lines.Add("แท็กที่ระบบไม่รู้จัก: " + string.Join(", ", inspection.UnknownTags.ToArray()));
                lines.Add("ระบบจะไม่แทนค่าแท็กเหล่านี้ และจะไม่อนุญาตให้สร้างเอกสารจนกว่าจะแก้ไข");
            }
            if (inspection.MalformedPlaceholders.Count > 0)
            {
                lines.Add("");
                lines.Add("วงเล็บปีกกาไม่สมบูรณ์: " + string.Join(", ", inspection.MalformedPlaceholders.ToArray()));
            }
            if (inspection.Tags.Count == 0)
            {
                lines.Add("ไม่พบ {tag} ใน body, header หรือ footer");
            }
            if (inspection.CanGenerate && inspection.Tags.Count > 0)
            {
                lines.Add("");
                lines.Add("ผลตรวจ: พร้อมใช้งาน");
            }
            return string.Join(Environment.NewLine, lines.ToArray());
        }

        private Label CreateLabel(string text, int x, int y, int width)
        {
            return new Label
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, 20),
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59)
            };
        }
    }

    internal sealed class TemplatePropertiesDialog : Form
    {
        private readonly TextBox nameBox = new TextBox();
        private readonly TextBox descriptionBox = new TextBox();
        private readonly ComboBox groupBox = new ComboBox();

        public string DisplayName { get { return nameBox.Text.Trim(); } }
        public string Description { get { return descriptionBox.Text.Trim(); } }
        public DocumentGroupRecord SelectedGroup { get { return groupBox.SelectedItem as DocumentGroupRecord; } }

        public TemplatePropertiesDialog(
            DocumentTemplateRecord template,
            IList<DocumentGroupRecord> groups,
            DocumentGroupRecord selectedGroup)
        {
            Text = "รายละเอียดแม่แบบเอกสาร";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(520, 310);
            Font = new Font("Segoe UI", 9.5f);

            Controls.Add(CreateLabel("ชื่อที่แสดง *", 22, 22));
            nameBox.Location = new Point(22, 48);
            nameBox.Size = new Size(476, 26);
            nameBox.Text = template.ToString();
            Controls.Add(nameBox);

            Controls.Add(CreateLabel("กลุ่มเอกสาร *", 22, 90));
            groupBox.Location = new Point(22, 116);
            groupBox.Size = new Size(476, 26);
            groupBox.DropDownStyle = ComboBoxStyle.DropDownList;
            groupBox.DataSource = groups.ToList();
            groupBox.DisplayMember = "Name";
            Controls.Add(groupBox);
            if (selectedGroup != null)
            {
                for (var index = 0; index < groupBox.Items.Count; index++)
                {
                    var item = groupBox.Items[index] as DocumentGroupRecord;
                    if (item != null && string.Equals(item.Id, selectedGroup.Id, StringComparison.OrdinalIgnoreCase))
                    {
                        groupBox.SelectedIndex = index;
                        break;
                    }
                }
            }

            Controls.Add(CreateLabel("คำอธิบาย", 22, 158));
            descriptionBox.Location = new Point(22, 184);
            descriptionBox.Size = new Size(476, 60);
            descriptionBox.Multiline = true;
            descriptionBox.Text = template.Description ?? "";
            Controls.Add(descriptionBox);

            var save = new Button
            {
                Text = "บันทึก",
                Location = new Point(322, 262),
                Size = new Size(84, 32)
            };
            save.Click += delegate
            {
                if (DisplayName.Length == 0 || SelectedGroup == null)
                {
                    MessageBox.Show("กรุณากรอกชื่อและเลือกกลุ่มเอกสาร", "ข้อมูลไม่ครบ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult = DialogResult.OK;
                Close();
            };
            Controls.Add(save);
            var cancel = new Button
            {
                Text = "ยกเลิก",
                Location = new Point(414, 262),
                Size = new Size(84, 32),
                DialogResult = DialogResult.Cancel
            };
            Controls.Add(cancel);
            AcceptButton = save;
            CancelButton = cancel;
        }

        private Label CreateLabel(string text, int x, int y)
        {
            return new Label
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(180, 20),
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
            };
        }
    }

    internal sealed class TextPromptDialog : Form
    {
        private readonly TextBox valueBox = new TextBox();
        public string Value { get { return valueBox.Text.Trim(); } }

        public TextPromptDialog(string title, string label, string hint, string initialValue)
        {
            Text = title;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(450, 180);
            Font = new Font("Segoe UI", 9.5f);

            Controls.Add(new Label
            {
                Text = label,
                Location = new Point(20, 20),
                Size = new Size(400, 22),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold)
            });
            valueBox.Location = new Point(20, 50);
            valueBox.Size = new Size(410, 26);
            valueBox.Text = initialValue ?? "";
            Controls.Add(valueBox);
            Controls.Add(new Label
            {
                Text = hint,
                Location = new Point(20, 82),
                Size = new Size(410, 22),
                ForeColor = Color.FromArgb(100, 116, 139)
            });

            var ok = new Button { Text = "ตกลง", Location = new Point(254, 126), Size = new Size(84, 32) };
            ok.Click += delegate
            {
                if (Value.Length == 0)
                {
                    MessageBox.Show("กรุณากรอกชื่อ", "ข้อมูลไม่ครบ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DialogResult = DialogResult.OK;
                Close();
            };
            Controls.Add(ok);
            var cancel = new Button
            {
                Text = "ยกเลิก",
                Location = new Point(346, 126),
                Size = new Size(84, 32),
                DialogResult = DialogResult.Cancel
            };
            Controls.Add(cancel);
            AcceptButton = ok;
            CancelButton = cancel;
        }
    }

    internal sealed class TagHelpDialog : Form
    {
        private readonly IList<TagDefinition> definitions;
        private readonly DocumentTemplateCatalog catalog;
        private readonly TextBox searchBox = new TextBox();
        private readonly ComboBox categoryBox = new ComboBox();
        private readonly ListView tagList = new ListView();

        public TagHelpDialog(IList<TagDefinition> definitions)
            : this(definitions, null)
        {
        }

        public TagHelpDialog(IList<TagDefinition> definitions, DocumentTemplateCatalog catalog)
        {
            this.definitions = definitions;
            this.catalog = catalog;
            Text = "คู่มือ {tag} ที่ระบบรองรับ";
            StartPosition = FormStartPosition.CenterParent;
            MinimumSize = new Size(800, 520);
            ClientSize = new Size(940, 600);
            Font = new Font("Segoe UI", 9.5f);
            BackColor = Color.FromArgb(243, 246, 248);
            AutoScaleMode = AutoScaleMode.Dpi;

            var header = new Panel { Dock = DockStyle.Top, Height = 94, BackColor = Color.FromArgb(24, 56, 82) };
            Controls.Add(header);
            header.Controls.Add(new Label
            {
                Text = "คู่มือ {tag}",
                Location = new Point(22, 12),
                Size = new Size(300, 32),
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = Color.White
            });
            header.Controls.Add(new Label
            {
                Text = "ใช้ชื่อแท็กให้ตรงทุกตัวอักษร หากพิมพ์วงเล็บหรือชื่อผิด ระบบจะไม่แทนค่าและเอกสารอาจผิดเพี้ยน",
                Location = new Point(24, 49),
                Size = new Size(860, 30),
                ForeColor = Color.FromArgb(255, 224, 160)
            });

            var filterPanel = new Panel
            {
                Location = new Point(18, 112),
                Size = new Size(ClientSize.Width - 36, 62),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(filterPanel);
            filterPanel.Controls.Add(new Label { Text = "ค้นหา", Location = new Point(14, 20), Size = new Size(55, 22) });
            searchBox.Location = new Point(72, 16);
            searchBox.Size = new Size(330, 26);
            searchBox.TextChanged += delegate { RefreshList(); };
            filterPanel.Controls.Add(searchBox);

            filterPanel.Controls.Add(new Label { Text = "หมวด", Location = new Point(432, 20), Size = new Size(50, 22) });
            categoryBox.Location = new Point(484, 16);
            categoryBox.Size = new Size(220, 26);
            categoryBox.DropDownStyle = ComboBoxStyle.DropDownList;
            categoryBox.Items.Add("ทั้งหมด");
            foreach (var category in definitions.Select(x => x.Category).Distinct().OrderBy(x => x))
            {
                categoryBox.Items.Add(category);
            }
            categoryBox.SelectedIndex = 0;
            categoryBox.SelectedIndexChanged += delegate { RefreshList(); };
            filterPanel.Controls.Add(categoryBox);

            tagList.Location = new Point(18, 190);
            tagList.Size = new Size(ClientSize.Width - 36, ClientSize.Height - 252);
            tagList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tagList.View = View.Details;
            tagList.FullRowSelect = true;
            tagList.HideSelection = false;
            tagList.GridLines = true;
            tagList.Columns.Add("ประเภท", 82);
            tagList.Columns.Add("แท็ก", 190);
            tagList.Columns.Add("ชนิดข้อมูล", 94);
            tagList.Columns.Add("หมวด", 125);
            tagList.Columns.Add("หน้าที่", 300);
            tagList.Columns.Add("เอกสารที่ใช้", 98);
            tagList.Columns.Add("ตัวอย่าง", 160);
            tagList.DoubleClick += delegate { CopySelectedTag(); };
            Controls.Add(tagList);

            var copy = new Button
            {
                Text = "คัดลอกแท็ก",
                Location = new Point(ClientSize.Width - 250, ClientSize.Height - 48),
                Size = new Size(112, 32),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            copy.Click += delegate { CopySelectedTag(); };
            Controls.Add(copy);
            var close = new Button
            {
                Text = "ปิด",
                Location = new Point(ClientSize.Width - 126, ClientSize.Height - 48),
                Size = new Size(108, 32),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right,
                DialogResult = DialogResult.OK
            };
            Controls.Add(close);
            CancelButton = close;
            RefreshList();
        }

        private void RefreshList()
        {
            var search = (searchBox.Text ?? "").Trim();
            var category = categoryBox.SelectedItem == null ? "ทั้งหมด" : categoryBox.SelectedItem.ToString();
            tagList.BeginUpdate();
            tagList.Items.Clear();
            foreach (var definition in definitions.Where(x =>
                (category == "ทั้งหมด" || x.Category == category)
                && (search.Length == 0
                    || x.Tag.IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0
                    || x.Description.IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0)))
            {
                var item = new ListViewItem(definition.IsSystem ? "System" : "Custom") { Tag = definition };
                item.SubItems.Add(definition.Tag);
                item.SubItems.Add(definition.DataType + (definition.Required ? " *" : ""));
                item.SubItems.Add(definition.Category);
                item.SubItems.Add(definition.Description + (definition.IsAlias ? " (ชื่อเดิม/alias)" : ""));
                item.SubItems.Add(catalog == null
                    ? "-"
                    : catalog.Templates.Count(x => (x.Tags ?? new List<string>())
                        .Contains(definition.Tag, StringComparer.Ordinal)).ToString());
                item.SubItems.Add(definition.Example);
                if (definition.IsSystem) item.ForeColor = Color.FromArgb(71, 85, 105);
                tagList.Items.Add(item);
            }
            tagList.EndUpdate();
        }

        private void CopySelectedTag()
        {
            if (tagList.SelectedItems.Count == 0) return;
            var definition = tagList.SelectedItems[0].Tag as TagDefinition;
            if (definition == null) return;
            try
            {
                Clipboard.SetText(definition.Tag);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "คัดลอกไม่สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

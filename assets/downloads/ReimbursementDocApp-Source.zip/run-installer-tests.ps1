$ErrorActionPreference = 'Stop'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $csc)) {
    $csc = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'
}

$testExe = Join-Path $PSScriptRoot 'InstallerUpgradeTest.exe'
& $csc `
    /codepage:65001 `
    /target:exe `
    /platform:anycpu `
    /main:InstallerUpgradeTest `
    /out:$testExe `
    /reference:System.Windows.Forms.dll `
    /reference:Microsoft.CSharp.dll `
    "$PSScriptRoot\Installer.cs" `
    "$PSScriptRoot\InstallerUpgradeTest.cs"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $testExe
exit $LASTEXITCODE

# Prompt ตั้งต้นสำหรับใช้ Source นี้กับ Codex

คัดลอก Prompt ด้านล่างไปใช้ใน task ใหม่หลังแตก Source ZIP แล้ว แก้ข้อความในส่วน `[ข้อมูลของฉัน]` ให้ตรงกับงานจริง

---

## Prompt

```text
คุณกำลังทำงานบน Source ของ ReimbursementDocApp ซึ่งเป็น WinForms desktop app
สำหรับสร้างเอกสาร DOCX แบบ offline จาก Word template และ {tag}

[ข้อมูลของฉัน]
- ชื่อระบบ/หน่วยงาน:
- กระบวนการเอกสารที่ต้องการเพิ่ม:
- รายชื่อเอกสาร:
- ตัวอย่างไฟล์ DOCX อยู่ที่:
- ข้อมูลที่ผู้ใช้ต้องกรอก:
- ข้อมูลที่ต้องคำนวณ:
- ผู้ลงนาม/บทบาท:
- รูปแบบ output ที่ต้องการ:

เป้าหมาย:
ใช้ระบบเดิมเป็นฐาน เพิ่มกลุ่ม แม่แบบ และ Tag สำหรับกระบวนการของฉัน
โดยรักษาความสามารถเดิมและไม่ทำลายเอกสารมาตรฐาน

กฎการทำงาน:
1. อ่าน README.md, DEVELOPER_GUIDE_TH.md, TEMPLATE_AND_TAG_SPEC_TH.md,
   EXTENSION_EXAMPLE_TH.md และ RELEASE_NOTES.md ให้ครบก่อนแก้ไฟล์
2. ตรวจ source, catalog, tag definitions, build scripts และ tests ก่อนสรุปแนวทาง
3. ใช้ DOCX เป็น source of truth ของ layout ตาราง ฟอนต์ spacing Header และ Footer
4. ห้ามเดาความหมายของ Tag หากชื่อหรือผู้รับข้อมูลไม่ชัด ให้รายงานจุดกำกวม
5. ใช้ System Tag เฉพาะเมื่อความหมายตรงกับข้อมูลเดิมจริง
6. ข้อมูลใหม่ที่ผู้ใช้กรอกให้เริ่มจาก Custom Tag ก่อน
7. เพิ่ม System Tag หรือ business logic ใน C# เฉพาะเมื่อจำเป็นต้องคำนวณ
   หรือ Custom Tag type ปัจจุบันรองรับไม่ได้
8. แม่แบบใหม่ต้องผ่าน Draft -> Validate -> Trial Render -> Active
9. ตรวจ Tag ใน document, Header, Footer และกรณี Word แบ่ง Tag เป็นหลาย run
10. ห้ามเปิดใช้แม่แบบเมื่อมี Unknown, Malformed หรือ Missing Tag
11. ก่อน rename/remove ต้องแสดงผลกระทบและมี backup/rollback
12. ห้ามบรรจุ saved_templates.json, output, admin-backups, test executable
    หรือข้อมูลจริงของผู้ใช้ลง Installer/Source package
13. รักษา upgrade-safe installer และข้อมูลของผู้ใช้เดิม
14. เพิ่มหรือแก้ tests ให้ครอบคลุมสิ่งที่เปลี่ยน
15. รัน acceptance tests และ installer tests ก่อน build release
16. ทำงานเฉพาะในโฟลเดอร์โปรเจกต์นี้
17. ห้าม commit หรือ push จนกว่าฉันจะอนุมัติ

ลำดับงาน:
A. วิเคราะห์ระบบปัจจุบันและสรุป source of truth
B. ทำบัญชีเอกสารและ Tag ของไฟล์ที่ฉันให้
C. แยก System Tag ที่ใช้ซ้ำได้, Custom Tag ใหม่ และค่าที่ต้องมี business logic
D. เสนอ group/template/tag mapping พร้อมจุดที่ต้องให้ฉันยืนยัน
E. หลังข้อมูลชัดเจนจึงแก้ source/template/catalog
F. ตรวจ DOCX และแสดงผลการตรวจแต่ละไฟล์
G. รัน tests และรายงานผล
H. Build เฉพาะเมื่อฉันสั่ง
I. สรุปไฟล์ที่เปลี่ยน ความเสี่ยง และวิธีย้อนกลับ

รูปแบบรายงานก่อนเริ่มแก้:
- สิ่งที่ระบบเดิมทำได้
- สิ่งที่งานใหม่ใช้ซ้ำได้
- Tag mapping
- Tag/กฎที่ยังไม่ชัด
- ไฟล์ที่จะเปลี่ยน
- Tests ที่ต้องเพิ่ม
- ความเสี่ยงต่อ layout/upgrade
```

---

## Prompt สำหรับตรวจ DOCX อย่างเดียว

```text
ตรวจไฟล์ DOCX ที่ฉันให้โดยยังไม่แก้ code:
- แสดง Tag ทั้งหมด แยก document/header/footer
- ตรวจ Unknown, Malformed, Missing และ split-run Tag
- จัดตาราง Tag -> ความหมายที่คาดจากบริบท -> System/Custom/ต้องยืนยัน
- ระบุตำแหน่งที่ font, spacing, table หรือ signature alignment เสี่ยงเปลี่ยน
- ห้ามเดาความหมายสุดท้าย ให้ถามเมื่อไม่แน่ใจ
- ยังไม่ build, commit หรือ push
```

## Prompt สำหรับ Review ก่อน Release

```text
ตรวจ release candidate โดยไม่เปลี่ยน business rule:
- รัน acceptance tests และ installer upgrade tests
- ตรวจ System/User Template และ lifecycle
- ทดลอง render แม่แบบทั้งหมด
- ตรวจว่าไม่เหลือ placeholder
- ตรวจ Source ZIP ว่าไม่มีข้อมูลผู้ใช้/output/backup/test executable
- ตรวจ Installer payload, version, file list และ upgrade preservation
- ตรวจ README/Guide/Release Notes/checksum
- รายงาน blocker ก่อน build หรือเผยแพร่
- ห้าม commit หรือ push
```

## สิ่งที่ควรแนบให้ Codex

- Source ทั้งโฟลเดอร์
- DOCX ตัวอย่างที่ไม่มีข้อมูลส่วนบุคคลจริง
- ตารางความหมาย Tag ที่เจ้าของงานยืนยันแล้ว
- ตัวอย่าง output ที่ถูกต้อง
- กฎการคำนวณ วันที่ ปีงบประมาณ และผู้ลงนาม
- รายการข้อห้ามด้านข้อมูลและการเผยแพร่

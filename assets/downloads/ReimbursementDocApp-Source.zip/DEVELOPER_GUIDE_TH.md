# คู่มือต่อยอด ReimbursementDocApp

เอกสารนี้สำหรับผู้ที่ต้องการใช้ Source ของ jmoney เป็นฐานสร้างระบบเอกสาร Word ของตนเอง โดยไม่จำเป็นต้องเริ่ม WinForms, DOCX engine, ระบบกลุ่ม, Template lifecycle และ Custom Tag ใหม่ทั้งหมด

## สิ่งที่นำไปใช้ซ้ำได้

- WinForms UI สำหรับกรอกข้อมูลและเลือกเอกสารเป็นกลุ่ม
- DOCX renderer ที่แทน `{tag}` ใน document, Header และ Footer
- การรองรับแท็กที่ Word แบ่งเป็นหลาย run
- `template_catalog.json` สำหรับกลุ่ม แม่แบบ สถานะ และ Custom Tag
- ศูนย์ผู้ดูแลสำหรับ Import, Validate, Activate, Remove และ Recovery
- Custom Tag ชนิด Text, Multiline, Number, Date และ Choice
- การบันทึกแบบ atomic พร้อม backup/rollback
- Installer แบบ upgrade-safe
- Acceptance tests และ installer upgrade tests

## Workflow แนะนำ

```mermaid
flowchart TD
    A["แตก Source ZIP ลงโฟลเดอร์ใหม่"] --> B["อ่าน README และ Template/Tag Specification"]
    B --> C["รัน tests โดยยังไม่แก้โค้ด"]
    C --> D{"Tests เดิมผ่าน?"}
    D -- "ไม่ผ่าน" --> E["แก้ environment หรือ baseline ก่อน"]
    D -- "ผ่าน" --> F["สำรวจ DOCX ของงานใหม่"]
    F --> G["ทำบัญชีข้อมูลและ Tag"]
    G --> H{"System Tag เดิมใช้ได้หรือไม่?"}
    H -- "ได้" --> I["ใช้ชื่อเดิมตามความหมายจริง"]
    H -- "ไม่ได้" --> J["สร้าง Custom Tag"]
    I --> K["Import DOCX เป็น Draft"]
    J --> K
    K --> L["Validate"]
    L --> M["Trial Render"]
    M --> N["ตรวจฟอนต์ spacing ตาราง Header/Footer"]
    N --> O{"ผลถูกต้อง?"}
    O -- "ไม่" --> P["แก้ DOCX/Tag แล้วตรวจใหม่"]
    P --> L
    O -- "ใช่" --> Q["Activate"]
    Q --> R["เพิ่ม tests ของงานใหม่"]
    R --> S["Build Installer และ Source"]
```

## เริ่มต้นอย่างปลอดภัย

1. แตก Source ZIP ลงโฟลเดอร์งานของตนเอง
2. อย่าทำงานบน ZIP หรือโฟลเดอร์ต้นฉบับเพียงชุดเดียว
3. รันชุดทดสอบเดิมก่อนเปลี่ยนสิ่งใด
4. เปิด `template_catalog.json` เพื่อดู schema แต่ให้โปรแกรมเป็นผู้บันทึก catalog ระหว่างใช้งานจริง
5. ตรวจแม่แบบทั้ง 5 ฉบับเพื่อดูตัวอย่างการวาง Tag
6. ทำตารางข้อมูลของงานใหม่ก่อนสร้าง Tag
7. เลือกใช้ System Tag เฉพาะเมื่อความหมายตรงกันจริง
8. ใช้ Custom Tag เมื่อเป็นข้อมูลเฉพาะของกระบวนการใหม่

คำสั่ง baseline:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-exe.ps1
powershell -ExecutionPolicy Bypass -File .\run-acceptance-tests.ps1
powershell -ExecutionPolicy Bypass -File .\run-installer-tests.ps1
```

## แยกสิ่งที่ควรแก้กับไม่ควรแก้

| ต้องการ | จุดที่ควรเริ่ม | หมายเหตุ |
|---|---|---|
| เพิ่มเอกสาร | ศูนย์ผู้ดูแล > นำเข้า DOCX | ไม่ต้องแก้ C# หากใช้ System/Custom Tag |
| เพิ่มกลุ่ม | ศูนย์ผู้ดูแล > กลุ่มเอกสาร | ระบุชื่อและคำอธิบายให้ชัด |
| เพิ่มช่องกรอก | Custom Tag | เลือกชนิดข้อมูลและ Required ให้เหมาะสม |
| เปลี่ยนหน้าตาเอกสาร | ไฟล์ DOCX | รักษา Tag และตรวจ render |
| เพิ่ม business rule ใหม่ | C# + tests | ใช้เมื่อ Custom Tag ธรรมดาไม่เพียงพอ |
| เพิ่มข้อมูลอ้างอิง | `app_database.json` + code ที่อ่านข้อมูล | ต้องรักษา schema เดิม |
| เปลี่ยนกระบวนการติดตั้ง | `Installer.cs` + installer tests | ต้องทดสอบ fresh/legacy/modern upgrade |

## เมื่อใดควรสร้าง System Tag ใหม่

Custom Tag เหมาะกับข้อมูลที่ผู้ใช้กรอกโดยตรง หากข้อมูลใหม่ต้อง:

- คำนวณจากหลายช่อง
- แปลงรูปแบบตามกฎเฉพาะ
- ใช้ร่วมกันเป็นมาตรฐานในหลายกระบวนการ
- มี UI เฉพาะที่ Custom Tag type ปัจจุบันรองรับไม่ได้

จึงค่อยพิจารณาเพิ่ม System Tag ใน code พร้อม:

1. ค่าคงที่หรือ definition
2. คำอธิบายและตัวอย่าง
3. UI/derived-value logic
4. validation
5. render test
6. migration compatibility
7. การอัปเดตเอกสาร

ห้ามเพิ่ม System Tag เพียงเพราะไม่ต้องการใช้หน้าสร้าง Custom Tag

## หลักการรักษา DOCX

- DOCX เป็น source of truth ของ layout
- อย่าสร้างหน้ากระดาษ ตาราง หรือลายเซ็นใหม่ใน C# ถ้าแก้ใน Word template ได้
- อย่าใช้การ replace string แบบเปิด XML ชิ้นเดียว
- ต้องรองรับ Header, Footer และ split runs
- อย่าเปลี่ยน style/font ของ run รอบ Tag โดยไม่จำเป็น
- ตรวจเอกสารจริงหลัง render ทุกครั้งเมื่อเปลี่ยน layout
- ใช้ข้อความทดสอบยาวและสั้นเพื่อดู pagination

## เพิ่ม Tests ของระบบใหม่

อย่างน้อยควรมี:

- แม่แบบใหม่ผ่าน preflight
- รายการ Tag ใน catalog ตรงกับ DOCX
- render แล้วไม่เหลือ placeholder
- Custom Tag ทุกชนิดที่ใช้สร้าง UI ได้
- Required Tag ว่างแล้วถูก block
- Unknown/Malformed/Missing Tag ถูก block
- Header/Footer และ split-run ที่ใช้จริงทำงาน
- การเปลี่ยนชื่อ Tag มี backup และ rollback
- installer อัปเกรดแล้วรักษาแม่แบบ/ข้อมูลผู้ใช้

## การออก Release ของตนเอง

1. เปลี่ยนชื่อผลิตภัณฑ์ ไอคอน และ version ให้ชัดเจน
2. ตรวจสิทธิ์การใช้แม่แบบและข้อมูลตัวอย่าง
3. ล้างข้อมูลผู้ใช้, output และ backup ออกจาก package
4. รัน tests ทั้งหมด
5. Build:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-installer.ps1
```

6. แตก ZIP ที่ build แล้วตรวจรายการไฟล์
7. ทดลอง fresh install
8. ทดลองอัปเกรดจากรุ่นที่แจกจริง
9. คำนวณ SHA-256
10. อัปเดต README/Guide/Release Notes ก่อนเผยแพร่

## จุดที่ต้องใช้วิจารณญาณของเจ้าของระบบ

Codex หรือ AI ช่วยอ่านโค้ด สร้าง tests และลดงานซ้ำได้ แต่ไม่ควรเดา:

- ความหมายของเอกสารทางกฎหมายหรือราชการ
- ผู้มีอำนาจลงนาม
- ชื่อ Tag ที่ควรผูกกับบุคคลใด
- กฎปีงบประมาณหรือวันจ่ายของหน่วยงานใหม่
- รูปแบบเอกสารที่ต้องผ่านการรับรอง

ให้เจ้าของกระบวนการยืนยันข้อมูลเหล่านี้ก่อนเปลี่ยน code หรือ template
